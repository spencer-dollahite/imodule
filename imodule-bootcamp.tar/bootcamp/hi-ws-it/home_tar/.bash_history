whoami
ssh dcho@10.7.10.42
vim notes.txt
smbclient -L 10.7.10.20 -N
history
sudo apt update
cd ~
cat Documents/OPORD-26.txt
