#!/bin/bash
# bootcamp :: hi-ws-it (rmorales, the new arrival). $1 = password. This is a
# hands-on onboarding lab: give the student the seeded practice data so they can
# read and slice it, and leave the dotfiles they will edit to the student to create.
echo "$1" | sudo -S chown -R "$(id -un)":"$(id -gn)" "$HOME/range-data" 2>/dev/null
# make sure a .bashrc exists to append aliases to (the base image ships one, but be safe)
[ -f "$HOME/.bashrc" ] || touch "$HOME/.bashrc"
echo $1 | sudo -S /usr/local/sbin/don-baseline-load 2>/dev/null
echo $1 | sudo -S systemctl enable --now don-baseline-replay.timer 2>/dev/null
echo $1 | sudo -S chown -R rmorales:rmorales /home/rmorales 2>/dev/null
echo $1 | sudo -S install -d -m 700 -o rmorales -g rmorales /home/rmorales/.ssh
echo $1 | sudo -S -u rmorales bash -c 'command -v ssh-keygen >/dev/null || exit 0; [ -f ~/.ssh/id_ed25519 ] || { ssh-keygen -t ed25519 -N "" -C "rmorales@hi-ws-it" -f ~/.ssh/id_ed25519 -q && touch -d "2026-05-26 15:33:23" ~/.ssh/id_ed25519 ~/.ssh/id_ed25519.pub; }'
echo $1 | sudo -S ln -sf /usr/share/zoneinfo/Pacific/Honolulu /etc/localtime 2>/dev/null
echo $1 | sudo -S sh -c 'echo Pacific/Honolulu > /etc/timezone' 2>/dev/null
