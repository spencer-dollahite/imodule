---
title: "Bootcamp: First Watch -- Finding Your Way Around the Command Line"
subtitle: "Fleet Cyber Detachment - Pacific (FCD-PAC)"
lab: "bootcamp"
---

<button class="toc-toggle no-print" id="tocToggle" type="button" aria-label="Collapse or expand the contents sidebar" title="Collapse / expand the contents sidebar">&#10094;</button>
<div class="export-menu no-print">
<button class="bearings-btn" id="btnBearings" type="button" title="Bearings — your credentials, the network, and who's who for this lab"><svg class="compass-ico" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><polygon points="12,12 15.2,8.8 12,14.5" fill="currentColor" stroke="none"/><polygon points="12,12 8.8,15.2 12,9.5" fill="currentColor" stroke="none" opacity="0.55"/></svg> Bearings</button><div class="actions-wrap" id="actionsWrap">
<button class="actions-btn" id="btnActions" type="button" aria-haspopup="true" aria-expanded="false" title="Lab actions: check your work, stop the lab, or reset it">&#9881; Actions &#9662;</button>
<div class="actions-dropdown" id="actionsMenu" hidden>
<button id="btnCheckWork" type="button" title="Run checkwork: your progress + what the automated grader looks for">&#10003; checkwork</button>
<button id="btnStopLab" type="button" title="Run stoplab: stop this lab and save your submission">&#9632; stoplab</button>
<button id="btnResetLab" type="button" class="actions-danger" title="Reset the lab to a fresh instance — your current work is discarded">&#8635; Reset Lab</button>
</div>
</div>
<button class="pdf-btn" id="btnExportReport" type="button" title="Download your questions, answers, and screenshots as a self-contained report to submit. Printing to PDF (Ctrl+P) produces this same report.">&#11015; Download Lab Report</button>
<button class="pdf-caret" id="btnExportMore" type="button" aria-haspopup="true" aria-expanded="false" title="More export options">&#9662;</button>
<div class="export-dropdown" id="exportMore" hidden>
<button id="btnExportDebug" type="button" title="Download a troubleshooting bundle (bridge status, lab state, recent errors) — student email/name are scrubbed">&#128295; Export Debug Log</button>
</div>
</div>

<div class="conn-banner no-print" id="connBanner" hidden title="Open this manual on the VM where Labtainers is running so the live buttons work.">
<span class="conn-dot">&#9888;</span>
<span class="conn-msg"><strong>Not attached to the lab VM.</strong> Live <strong>checkwork</strong> and <strong>stoplab</strong> cannot reach the lab from here, and your answers &amp; screenshots save only in this browser. To enable them, open this manual <strong>on the VM where Labtainers is running</strong>.</span>
<button class="conn-x" id="connX" type="button" aria-label="Dismiss this notice">&#215;</button>
</div>

<!-- #121 known-issues fast lane: a dismissable dropdown banner shown ONLY when a known issue is on file. -->
<div class="ki-banner no-print" id="kiBanner" hidden role="status" aria-live="polite">
<span class="ki-dot">&#9888;</span>
<span class="ki-body"><strong class="ki-title">Known issue:</strong> <span class="ki-text"></span></span>
<button class="ki-x" id="kiX" type="button" aria-label="Dismiss this known-issue notice">&#215;</button>
</div>
<button class="ki-pill no-print" id="kiPill" hidden type="button" title="Show the known-issue notice">&#9888;&#160;Known issue</button>
<script>(function(){
  // #121 known-issues fast lane. On load, fetch a tiny per-lab notes file LIVE from the public imodule
  // repo (the same raw host donlab self-updates from). Show a dismissable dropdown banner ONLY if an
  // active note exists. Pushing labs/known-issues/<lab>.json to the imodule repo (dist/publish-known-issues)
  // alerts students in minutes (raw CDN ~5-min cache) with NO image rebuild and NO smoke. Fails SILENT
  // offline, in-lab without egress, or on 404 (the normal no-issue state). Additive, never gates grading.
  var LAB="bootcamp";
  var LAB_REV=11;                     // #138: this manual's numeric revision, for version-scoped notes
  var IMOD="spencer-dollahite/imodule";
  var BRANCH=(window.DON_KI_BRANCH||"main");          // donlab/bridge may set "dev" for dev-channel testing
  var bucket=Math.floor(Date.now()/300000);           // 5-min cache-buster aligned to the raw CDN TTL
  var SRC="https://raw.githubusercontent.com/"+IMOD+"/"+BRANCH+"/known-issues/"+LAB+".json?_="+bucket;
  var ban=document.getElementById('kiBanner'), pill=document.getElementById('kiPill');
  if(!ban) return;
  function lsGet(k){try{return localStorage.getItem(k);}catch(e){return null;}}
  function lsSet(k,v){try{localStorage.setItem(k,v);}catch(e){}}
  function show(){ban.hidden=false; requestAnimationFrame(function(){ban.classList.add('ki-show');}); if(pill)pill.hidden=true;}
  function tuck(){ban.classList.remove('ki-show'); setTimeout(function(){ban.hidden=true;},400); if(pill)pill.hidden=false;}
  function active(notes){var now=Date.now();
    for(var i=0;i<notes.length;i++){var n=notes[i];
      if(!n||!n.summary)continue;
      if(n.until){var u=Date.parse(n.until); if(!isNaN(u)&&u<now)continue;}   // expired
      // #138: version scope. A note may declare `fixed_in` (the numeric revision the issue is fixed in);
      // suppress it on a manual AT OR PAST that revision. Older manuals ship without this check and keep
      // showing the note, which is intended: the note stays visible on the affected (pre-fix) versions and
      // disappears on the fixed one. Fail-open: a malformed fixed_in leaves the note shown.
      if(n.fixed_in!=null && typeof LAB_REV==='number' && isFinite(Number(n.fixed_in)) && LAB_REV>=Number(n.fixed_in))continue;
      return n;}
    return null;}
  var ctrl=null, to=setTimeout(function(){if(ctrl)try{ctrl.abort();}catch(e){}},6000);
  try{ctrl=new AbortController();}catch(e){}
  fetch(SRC,{cache:'no-store',signal:ctrl?ctrl.signal:undefined}).then(function(r){
    clearTimeout(to); if(!r.ok)throw 0; return r.json();
  }).then(function(data){
    var n=active((data&&data.notes)||[]); if(!n)return;
    var key='donki:'+LAB+':'+(n.id||'')+':'+(n.date||'');
    if(lsGet(key)==='1')return;                        // this exact note already dismissed by this viewer
    ban.querySelector('.ki-text').textContent=n.summary+(n.workaround?'  Workaround: '+n.workaround:'');
    // The note's own text is the whole message -- no tracker link (#137: don-range is private; a link
    // would be a dead sign-in wall for students). A `fix` field in a note file, if present, is ignored here.
    function dismiss(){lsSet(key,'1'); ban.classList.remove('ki-show'); setTimeout(function(){ban.hidden=true;},400); if(pill)pill.hidden=true;}
    var x=document.getElementById('kiX'); if(x)x.addEventListener('click',dismiss);
    if(pill)pill.addEventListener('click',function(){ if(ban.hidden)show(); else tuck(); });
    show();
    setTimeout(function(){ if(ban.classList.contains('ki-show'))tuck(); }, 9000);   // auto-tuck to the pill after ~9s
  }).catch(function(){ clearTimeout(to); /* offline / in-lab / 404 -> no banner, silent */ });
})();</script>

<div class="cw-overlay no-print" id="cwOverlay" hidden>
<div class="cw-modal cw-wide" role="dialog" aria-modal="true" aria-labelledby="cwTitle">
<button class="cw-close" id="cwClose" type="button" aria-label="Close">&#215;</button>
<h2 id="cwTitle">&#10003; Check Your Work</h2>
<div class="cw-cols">
<div class="cw-col">
<h3>Your progress <span class="cw-sub">— what you have checked off</span></h3>
<div id="cwProgress"></div>
</div>
<div class="cw-col">
<h3>Automated grading <span class="cw-sub">— from the <code>checkwork</code> command</span></h3>
<div class="cw-cmd"><button id="cwRunLive" type="button">Run live check now</button> &mdash; or run <code>checkwork bootcamp</code> in your lab terminal <button id="cwCopyCmd" type="button">Copy</button></div>
<div class="cw-live" id="cwLive">
<p class="cw-hint">Goals this lab assesses (run the live check for status):</p><ul class="cw-goals"><li>Built the ~/range practice workspace and the checklist files (navigation, brace expansion)</li><li>Edited a file in vim with text objects and search-and-replace</li><li>Logged a triage action with redirection and command chaining</li><li>Sliced the busiest source IP out of the auth log with a pipeline</li><li>Tuned the shell with an alias and a ~/.vimrc setting</li><li>Wrote a small runnable status script</li><li>(Unguided challenge) Found the credential-spray source that succeeded and the account it reached</li></ul></div>
</div>
</div>
<p class="cw-note"><strong>Note:</strong> the grader is automated and can misjudge an edge case; it is here to help you gauge your progress. If you're confident your work is correct and it disagrees, note it in your report and check with your instructor.</p>
</div>
</div>

<div class="wrapup-overlay no-print" id="wrapupOverlay" hidden>
<div class="wrapup-modal" role="dialog" aria-modal="true" aria-labelledby="wuTitle">
<div id="wuConfirm">
<h2 id="wuTitle">&#9873; Finish &amp; build your Lab Report</h2>
<p>When you finish, the manual will:</p>
<ol class="wu-steps-list">
<li>Run the automated <strong>checkwork</strong> so your report shows up-to-date grading.</li>
<li>Run <strong>stoplab</strong> &mdash; this <strong>stops the lab</strong> and packages your <code>.lab</code> submission.</li>
<li>Build and download your finished Lab Report with the fresh results.</li>
</ol>
<p class="wu-warn" id="wuWarn">Your lab will be stopped. Make sure you have saved your work and finished every task first.</p>
<p class="wu-offline" id="wuOffline" hidden>This manual is <strong>not attached to the lab VM</strong>, so the final checks and stoplab cannot run from here. You can download a draft now, or open this manual on the lab VM to finish properly.</p>
<div class="wu-actions">
<button id="wuGo" class="wu-primary" type="button">Finish &amp; build report</button>
<button id="wuDraft" class="wu-secondary" type="button">Just download a draft (don&rsquo;t stop the lab)</button>
<button id="wuCancel" class="wu-cancel" type="button">Cancel</button>
</div>
</div>
<div id="wuProgress" hidden>
<h2>Wrapping up&hellip;</h2>
<div class="wu-bar"><div class="wu-fill" id="wuFill"></div></div>
<ol class="wu-track">
<li id="wuStep-check"><span class="wu-mk"></span> Running checkwork</li>
<li id="wuStep-build"><span class="wu-mk"></span> Building your report &amp; gathering diagnostics</li>
<li id="wuStep-stop"><span class="wu-mk"></span> Stopping the lab &amp; packaging your submission</li>
</ol>
<div class="wu-status" id="wuStatus" aria-live="polite"></div>
<div class="wu-detail" id="wuDetail"></div>
</div>
<div id="wuDone" hidden>
<h2>&#10003; Report ready</h2>
<div class="wu-status" id="wuDoneMsg"></div>
<div class="wu-actions">
<a id="wuArchive" class="wu-secondary" href="#" hidden>&#11015; Download your .lab submission</a>
<button id="wuClose2" class="wu-primary" type="button">Close</button>
</div>
</div>
</div>
</div>

<div class="cw-overlay no-print" id="bearingsOverlay" hidden>
<div class="sa-modal" role="dialog" aria-modal="true" aria-labelledby="bearingsTitle">
<button class="cw-close" id="bearingsClose" type="button" aria-label="Close">&#215;</button>
<h2 id="bearingsTitle"><svg class="compass-ico" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true" style="vertical-align:-3px"><circle cx="12" cy="12" r="9"/><polygon points="12,12 15.2,8.8 12,14.5" fill="currentColor" stroke="none"/><polygon points="12,12 8.8,15.2 12,9.5" fill="currentColor" stroke="none" opacity="0.55"/></svg> Bearings &mdash; fcdpac</h2>
<div class="sa-tabs">
<button class="sa-tab active" type="button" data-sa="creds">Credentials</button>
<button class="sa-tab" type="button" data-sa="net">Network</button>
<button class="sa-tab" type="button" data-sa="people">Roster</button>
</div>
<div class="sa-panel" data-sa-panel="creds">
<p class="sa-hint">You're already logged in at each terminal &mdash; use these for <code>sudo</code> and any SSH logins.</p>
<table><thead><tr><th>Host</th><th>Username</th><th>Password</th></tr></thead><tbody>
<tr><td><code>hi-ws-it</code></td><td><code>rmorales</code></td><td><code>FirstWatch!2026</code> <button type="button" class="sa-copy" data-copy="FirstWatch!2026" title="Copy password" aria-label="Copy password"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg></button></td></tr>
</tbody></table>
</div>
<div class="sa-panel" data-sa-panel="net" hidden>
<div class="sa-viewtoggle no-print"><button type="button" class="sa-vt active" data-net-view="tables">Tables</button><button type="button" class="sa-vt" data-net-view="diagram">Diagram</button><button type="button" class="sa-vt" data-net-view="global">Global</button></div>
<div data-net-body="tables">
<table><thead><tr><th>Host</th><th>Address</th><th>Role</th></tr></thead><tbody>
<tr><td><code>hi-ws-it</code></td><td><code>10.10.10.42</code></td><td>workstation</td></tr>
</tbody></table>
<p class="sa-hint" style="margin-top:.9em">Network Segments</p>
<table><thead><tr><th>Segment</th><th>Subnet</th><th>Use</th></tr></thead><tbody>
<tr><td><code>userlan</code></td><td><code>10.10.10.0/24</code></td><td>FCD-PAC user workstation VLAN</td></tr>
</tbody></table></div>
<div data-net-body="diagram" hidden>
<div class="netdiagram">
<div class="netdiag-controls no-print">Show: <button type="button" data-diag="all">All</button> <button type="button" data-diag="none">None</button> <button type="button" data-diag="net" data-net="userlan">USERLAN</button></div>
<svg class="topo" viewBox="0 0 356 164" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg" role="img">
<g class="net-group" data-net="userlan">
<line class="bus" x1="152" y1="57" x2="330" y2="57"/>
<text class="netlabel" x="8" y="54">USERLAN</text>
<text class="netcidr" x="8" y="70">10.10.10.0/24</text>
<g class="host">
<rect class="hostbox" x="178" y="34" width="128" height="46" rx="6" fill="#3a6ea5"/>
<text class="hostname" x="242" y="53">hi-ws-it</text>
<text class="hostip" x="242" y="69">10.10.10.42</text>
</g>
</g>
</svg>
<script>(function(){var r=document.currentScript.closest('.netdiagram');function g(n){return r.querySelectorAll('.net-group[data-net="'+n+'"]');}function show(el,s){el.forEach(function(e){e.style.display=s?'':'none';});}r.querySelectorAll('[data-diag]').forEach(function(b){b.addEventListener('click',function(){var k=b.getAttribute('data-diag');if(k==='all'){r.querySelectorAll('.net-group').forEach(function(e){e.style.display='';});}else if(k==='none'){r.querySelectorAll('.net-group').forEach(function(e){e.style.display='none';});}else{var gs=g(b.getAttribute('data-net'));var hidden=gs[0]&&gs[0].style.display==='none';show(gs,hidden);}});});})();</script>
</div>
</div>
<div data-net-body="global" hidden>
<div class="sa-viewtoggle no-print" style="flex-wrap:wrap;gap:.4em;font-size:.8em"><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="land" checked> Land</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="cables" checked> Cables</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="choke"> Chokepoints</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="ixp"> IXPs</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="dc"> DC hubs</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="cloud" checked> Cloud</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="asn"> ASNs</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="rir"> RIR</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="ucc" checked> Cmds</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="bases"> Bases</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="dib"> DIB</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="commercial"> Commercial</label><label class="nt-lab"><input type="checkbox" class="nt-tog" data-nt="dod" checked> DoD</label></div><div class="sa-viewtoggle no-print" style="gap:.4em"><button type="button" class="sa-vt" id="nt-zin">+ Zoom</button><button type="button" class="sa-vt" id="nt-zout">&minus; Zoom</button><button type="button" class="sa-vt" id="nt-zreset">Reset</button><span class="sa-hint" style="align-self:center">drag &middot; scroll &middot; dbl-click</span></div>
<svg id="nt-bearings-svg" viewBox="0 0 1000 500" style="width:100%;height:auto;background:#0b1a26;border-radius:8px;display:block"></svg>
<p class="sa-hint" style="margin-top:.5em">Global network terrain &mdash; illustrative, as of 2026-10-08. Hover a cable or marker. &#9733; Guam is a key Pacific cable chokepoint. DoD-accredited gov cloud shown in pink; DISA anchor in red.</p>
</div>
</div>
<div class="sa-panel" data-sa-panel="people" hidden>
<table><thead><tr><th>Account</th><th>Name</th><th>Role</th></tr></thead><tbody>
<tr><td><code>rmorales</code></td><td>IT2 R. Morales</td><td>&mdash;</td></tr>
</tbody></table>
</div>
</div>
</div>

# Bootcamp: First Watch -- Finding Your Way Around the Command Line

<p class="meta">Fleet Cyber Detachment - Pacific (FCD-PAC) &bull; Operation SILENT REEF</p>

<div class="progress-wrap no-print" id="progwrap" title="Check off each section and question as you finish; your progress is saved in this browser.">
<div class="prog-version" title="Manual revision (bumped when this lab is promoted to students)">Revision: v0.0.011 20261112</div>
<div class="progress-head"><span id="proglabel">Complete 0/0 (0%)</span></div>
<div class="progress-bar"><div class="progress-fill" id="progfill"></div></div>
</div>

<p class="lab-estimate"><strong>Recommended Minimum Time:</strong> 60–90 min (a hands-on lab; the point is to build muscle memory, so type rather than skim). <span class="gloss info-i" tabindex="0" role="note" aria-label="About the recommended minimum time"><span class="info-glyph" aria-hidden="true">i</span><span class="gloss-pop"><span class="gloss-h">About this time</span><span class="gloss-d">Expertise, reading speed, and other variables shape how long this lab takes you; the figure is a recommended minimum, not a deadline.</span><span class="gloss-d">Each lab holds far more than a passing grade requires. I do not grade on raw completion alone. I care far more about your critical thinking, your writing, and your ability to communicate your justification and reasoning clearly.</span><span class="gloss-d">The lab offers more for those who are interested. Use your own time management to prioritize and execute with that in mind.</span></span></span></p>

## Scenario Brief

You have just checked aboard the Fleet Cyber Detachment - Pacific IT shop as the newest technician, and your workstation `hi-ws-it` is waiting. The later labs in this course assume you can find your way around a shell without thinking about it: move between directories, recall and fix a command instead of retyping it, and pull the one line you need out of a long log. This lab builds that muscle memory on your own seat. There is no adversary to fight today -- the work is learning to operate the seat itself so that in the next lab your attention is on the security problem, not on the keyboard.


**Your role:** New arrival to the FCD-PAC IT shop (IT technician, hi-ws-it) -- learning the seat.

<!-- FCD-PAC watch note (source only): a manual's own source may carry more than it shows. ctf{the_source_tells_on_you} -->
## Learning Objectives

- Find your bearings on a Linux seat: **`pwd`**, **`ls`** / `ls -a` / `ls -l`, **`cd`**, `cd -`, `cd ..`, and `cd` with no arguments.
- Create, read, and organize files: **`mkdir -p`**, **`touch`**, **`cp`**, **`mv`**, **`rm`**, **`cat`** / `less` / `head` / `tail`, and redirection (`>`, `>>`).
- Work faster, not harder: **history recall** (`Up`, `Ctrl+R`), **cursor shortcuts** (`Ctrl+A`/`Ctrl+E`, `Alt+B`/`Alt+F`, `Alt+.`, `Ctrl+W`/`Ctrl+U`/`Ctrl+K`), and **history expansion** (`!!`, `!$`, `!*`, `!N`, `!string`, `sudo !!`, `$(!!)`, `^old^new`).
- Edit at speed in **`vim`**: the insert commands (`i`/`I`/`a`/`A`/`o`), change and delete with **text objects** (`ciw`, `ciW`, `diw`, `ci'`) and the line changes `C` / `S`, **search** (`/`, `n`/`N`), **search-and-replace** (`:s`, `:%s/old/new/g`), **macros** (`q`…`q`, `@`), and leaving the editor (`ZZ`, `ZQ`, `:wq`, `:q!`).
- Compose commands: **brace expansion**, **`Tab`** completion, **aliases**, chaining with `&&` / `||`, and command substitution `$( )`.
- Slice text out of logs: the **pipe** `|`, **`grep`**, **`cut`**, **`sort`** / **`uniq`**, **`wc`**, and **`sed`**.
- Leave a tidy, graded end state in `~/range`, and turn in a Lab Report.

## Your bearings

You are the newest technician in the FCD-PAC IT shop (`rmorales`), sitting down at `hi-ws-it` for
the first time. Everything you need is on this one seat. There is no network to attack and no
adversary to chase today. The work is to get comfortable at the keyboard, because the labs that follow
in this course assume you already are.

On your screen you have three things:

- **This manual**, open in Firefox. Read a task, do it in the terminal, answer its question here.
- **A terminal.** The range arranges a terminal and this manual side by side; your exact layout depends on your seat. Open another terminal the usual way for your desktop if you want one.
- **The report tools.** Your answers save in this browser as you type. When you finish, export the
  **Lab Report** (top-right button) and stop the lab (**Actions ▸ stoplab** in this manual) to collect your work.

And one thing I expect you to bring yourself: an **AI assistant of your choice, open in a separate
window**, used as a copilot while you work, the way you would on the job. Ask it what a command does,
how to approach a task, or why something failed. It is another tool, so your judgment stays in charge:
read and understand any command it hands you before you run it (the cautions in the box below apply to
its suggestions as much as to the copy buttons), because the terminal is the ground truth that catches a
wrong or destructive answer.

A little practice data has been seeded into your home directory under `~/range-data/` (some logs and
a roster). You will build your own working area under `~/range/` as you go. That `~/range` folder is
what is graded, so keep your work there.



<div class="callout"><span class="clabel">On the copy buttons</span> I decided not to force you to type every command; each code block in this manual has a copy button,
and you are welcome to use it. But if you are new to the command line, type the commands yourself for
a while. That is how the shapes of things become familiar. Either way, copy-and-paste only
<em>after</em> you have read the command and understand what it is about to do. I promise I have not
slipped a destructive command in anywhere to trick you or prove a point (or have I?). Look for
<code>rm -rf</code>, redirects that overwrite, anything run with <code>sudo</code> you did not
expect, and pipes into a shell, and refuse to run what you do not understand. You know your
own learning style and where you stand; the point of these labs is much more than Linux commands.
The commands matter, but they are a means to a more important end. That end is the <strong>management of risk</strong>, which <strong>Lab 1</strong> defines and makes the lens the later labs are read through; today, just get comfortable at the keyboard.</div>





<div class="callout"><span class="clabel">Using AI in this course</span> I expect you to use an AI assistant, and to use it well. Keep a current one of your choice beside you;
the field moves quickly, so pick what is strong now and revisit the choice as it changes. Its best use
is as a partner to your thinking rather than a substitute for it. Have it challenge a conclusion you
reached, explain an error, surface a misconception, or act as a demanding critic of your own writing
after you have done the thinking and the draft (good prompts for that circulate online, worth a search).
Hand it the toil and keep the thinking this course exists to build in you.

Where course or NPS policy is explicit, follow it: an assignment that says "no AI" means exactly that.
Elsewhere the call is yours, and it rewards a deliberate plan for when and how you use the tool. Ask
whether the point of a task is the artifact or the process of producing it, because both exist and they
call for different uses of something this capable. Research the best practices here, and ask your
instructor for their read; views differ and the ground is still moving.

One straight word on integrity. Taking the easy way cheats the one person it is meant to serve, which is
you, and the department knows this space and what AI output tends to look like, so "getting away with it"
is mostly a story you tell yourself. The real loss is the reasoning you skipped. Use the tool to go
further into the work.

A note on scope. These labs mostly teach how to <strong>manage</strong> AI as an IT capability, governed like any
other tool, with attention to the data it touches and where that data goes. Using AI well yourself is a
related skill this box and your own practice build, rather than one the labs grade.

Two practical notes. The Microsoft Copilot tied to your NPS account can answer against your own Teams
recordings and OneDrive documents, which is useful for reviewing a recorded lecture or a shared handout.
And the NPS Cyber Club offers a starting set of custom instructions that makes an assistant teach rather
than hand over answers; copy it into your assistant's custom-instruction or project settings and adjust
it to suit you:</div>



```
Your job is to provide expert-level education in the areas of computer science, cybersecurity, and artificial intelligence to United States military and DoD civilian students (and allies). You will use the Socratic method and other engaging best-practices to help guide the student along their learning and research journey without just providing easy answers. You will provide a wide spectrum of ideas. You will challenge the student. You will use reputable sources for your information. You will point the student to other resources where they can get help. You will use a professional and engaging tone when interacting with the student. You will pro-actively create diagrams to help illustrate concepts where appropriate. You will pro-actively suggest ways in which the student can improve their learning approach. You will not take on a human persona. You are an AI bot. You will encourage critical thinking. You will look for opportunities to red team and steel-man different arguments to encourage deeper understanding of the pros and cons of various technologies and theories. You will challenge assumptions. You will ask clarifying questions. You will point out common misconceptions and correct them. You are aware of and sensitive to the current national security and geopolitical environment. You will account for budgetary and other resource constraints when discussing options.
```

<span data-checkpoint="l0-checkin" hidden></span>

## Task 0 - Orientation: the seat, the report, and screenshots

Before the shell, get oriented to how a lab works, because it is the same in the labs that follow.

1. **The manual is interactive.** Each task has a question box; type your answer and it saves in this
   browser. The progress bar at the bottom left tracks what you have finished.
2. **Check your work as you go.** The **Actions** menu (top of the page) has **checkwork**, which
   runs the lab's graders and tells you which objectives are met so far. Use it whenever you want a
   read on where you stand.
3. **Finish with `stoplab`.** When you are done, use **Actions ▸ stoplab** at the top of this manual, or run
   this in a terminal on your lab VM:

   ```
   stoplab bootcamp
   ```

   `stoplab` is a command of the lab VM, not of the seat: if the prompt in front of you reads
   `rmorales@hi-ws-it`, you are inside the seat, and the command is not found there. Press `Ctrl-b d`
   to detach from the lab layout and get the VM's own prompt, or use the button. Either way, that collects the work you did inside the seat (the files you created and your command history)
   into a `.lab` archive under `~/labtainer_xfer/bootcamp/`. You turn in two things: your **Lab
   Report** (the top-right export) and that **`.lab`** archive.



<div class="callout systems"><span class="clabel">What is actually running here</span> Your seat <code>hi-ws-it</code> is a Linux container on your lab VM, a lightweight, self-contained machine
that the range built for you. <code>donlab</code> fetched the lab, started the container, opened this manual, and
laid out the windows. When you run <code>checkwork</code> it runs graders against the end state inside
the container; <code>stoplab</code> shuts the seat down and packages what you did for the instructor.
You do not need to manage any of that today. It is background, so that later you can think about
the security problem and not the plumbing.</div>



**Screenshots.** You can add a screenshot to any answer. The range installs **Flameshot** on your
desktop for this: press <kbd>Print</kbd> (or <kbd>Super</kbd>+<kbd>p</kbd>), drag a box around what
you want, add an arrow or highlight from the toolbar, and click save. The image lands in
`~/labtainer_xfer/screenshots/`, and you attach it with the *Attach screenshot(s)* control under a
question. Inside the terminal, the `shot` command is a plainer fallback.



<div class="callout"><span class="clabel">A screenshot supports an answer; it does not replace one</span> Adding a screenshot is fine, and an annotated one, an arrow or a box on the line that matters
 is often clearer than the raw capture. It supports your answer; it does not replace it. Write
out what the screenshot shows and what you conclude from it. Do not assume I will find the right value
in the image, or will know that you saw it. A screenshot standing alone as an answer is rarely enough.</div>



## Task 1 - Where am I, and what is here?

The first two questions at any seat are *where am I* and *what is here*.

1. Print your current directory, then list what is in it (including hidden files, and in long form):

   ```
   pwd
   ls
   ls -a
   ls -l
   ```

   `pwd` prints the working directory. `ls` lists files; `-a` shows hidden entries (names beginning
   with a `.`, used for configuration like `.bashrc`), and `-l` gives a long listing with
   permissions, owner, size, and time. You can combine flags: `ls -la`.

2. Look at the seeded practice data and get a feel for moving around:

   ```
   ls -l ~/range-data
   cd ~/range-data
   pwd
   cd -
   cd
   pwd
   ```

   `cd ~/range-data` moves you there; `cd -` returns you to where you were; `cd` with no arguments
   takes you home. Remember that last one: however deep you wander, `cd` alone brings you back.



<div class="callout legacy"><span class="clabel">Absolute vs. relative paths</span> An <strong>absolute</strong> path starts from the root of the filesystem: <code>/home/rmorales/range-data</code>.
A <strong>relative</strong> path starts from where you already are: <code>range-data</code> or
<code>./range-data</code>. Both name the same place from different starting points. <code>.</code> is the
current directory, <code>..</code> is the parent, and <code>~</code> is your home. Older habits lean on
absolute paths for scripts (they do not depend on where you happen to be) and relative paths at the
keyboard (they are shorter).</div>



<div class="inq" data-q="t1here"><p>Run <code>pwd</code> from your home directory and paste what it prints. Then, in one sentence, say what <code>cd</code> with no arguments and <code>cd -</code> each do.</p>
<textarea data-ans="t1here" data-check="/home/rmorales" data-hint="a pasted path and one sentence on cd" placeholder="A pasted path and one sentence. Saved in your browser; included in your Lab Report."></textarea>
<div class="inq-tools no-print"><button type="button" class="inq-check">Check my answer</button><span class="inq-result"></span>
<details class="inq-answer"><summary>Show the correct answer (after you've written yours)</summary><div>From home, <code>pwd</code> prints <code>/home/rmorales</code>. <code>cd</code> with no arguments returns you to your home directory regardless of where you currently are.</div></details></div></div>

## Task 2 - Build your working area (create, read, organize)

Now make a place to work. You will build a small triage workspace and put a few files in it.

1. Create the workspace and three checklist files in one step, using **brace expansion** so you type
   the shared part once:

   ```
   mkdir -p ~/range/checklists
   touch ~/range/checklists/{network,auth,dns}.txt
   ls ~/range/checklists
   ```

   `mkdir -p` creates parent directories as needed and does not complain if they already exist. The
   `{network,auth,dns}.txt` expands to three filenames before `touch` runs, so one command creates
   all three. Confirm with `tree ~/range` if you like the picture.

2. Write and read a file, to see redirection:

   ```
   echo 'First watch: getting my bearings' > ~/range/notes.txt
   echo 'Seat: hi-ws-it' >> ~/range/notes.txt
   cat ~/range/notes.txt
   ```

   `>` sends output to a file, overwriting it; `>>` appends. `cat` prints the whole file; for a long
   file use `less` (press `q` to quit), or `head` / `tail` for the first or last lines.



<div class="callout"><span class="clabel">Some commands succeed silently</span> <code>mkdir</code>, <code>touch</code>, <code>cp</code>, and <code>mv</code> usually print nothing when
they work, no output means success. Errors are printed when something goes wrong. Getting used
to the quiet is part of trusting the shell; when in doubt, follow a changing command with a reading one
(<code>ls</code>, <code>cat</code>) to confirm the result.</div>



This builds the first graded artifact: the `~/range/checklists` directory with `network.txt`,
`auth.txt`, and `dns.txt`.

## Task 3 - Work faster: history and cursor shortcuts

You rarely type a command once. The shell remembers what you ran and lets you recall and edit it
instead of retyping. Practice these on the commands you have already run.

| Shortcut | Action |
|----------|--------|
| `Up` / `Down` | Move through recent commands |
| `Ctrl+R` | Reverse-search your history (type a few letters of an old command) |
| `Ctrl+A` / `Ctrl+E` | Jump to the start / end of the line |
| `Alt+B` / `Alt+F` | Move back / forward one word |
| `Alt+.` | Insert the last argument of the previous command (press again to walk back through earlier commands' last arguments) |
| `Ctrl+W` | Delete the word before the cursor |
| `Ctrl+U` / `Ctrl+K` | Delete to the start / end of the line |
| `Tab` | Complete a command or path |

1. Recall a command instead of retyping it. Press `Up` a few times to walk back through what you ran,
   then `Ctrl+R` and type `check` to find your `ls ~/range/checklists` command. Press Enter to run it.
   (Do this in the terminal where you have been working; a terminal you just opened starts with an empty history.)
2. Edit in place. Type (do not run yet):

   ```
   echo 'incident triage in progres'
   ```

   Notice the typo. Use `Ctrl+A` to jump to the start, `Alt+F` to move forward by words, fix
   `progres` to `progress`, then run it; it should print `incident triage in progress`. The rule for this task: fix mistakes with the cursor keys,
   do not clear the line and retype.

3. **History expansion** is the fastest recall of all. Try each and read what it does; paste them one at a time, not as one block, so you can read each expansion before it runs:

   ```
   ls ~/range/checklists
   !!            # rerun the previous command verbatim
   echo !$       # !$ = the LAST argument of the previous command
   echo !*       # !* = ALL arguments of the previous command
   !echo         # rerun the most recent command that started with "echo"
   history       # numbered list of your commands
   ```

   `!N` reruns command number `N` from `history`. `sudo !!` reruns your last command with `sudo` in
 front: useful the moment a command fails for lack of privilege. And `^old^new` reruns the
   previous command with the first `old` replaced by `new`:

   ```
   cat ~/range/notes.txt
   ^notes.txt^checklists/auth.txt
   ```

   The rerun prints nothing: `auth.txt` was created empty in Task 2. The point is that `^old^new` rebuilt the command correctly, which you can see in the echoed command line.

4. Two more that save real typing. `Alt+.` inserts the **last argument** of the previous command right
   at the cursor, where you can edit it, which is often handier than `!$` because you see it before you
   run it; press `Alt+.` again to reach back through earlier commands. And `$(!!)` substitutes the
   **output** of the previous command into a new one, when what you want next is to act on what the
   last command just printed:

   ```
   ls -d ~/range/checklists         # prints the path
   cd $(!!)                         # cd into whatever that last command printed
   ```

   `cd` prints nothing when it works; run `pwd` to confirm you landed in `~/range/checklists`.



<div class="callout human"><span class="clabel">Speed is a safety feature, up to a point</span> Recalling and editing a command is faster and less error-prone than retyping a long one from memory.
But the same speed that helps you also helps you rerun the wrong thing quickly, <code>!!</code>
and <code>sudo !!</code> rerun whatever was last, even if that was a mistake. Glance at what you are
about to run. The habit of reading before pressing Enter is what keeps the speed from turning on you.</div>





<div class="callout case"><span class="clabel">GitLab.com, 2017</span> On 31 January 2017 a GitLab engineer repairing database replication ran a recursive delete on the
PostgreSQL data directory of the <strong>primary</strong> host, believing it was the secondary. About
300 GB of production data was gone before the command was stopped seconds later. The post-mortem also
records that several of the intended backup mechanisms were not working when they were needed. The
command was valid; the failure was a shell that did not make the target host obvious and a destructive
command run without confirming where it would run. Read <code>hostname</code> and <code>pwd</code>
before you press Enter on an <code>rm</code>, and test the recovery path before you need it.
<em>Source: GitLab, "Postmortem of database outage of January 31" (2017).</em></div>



## Task 4 - Edit at speed: vim

You will edit files on every seat in this course, often over a slow remote session where a mouse is
not an option. `vim` is on every host here, so it is the editor the course assumes. Its power is that
you edit with the home-row keys instead of arrows and menus; the cost is that you must know which
**mode** you are in.

Expect Task 4 to take longer than Tasks 1-3; the macro step near the end is the stretch, so pace
yourself against the lab's time estimate.

- **Normal mode** (where `vim` starts) treats keys as commands: move, delete, change, search.
- **Insert mode** types literal text. You enter it with one of the commands below and leave it with
  `Esc`. When in doubt, press `Esc` to get back to Normal mode.

Enter Insert mode where you need it, rather than arrowing to the spot first:

| Key | Enters insert... |
|-----|------------------|
| `i` / `a` | before / after the cursor |
| `I` / `A` | at the first non-blank / at the end of the line |
| `o` / `O` | on a new line below / above |

1. Make a scratch file to practice on. Type the typos and placeholders exactly as shown; you will fix
   them with the commands that follow:

   ```
   cat > ~/range/vim-drill.txt <<'EOF'
   host: hi-ws-XX
   analyst: 'jdoe'
   role: it-tech/tmp
   status: getting bearings DRAFT
   check netwrok
   check netwrok
   check netwrok
   EOF
   vim ~/range/vim-drill.txt
   ```

2. **Change and delete by text object.** A text object is a span `vim` understands as a unit: `iw`
   is the *inner word*, `iW` the *inner WORD* (whitespace-delimited, so it keeps punctuation),
   `i'` the text *inside single quotes*. Combine an operator (`c` change, `d` delete) with an object:

   - Line 1: move onto `XX` (type `/XX` then `Enter` to jump there) and press `ciw`, type `it`,
     `Esc`. `ciw` replaced the inner word `XX` with `it` &mdash; `host: hi-ws-it`.
   - Line 2: move onto the quoted value and press `ci'`, type `rmorales`, `Esc`. `ci'` replaced only
     what was inside the quotes &mdash; `analyst: 'rmorales'`.
   - Line 3: move onto `it-tech/tmp` and press `ciW`, type `it-technician`, `Esc`. `ciW` took the
     whole WORD including the `/`, which `ciw` would have stopped at.
   - Line 4: move onto `DRAFT` and press `diw`. `diw` deleted the inner word and left the rest.
     (`daw`, *delete a word*, also removes a surrounding space if you want the gap closed.)

   The pattern generalises: `c`/`d` + `i`/`a` + an object (`w`, `W`, `'`, `"`, `(`, `{`, `t` for an
   HTML/XML tag). `ci"`, `di(`, `cit` all work the same way. This is one of the biggest speedups in
   `vim`: you name *what* to change, not how many characters.

3. **Change whole lines.** `C` changes from the cursor to the end of the line; `S` changes the entire
   line (same as `cc`). On line 4, press `I` to jump to the start of the line, then `Esc`; press `A`
   to jump to the end, then `Esc` again; `I` and `A` put you in Insert mode at the line's edges without arrowing. Now, from Normal mode, leave
   line 4 reading `status: ready`: press `S`, type `status: ready`, `Esc`.

4. **Search, then replace across the file.** `/text` searches forward (`?text` backward); `n` repeats
   the search, `N` repeats it the other way. To change every occurrence at once, use substitution:

   ```
   :%s/netwrok/network/g
   ```

   `:%s` runs over the whole file (`%`), `s` substitutes, `/g` catches every match on each line (not
   just the first). It fixes all three `netwrok` lines in one stroke. Scope and confirmation are
   worth knowing: `:s/old/new/` acts on the current line only, and adding `c` (`:%s/old/new/gc`)
   asks you to confirm each change with `y`/`n`.

5. **Record a macro for a repetitive edit.** When a change is too shaped for `:s` but you must make it
   on many lines, record the keystrokes once and replay them. Put the cursor on the first `check`
   line and:

   - `qa` &mdash; start recording into register `a`.
   - `A` ` [verified]` `Esc` `j` `0` &mdash; append the tag, leave Insert mode, drop to the next line,
     return to its start.
   - `q` &mdash; stop recording.
   - `@a` replays the macro (tagging the second line); `@@` repeats the last macro (the third). `3@a`
     would run it three times.
   - If the recording came out wrong, press `u` to undo until the line is back, then re-record with `qa`.

6. **Leave the editor.** From Normal mode:

   | Keys | Effect |
   |------|--------|
   | `ZZ` (`Shift+Z` `Shift+Z`) | write the file and quit |
   | `ZQ` (`Shift+Z` `Shift+Q`) | quit and **discard** changes |
   | `:wq` then `Enter` | write and quit (the typed form of `ZZ`) |
   | `:q!` then `Enter` | quit discarding changes (the typed form of `ZQ`) |
   | `:w` / `:q` | write without quitting / quit (refuses if there are unsaved changes) |

   Save your drill file with `ZZ`. This builds the second graded artifact: `~/range/vim-drill.txt` with the
   placeholders and typos corrected.



<div class="callout"><span class="clabel">Modes are the whole game</span> Most early <code>vim</code> frustration is typing a command while in Insert mode, or typing text while in Normal
mode. There is one cure: when a keystroke does something strange, press <code>Esc</code> and look at
the bottom-left &mdash; <code>-- INSERT --</code> means your keys are text, a blank line means they are
commands. The muscle memory of tapping <code>Esc</code> before a command is worth building early.</div>



<div class="inq" data-q="t4_vim"><p>Name one edit from this task you would reach for <code>ciw</code> to make and one you would reach for <code>:%s///g</code> to make, and say in a sentence what distinguishes the two situations (one spot versus many, shaped versus uniform).</p>
<textarea data-ans="t4_vim" placeholder="A ciw job, a :%s job, and what tells them apart. Saved in your browser; included in your Lab Report."></textarea></div>

## Task 5 - Compose commands: chaining, aliases, substitution

1. **Chain** commands so one runs only if the last succeeded. Log a triage action into your workspace:

   ```
   mkdir -p ~/range/logs && echo 'checked network' >> ~/range/logs/actions.log && cat ~/range/logs/actions.log
   ```

   `&&` runs the next command only if the previous one succeeded; `||` runs the next one only if the
   previous one failed. Chaining `mkdir` then the append then the `cat` makes setup, action, and
   confirmation one deliberate step. This creates the third graded artifact: `~/range/logs/actions.log`
   containing your logged action.

2. **Command substitution** drops the output of one command into another. Build a one-line status:

   ```
   echo "summary: $(ls ~/range/checklists/*.txt | wc -l) checklists in $(pwd)"
   ```

   `$( ... )` runs the inner command and substitutes its output, so the count and the directory are
   filled in live rather than hardcoded.

3. **Aliases** name a command you run often. Add one to your shell config so it survives new
   terminals, and give yourself a `.vimrc` setting while you are editing dotfiles:

   ```
   echo "alias ll='ls -lah'" >> ~/.bashrc
   echo "alias lcheck='ls -lah ~/range/checklists'" >> ~/.bashrc
   echo "set number" >> ~/.vimrc
   source ~/.bashrc
   alias lcheck
   ```

   `source ~/.bashrc` re-reads the config in your current shell so the alias works now. This builds
   the fourth graded artifact: an alias in your shell config and a setting in `~/.vimrc`.



<div class="callout"><span class="clabel">Dotfiles are how the seat remembers you</span> Files like <code>.bashrc</code> and <code>.vimrc</code> are read when a shell or editor starts, so the
aliases and settings you put there come back each session. That is the difference between a one-off
convenience and a habit the seat keeps for you. Later in the course you will carry a shared
<code>.vimrc</code> and tmux config for exactly this reason.</div>



<div class="inq" data-q="t4_unintended"><p><strong>Unintended consequences.</strong> A change you made in this task keeps taking effect after the moment you made it. Name two consequences of that persistence that would not be visible the day you made the change, and one way you would check for each.</p>
<textarea data-ans="t4_unintended" placeholder="Two downstream consequences and a check for each. Saved in your browser; included in your Lab Report."></textarea></div>

<div class="inq" data-q="x_predict"><p><strong>Predict first.</strong> Before you run the busiest-source pipeline in Task 6 step 4 (<code>cut &hellip; | sort | uniq -c | sort -rn</code>), predict what it will produce and which tools and options you expect to need. The grade is for the reasoning, not for guessing right.</p>
<textarea data-ans="x_predict" placeholder="Your prediction and reasoning. Saved in your browser; included in your Lab Report."></textarea></div>

## Task 6 - Slice text out of logs

The real leverage of the shell is pulling the one line you need out of a long file. Your practice
data has a small authentication log at `~/range-data/auth.log`. Each line begins with a source IP.

1. Look at it, and get its size:

   ```
   head ~/range-data/auth.log
   wc -l ~/range-data/auth.log
   ```

   `head` shows the first lines (`tail` the last, `tail -f` follows a live log). `wc -l` counts
   lines.

2. **Search** with `grep`. Count the failed authentications:

   ```
   grep 'failure' ~/range-data/auth.log
   grep -c 'failure' ~/range-data/auth.log
   grep -v 'failure' ~/range-data/auth.log
   ```

   `-c` counts matching lines instead of printing them; `-v` inverts the match (lines that do *not*
   contain the pattern); `-i` would make it case-insensitive.

3. **Cut** a column. The IP is the first space-delimited field:

   ```
   cut -d' ' -f1 ~/range-data/auth.log
   ```

   `-d' '` sets the delimiter to a space and `-f1` selects the first field. For a colon-delimited
   file like the seeded roster, `cut -d':' -f1 ~/range-data/roster.txt` pulls the first column.

4. **Rank** the busiest source. Sort the IPs so duplicates are adjacent, count them with `uniq -c`,
 and sort those counts high to low. Save the result. This is the fifth graded artifact:

   ```
   cut -d' ' -f1 ~/range-data/auth.log | sort | uniq -c | sort -rn > ~/range/top-sources.txt
   cat ~/range/top-sources.txt
   ```

   Read the pipeline left to right: `cut` extracts the IPs, `sort` groups identical ones, `uniq -c`
   collapses each group to one line with its count, and `sort -rn` orders those counts numerically,
   largest first, so the busiest source is at the top. `sort` has to come before `uniq` because
   `uniq` only collapses lines that are already next to each other.



<div class="callout systems"><span class="clabel">This is the shape of log analysis</span> The pattern <em>extract a field &rarr; sort &rarr; count &rarr; rank</em> is one you will use in later labs that touch a log: top talkers in a firewall log, most-hit URLs in a web log, the account
with the most failed logins in an auth log. The commands change a little; the shape does not. Today you
are practicing it on ten lines so that later it works the same on six million.</div>



5. **`sed`** transforms a stream. The log server has moved; rewrite an address in the seeded config
   (to the screen, not in place, so you can see it first):

   ```
   sed 's/192.168.1.100/10.50.1.200/g' ~/range-data/log_config.txt
   ```

   `s/old/new/` replaces the first match on each line; the trailing `g` replaces all matches on a
 line; `sed -i` would edit the file in place. Look before you use `-i`, an in-place edit
   overwrites the original.

<div class="inq" data-q="t5top"><p>Paste the first line of <code>~/range/top-sources.txt</code> and name the busiest source IP. In one sentence, explain why <code>sort</code> comes before <code>uniq</code> in the pipeline.</p>
<textarea data-ans="t5top" placeholder="A pasted line, the IP, and one sentence. Saved in your browser; included in your Lab Report."></textarea>
<div class="inq-tools no-print"><span class="inq-result"></span>
<details class="inq-answer"><summary>Show the correct answer (after you've written yours)</summary><div>The top line shows the highest count next to the busiest source IP. <code>sort</code> comes before <code>uniq</code> because <code>uniq -c</code> only collapses and counts lines that are already adjacent, so the input has to be sorted first for the counts to be right.</div></details></div></div>

<div class="inq" data-q="x_effects"><p><strong>What else just changed.</strong> A command you run once and read differs from one saved in a script that runs unattended. Name a consequence of that difference, if any, and one habit that limits the blast radius.</p>
<textarea data-ans="x_effects" placeholder="A consequence of the difference and one habit. Saved in your browser; included in your Lab Report."></textarea></div>

## Task 7 - Write a tiny script

A script is a file of the commands you just learned, run in order. Turn your status line into
something you can run again. This is the last graded artifact.

1. Create `~/range/status.sh` with your editor (`vim ~/range/status.sh`) or with a here-document:

   ```
   cat > ~/range/status.sh <<'EOF'
   #!/bin/bash
   # First-watch status: how much have I set up, and where am I?
   echo "summary: $(ls ~/range/checklists/*.txt 2>/dev/null | wc -l) checklists; $(wc -l < ~/range/logs/actions.log 2>/dev/null) actions logged"
   EOF
   ```

2. Make it runnable and run it:

   ```
   chmod +x ~/range/status.sh
   ~/range/status.sh
   ```

   `chmod +x` sets the execute permission so the shell will run the file. The `#!/bin/bash` first
   line (the "shebang") tells the system which interpreter to use.



<div class="callout"><span class="clabel">A script is just yesterday's commands, saved</span> There is no line between "using the shell" and "scripting", a script is the commands you already
ran, written down so you do not have to remember them next time. Each command in this file is one you
used earlier in the lab. When a task starts to repeat, that is the signal to save it as a script.</div>





<div class="callout adversary"><span class="clabel">The adversary has a shell too</span> An intruder who lands on a box has the same prompt you just used. With only the commands from this lab, what are the first three things they would run to learn where they are and what they can reach?</div>



<div class="inq" data-q="x_redteam"><p><strong>The adversary's first moves.</strong> Name the commands an intruder on this seat would run first and what each would reveal. Then: which would leave a trace a defender could find, if any.</p>
<textarea data-ans="x_redteam" placeholder="Your commands and reasoning. Saved in your browser; included in your Lab Report."></textarea></div>

> **Setup note (transcribed, unverified):** your starter files are under `~/range/`.

<div class="inq" data-q="path-ref_check"><p><strong>Check it before you trust it.</strong> A transcribed note above tells you where your starter files are. Verify that claim against the filesystem before you rely on it, then record what you found and the rule it taught you.</p>
<textarea data-ans="path-ref_check" placeholder="The value you settled on, the source you checked, and how you confirmed it. Saved in your browser; included in your Lab Report."></textarea>
<div class="inq-tools no-print"><details class="inq-answer"><summary>Show the correct answer (this locks your answer)</summary><div>Run <code>ls ~</code> and <code>ls ~/range-data</code> to see where the files actually are. The seeded practice data is under <code>~/range-data/</code>; <code>~/range/</code> is the working area you build in this lab, not where the starter files live, so the transcribed note is wrong. The rule: confirm a path against the filesystem before trusting a value someone transcribed for you.</div></details></div></div>

<div class="helpdesk no-print"><details class="helpdesk-box"><summary class="helpdesk-btn">Tap Shipmate on Shoulder</summary><p class="helpdesk-tip">Run ls to see where the files actually live; the walkthrough is a transcription and the directory name is exact.</p></details></div>

<div class="inq" data-q="x_friction"><p><strong>When a command surprised you.</strong> If a command did not do what you expected, name it, what you assumed it would do, what it actually did, and how you figured out the difference.</p>
<textarea data-ans="x_friction" placeholder="The command, your assumption, what it did, and how you found out. Saved in your browser; included in your Lab Report."></textarea></div>

<div class="inq" data-q="t6_gradernote"><p><strong>Grading fallback (optional).</strong> If an automated check for this task did not register your work, describe what you did here &mdash; the commands and config you changed, and the evidence you saw &mdash; so it can be credited by hand.</p>
<textarea data-ans="t6_gradernote" placeholder="Only if an auto-check missed your work: what you did, where, and how you verified it. Saved in your browser; included in your Lab Report."></textarea></div>

## Task 8 (Unguided Challenge) - Find the quiet one

<span data-checkpoint="l0-breach-found" hidden></span>

The rest of this lab walked you to each answer. This one does not: you have the moves, and the method is
yours to choose.

A fuller night of authentication traffic has been seeded at `~/range-data/watch-auth.log`. Somewhere in it,
one source did more than hammer the door, it got in. It is **not** one of the routine internal logins, and
it is **not** the loudest brute-forcer (the source with the most failed attempts never succeeded). Find the
source that broke in, and the account it reached.

Write your finding to `~/range/breach-finding.txt`: the source IP on the first line, the account it reached
on the second.

```
198.51.100.x        <- the source IP (this is the FORM, not the answer)
<the account>
```

The automated check reads this file.

<div class="inq" data-q="l0challenge"><p>Give the source IP and the account it reached, and the pipeline you used to find it. Why is the busiest source by failed attempts <em>not</em> the one that matters, and what single feature set the real break-in apart from the routine logins and from the noisy brute-forcer?</p>
<textarea data-ans="l0challenge" placeholder="The IP, the account, your pipeline, and why busiest != breach. Saved in your browser; included in your Lab Report."></textarea>
<div class="inq-tools no-print"><details class="inq-answer"><summary>Show the correct answer (this locks your answer)</summary><div><p>The source is <code>198.51.100.44</code> and the account it reached is <code>svc-backup</code>. One route to it: list the sources that have any <code>Accepted</code> line, then ask which of those tried a spread of <em>different</em> usernames rather than logging one person in:</p>
<pre>grep Accepted ~/range-data/watch-auth.log | grep -oE 'from [0-9.]+' | sort -u     # who got in at all
# for a suspicious external source, how many DISTINCT usernames did it try?
grep '198.51.100.44' ~/range-data/watch-auth.log | grep -oE 'for (invalid user )?[a-z-]+' | sed 's/invalid user //' | sort -u
grep '198.51.100.44' ~/range-data/watch-auth.log | grep Accepted      # the one that worked</pre>
<p>The busiest source by failed attempts, <code>203.0.113.7</code>, is a loud brute-forcer that never succeeded: volume is not compromise. The routine logins come from internal addresses, each for one user. The break-in is the combination the other two lack, many different usernames tried (a spray) ending in a single success. That is the shape of a credential spray that found a weak account, and it is the line that actually matters. Counting is where this lab started; deciding which count matters is the work.</p></div></details></div></div>

<div class="inq" data-q="l0challenge_gradernote"><p><strong>Grading fallback (optional).</strong> If the automated check did not register your finding, describe what you found and the pipeline you used, so it can be credited by hand.</p>
<textarea data-ans="l0challenge_gradernote" placeholder="Only if the auto-check missed your work: your finding and how you got it. Saved in your browser; included in your Lab Report."></textarea></div>

## Task 9 - Debrief

<span data-checkpoint="l0-seat-ready" hidden></span>

You now have the moves the rest of the course leans on. Before you stop the lab:

- Run **checkwork** (Actions menu) and confirm your objectives are met. Each one maps to an artifact
  you built in `~/range`.
- Answer the **Questions** below and complete the **Independent Research / Experiment** and **What You
  Learned** boxes.
- Export your **Lab Report** and stop the lab (**Actions ▸ stoplab**, or `stoplab bootcamp` in a VM
  terminal, as in Task 0). Turn in both.

The next lab has a security problem in it. The command line will be your tool for that problem, not
the subject. The more of this that is automatic for you, the more attention the next lab's security problem will get.

<div class="inq" data-q="x_unintended"><p><strong>The Law of Unintended Consequences.</strong> Take the main control, change, or decision you made in this lab. First, enumerate the unintended consequences it is likely to produce. For each, say how you would address it, and what new consequences your mitigation might itself create. Then stretch past the likely: name one low-probability, high-impact "black swan" consequence outside the obvious set.</p>
<textarea data-ans="x_unintended" placeholder="This lab's main control/change; its likely unintended consequences; your mitigations and their own second-order consequences; plus one unlikely, high-impact "black swan". Saved in your browser; included in your Lab Report."></textarea>
<div class="inq-tools no-print"><details class="inq-answer"><summary>Show the correct answer (this locks your answer)</summary><div>There is no single key here; the grade is on the quality of your reasoning. A strong answer treats a control as a change to a living system rather than a fix in isolation, and names consequences across that system, not only the effect you intended: users routing around friction, a boundary that breaks a legitimate workflow, a log that floods the SIEM, a new dependency you created, a cost quietly shifted to another team. For each, pair a mitigation with its own second-order effect, because a mitigation is itself a change that lands somewhere, tightening a control pushes users to shadow workarounds, adding redundancy adds attack surface and maintenance, more logging raises noise and storage cost, an exception you grant tends to become the one nobody revokes. That second order is the point of the law: consequences cascade and the fix is rarely free, so you plan for the next effect, not just the first. The black swan is deliberately low-probability, high-impact, and hard to foresee, and imagining one is the exercise: a control whose failure mode nobody modeled, a safety interlock that strands an operator mid-crisis, a monitoring agent that becomes the thing that takes down what it monitors, a "temporary" change that turns load-bearing and fails years later under conditions nobody anticipated. The discipline is humility: assume you cannot see every effect, build in feedback and reversibility where you can, and watch for the surprise instead of assuming your change did only what you intended.</div></details></div></div>


## Questions

<div class="qcard" data-q="1">
<p><span class="qnum">Q1.</span> You typed a long command and mistyped one word near the start of the line. Describe two different ways to fix it without retyping the whole command.</p>
<textarea data-ans="1" placeholder="Type your answer here..."></textarea>
<div class="attach no-print">Attach screenshot(s): <input type="file" accept="image/*" data-shot="1" multiple></div>
<div class="shots" data-shots="1"></div>
<details class="answer"><summary>Show answer</summary>
<div>One way: press Up to recall the command, use Ctrl+A (or Alt+B to move back a word at a time) to move the cursor to the wrong word, fix it in place, and press Enter. Another way: use the quick substitution <code>^old^new</code> on the previous command, which reruns it with the first occurrence of <code>old</code> replaced by <code>new</code>. <code>Ctrl+R</code> to reverse-search history and re-edit the recalled line is a third.
</div>
</details><label class="complete no-print"><input type="checkbox" class="progress-item" data-done="q1"> Mark complete</label>
</div>
<div class="qcard" data-q="2">
<p><span class="qnum">Q2.</span> Give one command you ran today that changed the system (created, moved, or removed something) and one that only read or reported. Why is it worth knowing which is which before you press Enter?</p>
<textarea data-ans="2" placeholder="Type your answer here..."></textarea>
<div class="attach no-print">Attach screenshot(s): <input type="file" accept="image/*" data-shot="2" multiple></div>
<div class="shots" data-shots="2"></div>
<details class="answer"><summary>Show answer</summary>
<div>A changing command is one like <code>mkdir -p ~/range/checklists</code>, <code>touch</code>, <code>mv</code>, <code>rm</code>, or a redirection with <code>></code>; a reading command is one like <code>ls</code>, <code>cat</code>, <code>pwd</code>, <code>grep</code>, or a pipeline that only prints to the screen. It is worth knowing the difference because a reading command can be run freely to check your bearings, while a changing command -- especially <code>rm</code>, a <code>></code> that overwrites, or anything run with <code>sudo</code> -- can be hard to undo, sometimes irreversibly, so you read it and understand it before you run it.
</div>
</details><label class="complete no-print"><input type="checkbox" class="progress-item" data-done="q2"> Mark complete</label>
</div>
<div class="worksheet-controls no-print">
<button type="button" data-ws="show">Show all answers</button>
<button type="button" data-ws="hide">Hide all answers</button>
</div>



<footer class="report-stamp">bootcamp &middot; Revision: v0.0.011 20261112</footer>

<script>/* DoN Range narrative engine: the thin GAME layer that sits ABOVE a real lab.
 *
 * It owns reputation, rank, qualifications, story checkpoints, side quests, progression gates, and
 * seeded dice events. It is deliberately SEPARATE from the economy engine (game-engine.js / DonGame):
 * that engine's parse() rebuilds state from a whitelist and would silently drop any extra field, so the
 * game layer keeps its OWN state + storage key and merely COMPOSES with the economy -- when a gate is
 * unblocked by hiring a contractor, the caller charges the economy (DonGame.apply a 'workorder'/'charge')
 * and marks the gate satisfied here.
 *
 * Pure functions over a plain state object, so the mechanics run in Node (tests) and in the browser
 * (manual / FRMS UI) with no dependencies. Every function returns a NEW state; inputs are never mutated.
 *
 * HARD BOUNDARY: this layer drives NARRATIVE, rewards, and progression only. It never decides a lab's
 * automated pass/fail -- graders read real artifacts (prestop markers, sensor logs), never this state.
 * Dice affect flavor / rewards / optional branches, never the graded objective. Rolls are SEEDED
 * (per-student seed + roll id) so they are reproducible, and fire once (persisted like checkpoints).
 *
 * Content ("narrative pack") is DATA supplied per course (see game/narrative.example.yml), the same way
 * the economy payload is data: { ranks, quals, checkpoints, quests, gates, rolls }.
 */
(function (root) {
  'use strict';

  var VERSION = 1;
  var MAX_BYTES = 512 * 1024;
  var MAX_KEYS = 2000;                 // per object (quals/checkpoints/quests/unlocked/rolls/flags)
  var REP_MIN = -100000, REP_MAX = 100000000;
  var ID_RE = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$/;
  var FLAG_TXT_RE = /^ctf\{[A-Za-z0-9_]{1,64}\}$/;   // a captured flag's plaintext, as the student typed it

  function clone(s) { return JSON.parse(JSON.stringify(s)); }
  function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

  // Deterministic 32-bit hash of a string (FNV-1a), used to seed rolls reproducibly.
  function hashStr(str) {
    var h = 0x811c9dc5;
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0; }
    return h >>> 0;
  }
  // A reproducible integer in [1, sides] from a seed and a key (e.g. a roll id). Same inputs => same roll.
  function seededInt(seed, key, sides) {
    if (!(sides >= 1)) throw new Error('sides must be >= 1');
    var h = hashStr(String(seed) + '|' + String(key));
    return (h % Math.floor(sides)) + 1;
  }

  function newGame(course, seed) {
    if (!ID_RE.test(course || '')) throw new Error('bad course id');
    return {
      v: VERSION, course: course, rev: 0,
      seed: (seed == null ? 'seed:' + course : String(seed)).slice(0, 120),
      rep: 0,
      quals: {},          // { qualId: true }
      flags: {},          // { flagId: true }  -- story flags
      checkpoints: {},    // { "lab:cpId": true }
      quests: {},         // { questId: 'active' | 'done' | 'failed' }
      unlocked: {},       // { unlockId: true } -- tools/content unlocked in-game (incl. hired gates)
      rolls: {},          // { rollId: outcomeId } -- recorded, fire-once
      ctfs: {},           // { ctfId: true } -- captured flags
      ctftext: {}         // { ctfId: 'ctf{...}' } -- the captured plaintexts (the key to the sealed commendation)
    };
  }

  function bump(s) { s.rev += 1; return s; }

  // ---- reputation, rank, quals -----------------------------------------------------------------
  function awardRep(state, n, _reason) {
    var s = clone(state);
    s.rep = clamp(s.rep + Math.round(Number(n) || 0), REP_MIN, REP_MAX);
    return bump(s);
  }
  function earnQual(state, qualId) {
    if (!ID_RE.test(qualId || '')) throw new Error('bad qual id');
    if (state.quals[qualId]) return state;
    var s = clone(state); s.quals[qualId] = true;
    if (Object.keys(s.quals).length > MAX_KEYS) throw new Error('too many quals');
    return bump(s);
  }
  function hasQual(state, qualId) { return !!state.quals[qualId]; }
  // Full course completion (owner, 2026-09-29): the top rank requires EVERYTHING -- every lab's progress
  // list finished (flag labdone:<lab>, set once by the overlay), every CTF flag captured, every
  // checkpoint seen, every side quest done (optional ones included). `completion` is generated
  // course-wide ({labs, ctfs, checkpoints: ["lab:id"], quests}). No completion data -> never complete,
  // so a missing manifest cannot hand out the top rank for free.
  function completionStatus(state, completion) {
    var c = completion || {};
    var miss = { labs: [], ctfs: [], checkpoints: [], quests: [] };
    (c.labs || []).forEach(function (l) { if (!state.flags['labdone:' + l]) miss.labs.push(l); });
    (c.ctfs || []).forEach(function (id) { if (!state.ctfs[id]) miss.ctfs.push(id); });
    (c.checkpoints || []).forEach(function (k) { if (!state.checkpoints[k]) miss.checkpoints.push(k); });
    (c.quests || []).forEach(function (id) { if (state.quests[id] !== 'done') miss.quests.push(id); });
    var total = (c.labs || []).length + (c.ctfs || []).length + (c.checkpoints || []).length + (c.quests || []).length;
    var remaining = miss.labs.length + miss.ctfs.length + miss.checkpoints.length + miss.quests.length;
    return { complete: total > 0 && remaining === 0, total: total, remaining: remaining, missing: miss };
  }
  // Current rank = the highest ranks[] entry the student holds (ranks ascending). A rep rank is held at
  // min_rep; a rank with `complete: true` is held ONLY on full completion (rep does not matter, so a
  // negative dice roll cannot block it and surplus rep cannot buy it).
  function rankOf(state, ranks, completion) {
    var cur = null, done = null;
    (ranks || []).forEach(function (r) {
      if (r.complete) {
        if (done === null) done = completionStatus(state, completion).complete;
        if (done) cur = r;
      } else if (state.rep >= (r.min_rep || 0)) cur = r;
    });
    return cur || (ranks && ranks[0]) || { id: 'plebe', title: 'Plebe', min_rep: 0 };
  }
  function rankAtLeast(state, ranks, rankId, completion) {
    var order = (ranks || []).map(function (r) { return r.id; });
    var have = order.indexOf(rankOf(state, ranks, completion).id);
    var need = order.indexOf(rankId);
    return need < 0 ? false : have >= need;
  }

  // ---- unlocks + story flags -------------------------------------------------------------------
  function unlock(state, id) {
    if (!ID_RE.test(id || '')) throw new Error('bad unlock id');
    if (state.unlocked[id]) return state;
    var s = clone(state); s.unlocked[id] = true;
    if (Object.keys(s.unlocked).length > MAX_KEYS) throw new Error('too many unlocks');
    return bump(s);
  }
  function isUnlocked(state, id) { return !!state.unlocked[id]; }
  function setFlag(state, id) {
    if (!ID_RE.test(id || '')) throw new Error('bad flag id');
    if (state.flags[id]) return state;
    var s = clone(state); s.flags[id] = true;
    if (Object.keys(s.flags).length > MAX_KEYS) throw new Error('too many flags');
    return bump(s);
  }

  // Apply a reward block { rep?, qual?, unlock?, flag? } (used by checkpoints/quests/rolls).
  function applyReward(state, reward) {
    var s = state, r = reward || {};
    if (r.rep) s = awardRep(s, r.rep);
    if (r.qual) s = earnQual(s, r.qual);
    if (r.unlock) s = unlock(s, r.unlock);
    if (r.flag) s = setFlag(s, r.flag);
    return s;
  }

  // ---- CTF flags -------------------------------------------------------------------------------
  // Compact, self-contained SHA-256 (sync, UTF-8) so a flag can be validated WITHOUT shipping its
  // plaintext to the browser: the narrative pack carries only sha256(flag). Students submit the ctf{...}
  // they found; we hash it and compare. Not a security boundary (a determined student could brute a
  // weak flag) -- it just keeps the answer out of view-source.
  function _utf8(str) {
    var out = [];
    for (var i = 0; i < str.length; i++) {
      var c = str.charCodeAt(i);
      if (c < 0x80) out.push(c);
      else if (c < 0x800) { out.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f)); }
      else if (c < 0xd800 || c >= 0xe000) { out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f)); }
      else { i++; var cp = 0x10000 + (((c & 0x3ff) << 10) | (str.charCodeAt(i) & 0x3ff)); out.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3f), 0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f)); }
    }
    return out;
  }
  function sha256hex(str) {
    var K = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
      0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
      0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
      0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
      0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
      0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
      0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
      0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
    var H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
    var b = _utf8(str), len = b.length, bitLen = len * 8;
    b.push(0x80); while (b.length % 64 !== 56) b.push(0);
    for (var i = 7; i >= 0; i--) b.push((bitLen / Math.pow(2, i * 8)) & 0xff);
    function rr(x, n) { return (x >>> n) | (x << (32 - n)); }
    for (var j = 0; j < b.length; j += 64) {
      var w = new Array(64);
      for (var t = 0; t < 16; t++) w[t] = (b[j + t * 4] << 24) | (b[j + t * 4 + 1] << 16) | (b[j + t * 4 + 2] << 8) | (b[j + t * 4 + 3]);
      for (t = 16; t < 64; t++) {
        var s0 = rr(w[t - 15], 7) ^ rr(w[t - 15], 18) ^ (w[t - 15] >>> 3);
        var s1 = rr(w[t - 2], 17) ^ rr(w[t - 2], 19) ^ (w[t - 2] >>> 10);
        w[t] = (w[t - 16] + s0 + w[t - 7] + s1) | 0;
      }
      var a = H[0], bb = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (t = 0; t < 64; t++) {
        var S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25), ch = (e & f) ^ (~e & g);
        var t1 = (h + S1 + ch + K[t] + w[t]) | 0;
        var S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22), maj = (a & bb) ^ (a & c) ^ (bb & c);
        var t2 = (S0 + maj) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = bb; bb = a; a = (t1 + t2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + bb) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
      H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    return H.map(function (x) { return ('00000000' + (x >>> 0).toString(16)).slice(-8); }).join('');
  }

  // Submit a candidate flag. Trims it, hashes it, and matches against pack.ctfs[].sha256. On a NEW
  // match, records it found (fire-once) and pays its reward. Returns { state, found, already, ctf }.
  function submitFlag(state, pack, candidate) {
    var s = String(candidate == null ? '' : candidate).trim();
    if (!s) return { state: state, found: false, already: false, ctf: null };
    var h = sha256hex(s);
    var ctf = ((pack && pack.ctfs) || []).filter(function (c) { return String(c.sha256 || '').toLowerCase() === h; })[0];
    if (!ctf) return { state: state, found: false, already: false, ctf: null };
    if (state.ctfs[ctf.id]) return { state: state, found: true, already: true, ctf: ctf };
    var ns = clone(state); ns.ctfs[ctf.id] = true; bump(ns);
    ns.ctftext = ns.ctftext || {}; if (FLAG_TXT_RE.test(s)) ns.ctftext[ctf.id] = s;
    if (Object.keys(ns.ctfs).length > MAX_KEYS) throw new Error('too many ctfs');
    ns = applyReward(ns, { rep: ctf.points, qual: ctf.qual, unlock: ctf.unlock, flag: ctf.flag });
    return { state: ns, found: true, already: false, ctf: ctf };
  }
  function ctfFound(state, id) { return !!state.ctfs[id]; }
  // Side-quest answers share the flag submit box: the candidate is trimmed + LOWERCASED, hashed, and matched
  // against this lab's quests' answer_sha256 (the pack never carries the answer). A match completes the quest.
  function labQuests(pack, lab) {
    return ((pack && pack.quests) || []).filter(function (q) { return q && q.id && (!q.lab || !lab || q.lab === lab); });
  }
  function submitAnswer(state, pack, lab, candidate) {
    var s = String(candidate == null ? '' : candidate).trim().toLowerCase();
    if (!s) return { state: state, found: false, already: false, quest: null };
    var h = sha256hex(s);
    var q = labQuests(pack, lab).filter(function (x) { return String(x.answer_sha256 || '').toLowerCase() === h; })[0];
    if (!q) return { state: state, found: false, already: false, quest: null };
    if (state.quests[q.id] === 'done') return { state: state, found: true, already: true, quest: q };
    var r = completeQuest(state, q);
    return { state: r.state, found: true, already: false, quest: q };
  }
  function questBoard(state, pack, lab) {
    return labQuests(pack, lab).map(function (q) {
      return { id: q.id, title: q.title || q.id, body: q.body || '', optional: !!q.optional,
               points: (q.reward && q.reward.rep) || 0, done: state.quests[q.id] === 'done' };
    });
  }
  // The CTF board: every flag in the pack with its found status. Unfound flags reveal only their hint
  // (or, for a no-hint flag, nothing) -- never the answer.
  function ctfBoard(state, pack) {
    return ((pack && pack.ctfs) || []).map(function (c) {
      var found = ctfFound(state, c.id);
      return { id: c.id, title: c.title || c.id, points: c.points || 0, found: found,
               hint: found ? '' : (c.hint || '') };
    });
  }

  // ---- the sealed commendation -----------------------------------------------------------------
  // A ctf entry with `sealed: true` carries `cipher` (hex): its commendation text XORed with a keystream
  // derived from the PLAINTEXTS of every other flag in the course (pack.completion.ctfs minus the sealed
  // entries, sorted by id, joined by '\n', sha256 -> key; block i of the keystream = sha256(key + ':' + i)).
  // The pack holds no key, so only a student holding every other flag can open it; the reachability check
  // re-derives the same key from the planted sources (game/seal_commendation.py writes the cipher).
  function sealKey(state, pack) {
    var sealed = {};
    ((pack && pack.ctfs) || []).forEach(function (c) { if (c && c.sealed && c.id) sealed[c.id] = true; });
    var ids = ((pack && pack.completion && pack.completion.ctfs) || []).filter(function (id) { return !sealed[id]; }).sort();
    var texts = state.ctftext || {};
    var missing = ids.filter(function (id) { return !texts[id]; });
    if (!ids.length || missing.length) return { key: null, missing: missing, total: ids.length };
    return { key: sha256hex(ids.map(function (id) { return texts[id]; }).join('\n')), missing: [], total: ids.length };
  }
  function _hexBytes(h) { var out = []; for (var i = 0; i + 1 < h.length; i += 2) out.push(parseInt(h.substr(i, 2), 16)); return out; }
  function _xorStream(bytes, key) {
    var out = [], ks = [];
    for (var i = 0; i < bytes.length; i++) {
      if (i % 32 === 0) ks = _hexBytes(sha256hex(key + ':' + (i / 32)));
      out.push(bytes[i] ^ ks[i % 32]);
    }
    return out;
  }
  function seal(text, key) {   // plaintext -> cipher hex (used by the authoring tool and the tests)
    return _xorStream(_utf8(String(text)), key).map(function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  }
  function unseal(cipherHex, key) {   // cipher hex -> text, or null when the bytes are not UTF-8 (wrong key)
    var out = _xorStream(_hexBytes(String(cipherHex || '')), key);
    try { return decodeURIComponent(out.map(function (b) { return '%' + ('0' + b.toString(16)).slice(-2); }).join('')); } catch (e) { return null; }
  }
  // What the UI needs: { present, open, found, missing, total, text, id, title }. text stays null until
  // every other flag is in hand; a wrong key decodes to no ctf{...} and counts as closed.
  function sealStatus(state, pack) {
    var entry = ((pack && pack.ctfs) || []).filter(function (c) { return c && c.sealed && c.cipher; })[0];
    if (!entry) return { present: false, open: false, found: false, missing: [], total: 0, text: null, id: null, title: null };
    var k = sealKey(state, pack);
    var text = k.key ? unseal(entry.cipher, k.key) : null;
    if (text && !/ctf\{[A-Za-z0-9_]+\}/.test(text)) text = null;
    return { present: true, open: !!text, found: ctfFound(state, entry.id), missing: k.missing, total: k.total,
             text: text, id: entry.id, title: entry.title || entry.id };
  }

  // ---- checkpoints (fire-once narrative popups) ------------------------------------------------
  // Returns { state, fired, popup } -- popup is the briefing to show (null if already seen).
  function reachCheckpoint(state, cp) {
    if (!cp || !ID_RE.test(cp.id || '') || !ID_RE.test(cp.lab || '')) throw new Error('bad checkpoint');
    var key = cp.lab + ':' + cp.id;
    if (state.checkpoints[key]) return { state: state, fired: false, popup: null };
    var s = clone(state); s.checkpoints[key] = true; bump(s);
    if (Object.keys(s.checkpoints).length > MAX_KEYS) throw new Error('too many checkpoints');
    s = applyReward(s, cp.reward);
    return { state: s, fired: true, popup: { title: cp.title || cp.id, body: cp.body || '', reward: cp.reward || {} } };
  }
  function seenCheckpoint(state, cp) { return !!state.checkpoints[cp.lab + ':' + cp.id]; }

  // ---- side quests -----------------------------------------------------------------------------
  function startQuest(state, questId) {
    if (!ID_RE.test(questId || '')) throw new Error('bad quest id');
    if (state.quests[questId]) return state;    // already active/done/failed
    var s = clone(state); s.quests[questId] = 'active';
    if (Object.keys(s.quests).length > MAX_KEYS) throw new Error('too many quests');
    return bump(s);
  }
  function completeQuest(state, quest) {
    if (!quest || !ID_RE.test(quest.id || '')) throw new Error('bad quest');
    if (state.quests[quest.id] === 'done') return { state: state, fired: false, reward: null };
    var s = clone(state); s.quests[quest.id] = 'done'; bump(s);
    s = applyReward(s, quest.reward);
    return { state: s, fired: true, reward: quest.reward || {} };
  }
  function failQuest(state, questId) {
    if (!ID_RE.test(questId || '')) throw new Error('bad quest id');
    var s = clone(state); s.quests[questId] = 'failed'; return bump(s);
  }
  function questStatus(state, questId) { return state.quests[questId] || 'available'; }

  // ---- progression gates -----------------------------------------------------------------------
  // A gate.requires is { all: [req...] } or { any: [req...] }; a req is one of:
  //   { qual: id } { rank: id } { unlock: id } { rep: n } { tool: id } { owned: id } { staff: id }
  // 'tool'/'owned'/'staff' consult the ECONOMY state (owned catalog items / staff) via econ.
  // Returns { open, missing:[req...], canHire, hire:{ref,cost_usd,title} }.
  function reqMet(req, gameState, econState) {
    if (req.qual != null) return hasQual(gameState, req.qual);
    if (req.unlock != null) return isUnlocked(gameState, req.unlock);
    if (req.rep != null) return gameState.rep >= req.rep;
    if (req.rank != null) return false; // resolved in evalGate (needs ranks table)
    if (req.tool != null || req.owned != null) return !!(econState && econState.owned && econState.owned[req.tool || req.owned]);
    if (req.staff != null) return !!(econState && econState.staff && econState.staff[req.staff]);
    return false;
  }
  function evalGate(gate, gameState, econState, ranks, completion) {
    if (!gate || !ID_RE.test(gate.id || '')) throw new Error('bad gate');
    // hiring a contractor for this gate marks it unlocked (id or the hire ref)
    var hireKey = gate.hire && gate.hire.ref ? gate.hire.ref : ('gate:' + gate.id);
    if (isUnlocked(gameState, hireKey) || isUnlocked(gameState, 'gate:' + gate.id)) {
      return { open: true, missing: [], canHire: false, hire: null, via: 'hired' };
    }
    var reqs = (gate.requires && (gate.requires.all || gate.requires.any)) || [];
    var mode = gate.requires && gate.requires.any ? 'any' : 'all';
    var met = reqs.map(function (r) {
      return r.rank != null ? rankAtLeast(gameState, ranks, r.rank, completion) : reqMet(r, gameState, econState);
    });
    var open = mode === 'any' ? met.some(Boolean) : met.every(Boolean);
    var missing = reqs.filter(function (_r, i) { return !met[i]; });
    return {
      open: open, missing: open ? [] : missing,
      canHire: !open && !!gate.hire,
      hire: !open && gate.hire ? { ref: gate.hire.ref || hireKey, cost_usd: gate.hire.cost_usd || 0, title: gate.hire.title || 'Hire a contractor' } : null,
      via: open ? mode : null
    };
  }
  // Mark a gate satisfied because the student hired a contractor. The caller is responsible for the
  // ECONOMY charge (DonGame.apply a 'workorder'/'charge' for gate.hire.cost_usd) BEFORE calling this;
  // hireGateTx() returns the economy transaction to apply, so the two stay consistent.
  function hireGateTx(gate, lab) {
    if (!gate || !gate.hire) throw new Error('gate has no hire option');
    return { type: 'workorder', lab: lab, amount: Math.round((gate.hire.cost_usd || 0) * 100),
             ref: gate.hire.ref || ('gate-' + gate.id), note: gate.hire.title || 'contractor to unblock ' + gate.id };
  }
  function markHired(state, gate) {
    var key = gate.hire && gate.hire.ref ? gate.hire.ref : ('gate:' + gate.id);
    return unlock(unlock(state, key), 'gate:' + gate.id);
  }

  // ---- seeded dice events ----------------------------------------------------------------------
  // roll.table is [{ max, outcome, body?, effect? }] sorted ascending by `max` (the top of each band on
  // a d`sides`). Fires once per roll id; the outcome is recorded and its effect (a reward block, which
  // may carry a NEGATIVE rep) applied. Returns { state, outcome, popup, fired }.
  function roll(state, rollDef) {
    if (!rollDef || !ID_RE.test(rollDef.id || '')) throw new Error('bad roll');
    if (state.rolls[rollDef.id] != null) {
      return { state: state, outcome: state.rolls[rollDef.id], popup: null, fired: false };
    }
    var sides = rollDef.sides || 20;
    var n = seededInt(state.seed, rollDef.id, sides);
    var band = (rollDef.table || []).find(function (b) { return n <= b.max; }) || (rollDef.table || [])[ (rollDef.table||[]).length - 1 ] || { outcome: 'none', effect: {} };
    var s = clone(state); s.rolls[rollDef.id] = band.outcome;
    if (Object.keys(s.rolls).length > MAX_KEYS) throw new Error('too many rolls');
    bump(s);
    s = applyReward(s, band.effect);
    return { state: s, outcome: band.outcome, roll: n, popup: { title: rollDef.title || rollDef.id, body: band.body || '', effect: band.effect || {} }, fired: true };
  }

  // ---- HUD model (data the UI renders; no DOM here) --------------------------------------------
  function hudModel(state, pack) {
    var ranks = (pack && pack.ranks) || [];
    var comp = completionStatus(state, pack && pack.completion);
    var cur = rankOf(state, ranks, pack && pack.completion);
    var next = ranks[ranks.map(function (r) { return r.id; }).indexOf(cur.id) + 1] || null;
    var nextModel = null;
    if (next && next.complete) nextModel = { id: next.id, title: next.title || next.id, requires: 'complete', remaining: comp.remaining };
    else if (next) nextModel = { id: next.id, title: next.title || next.id, rep_to_go: Math.max(0, (next.min_rep || 0) - state.rep) };
    return {
      rep: state.rep,
      rank: { id: cur.id, title: cur.title || cur.id },
      next_rank: nextModel,
      completion: { total: comp.total, remaining: comp.remaining, complete: comp.complete },
      seal: (function () { var z = sealStatus(state, pack); return { present: z.present, open: z.open, found: z.found, remaining: z.missing.length }; })(),
      quals: Object.keys(state.quals).sort(),
      unlocked: Object.keys(state.unlocked).sort(),
      quests: Object.keys(state.quests).sort().map(function (q) { return { id: q, status: state.quests[q] }; })
    };
  }

  // ---- serialize / parse / storage (bounded + validated, mirrors the economy engine) -----------
  function canon(x) {
    if (x === null || typeof x !== 'object') return JSON.stringify(x);
    if (Array.isArray(x)) return '[' + x.map(canon).join(',') + ']';
    return '{' + Object.keys(x).sort().map(function (k) { return JSON.stringify(k) + ':' + canon(x[k]); }).join(',') + '}';
  }
  function serialize(state) { return canon(state); }
  function okMap(m, valOk) {
    if (typeof m !== 'object' || m === null || Array.isArray(m)) throw new Error('bad map');
    var keys = Object.keys(m);
    if (keys.length > MAX_KEYS) throw new Error('map too large');
    keys.forEach(function (k) { if (!ID_RE.test(k) || !valOk(m[k], k)) throw new Error('bad map entry: ' + k); });
    return m;
  }
  function parse(text) {
    if (typeof text !== 'string') throw new Error('state must be text');
    if (text.length > MAX_BYTES) throw new Error('state too large');
    var raw = JSON.parse(text, function (k, v) {
      if (k === '__proto__' || k === 'constructor' || k === 'prototype') throw new Error('forbidden key');
      return v;
    });
    if (!raw || raw.v !== VERSION) throw new Error('unsupported state version');
    if (!Number.isSafeInteger(raw.rev) || raw.rev < 0) throw new Error('bad rev');
    if (typeof raw.rep !== 'number' || !(raw.rep >= REP_MIN && raw.rep <= REP_MAX)) throw new Error('bad rep');
    var s = newGame(raw.course, raw.seed);
    s.rev = raw.rev; s.rep = Math.round(raw.rep);
    s.quals = okMap(raw.quals || {}, function (v) { return v === true; });
    s.flags = okMap(raw.flags || {}, function (v) { return v === true; });
    s.unlocked = okMap(raw.unlocked || {}, function (v) { return v === true; });
    s.checkpoints = okMap(raw.checkpoints || {}, function (v) { return v === true; });   // key is "lab:cp"
    Object.keys(s.checkpoints).forEach(function (k) {
      var p = k.split(':'); if (p.length !== 2 || !ID_RE.test(p[0]) || !ID_RE.test(p[1])) throw new Error('bad checkpoint key');
    });
    s.quests = okMap(raw.quests || {}, function (v) { return v === 'active' || v === 'done' || v === 'failed'; });
    s.rolls = okMap(raw.rolls || {}, function (v) { return typeof v === 'string' && v.length <= 80; });
    s.ctfs = okMap(raw.ctfs || {}, function (v) { return v === true; });
    s.ctftext = okMap(raw.ctftext || {}, function (v) { return typeof v === 'string' && FLAG_TXT_RE.test(v); });
    if (canon(s).length > MAX_BYTES) throw new Error('state too large');
    return s;
  }
  function storageKey(course) { return 'dongame-narr:' + course + ':v1'; }
  function load(storage, course, seed) {
    try { var t = storage && storage.getItem(storageKey(course)); if (t) return parse(t); }
    catch (e) { /* fall through */ }
    return newGame(course, seed);
  }
  function save(storage, state) {
    try { storage.setItem(storageKey(state.course), serialize(state)); return true; } catch (e) { return false; }
  }

  var api = {
    VERSION: VERSION, MAX_BYTES: MAX_BYTES, REP_MIN: REP_MIN, REP_MAX: REP_MAX,
    hashStr: hashStr, seededInt: seededInt,
    newGame: newGame, awardRep: awardRep, earnQual: earnQual, hasQual: hasQual,
    rankOf: rankOf, rankAtLeast: rankAtLeast, completionStatus: completionStatus, unlock: unlock, isUnlocked: isUnlocked, setFlag: setFlag, applyReward: applyReward,
    sha256hex: sha256hex, submitFlag: submitFlag, ctfFound: ctfFound, ctfBoard: ctfBoard, submitAnswer: submitAnswer, questBoard: questBoard,
    sealKey: sealKey, seal: seal, unseal: unseal, sealStatus: sealStatus,
    reachCheckpoint: reachCheckpoint, seenCheckpoint: seenCheckpoint,
    startQuest: startQuest, completeQuest: completeQuest, failQuest: failQuest, questStatus: questStatus,
    evalGate: evalGate, hireGateTx: hireGateTx, markHired: markHired,
    roll: roll, hudModel: hudModel,
    canon: canon, serialize: serialize, parse: parse, storageKey: storageKey, load: load, save: save
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.DonNarrative = api;
})(typeof window !== 'undefined' ? window : this);
</script>
<script>/* DoN Range game OVERLAY: the thin, out-of-the-way UI glue that lives ONLY in the lab manual.
 *
 * Design (owner, 2026-09-29): the game stays out of the way. A compact, read-only DASHBOARD (budget,
 * rank, points, progress) lives inside the manual's existing checkwork/progress overlay (#cwOverlay);
 * brief POP-UPS fire at authored checkpoints in the manual body. FRMS, the SIEM, and the terminals stay
 * REAL and carry NO game code -- their outcomes FEED IN one way: FRMS decisions via the shared economy
 * state (DonGame), and real work via progress-item / checkwork completion recorded in the manual.
 *
 * This module is the overlay's BRAIN, split into pure logic (dashboardModel, progressStats, checkpoint
 * resolution -- all unit-testable in Node) and a thin mount() that wires the DOM and returns a controller
 * with test hooks. Dependencies are INJECTED (opts.narrative / opts.economy), defaulting to the globals
 * DonNarrative / DonGame, so the whole thing runs in jsdom with no browser.
 *
 * HARD BOUNDARY (inherited): the overlay drives narrative/rewards/progression only, never a lab's
 * automated pass/fail. It never mutates FRMS/economy state except the ONE path the owner asked for --
 * hiring a contractor to open a gate (an explicit economy workorder the student confirms).
 */
(function (root) {
  'use strict';

  var REP_PER_ITEM = 5;                 // rep awarded the first time a progress item is completed (feed-in)

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtUsd(cents) {
    if (cents == null || isNaN(cents)) return null;
    var n = Math.round(cents) / 100;
    return '$' + n.toLocaleString('en-US', { maximumFractionDigits: 0 });
  }

  // ---- pure logic ------------------------------------------------------------------------------
  // Progress from the manual's .progress-item checkboxes (real work the student has checked off).
  function progressStats(doc) {
    var items = doc ? Array.prototype.slice.call(doc.querySelectorAll('.progress-item')) : [];
    var done = items.filter(function (c) { return c.checked; }).length;
    var total = items.length;
    return { done: done, total: total, pct: total ? Math.round(done / total * 100) : 0 };
  }

  // The dashboard snapshot the overlay renders. narr = DonNarrative api; state = its state; pack = content.
  // balanceCents is the FRMS/economy balance (null when there is no FRMS, e.g. non-cs3670).
  function dashboardModel(narr, state, pack, progress, balanceCents) {
    var hud = narr.hudModel(state, pack || {});
    return {
      rank: hud.rank,
      next_rank: hud.next_rank,
      completion: hud.completion,
      points: hud.rep,
      budget: fmtUsd(balanceCents),
      progress: progress || { done: 0, total: 0, pct: 0 },
      seal: (typeof narr.sealStatus === 'function') ? narr.sealStatus(state, pack || {}) : { present: false, open: false, found: false },
      quals: hud.quals,
      quests: hud.quests
    };
  }

  function dashboardHtml(model) {
    var m = model, parts = [];
    parts.push('<div class="gd-row">');
    // The insignia beside the rank appears only once every other flag is in hand (the sealed commendation
    // opens); hovering it shows the commendation. Until then nothing marks it -- the seal is a secret.
    var insignia = '';
    if (m.seal && m.seal.open) insignia = ' <span class="gd-insignia' + (m.seal.found ? ' is-on' : '') + '" tabindex="0" role="img" aria-label="Commendation" title="' + esc(m.seal.text) + '">&#9733;</span>';
    parts.push('<span class="gd-cell" title="Your standing"><span class="gd-k">Rank</span><span class="gd-v">' + esc(m.rank.title) + insignia + '</span></span>');
    parts.push('<span class="gd-cell" title="Reputation points"><span class="gd-k">Points</span><span class="gd-v">' + esc(m.points) + '</span></span>');
    if (m.budget != null) parts.push('<span class="gd-cell" title="Detachment budget (FRMS)"><span class="gd-k">Budget</span><span class="gd-v">' + esc(m.budget) + '</span></span>');
    parts.push('<span class="gd-cell" title="Lab progress"><span class="gd-k">Progress</span><span class="gd-v">' + esc(m.progress.done) + '/' + esc(m.progress.total) + '</span></span>');
    parts.push('</div>');
    if (m.next_rank && m.next_rank.requires === 'complete') parts.push('<div class="gd-next">' + esc(m.next_rank.title) + ' requires full course completion: ' + esc(m.next_rank.remaining) + ' item(s) remaining (every lab, flag, checkpoint, and side quest)</div>');
    else if (m.next_rank) parts.push('<div class="gd-next">' + esc(m.next_rank.rep_to_go) + ' pts to ' + esc(m.next_rank.title) + '</div>');
    if (m.quals.length) parts.push('<div class="gd-quals">Quals: ' + m.quals.map(esc).join(', ') + '</div>');
    var active = m.quests.filter(function (q) { return q.status === 'active'; });
    if (active.length) parts.push('<div class="gd-quests">Side quests: ' + active.map(function (q) { return esc(q.id); }).join(', ') + '</div>');
    return '<div class="game-dash" aria-label="Game status">' + parts.join('') + '</div>';
  }

  // The CTF board: planted flags with found status + a submit box. Unfound flags show only their hint
  // (nothing for a no-hint flag) -- never the answer. `status` is a transient message after a submit.
  function ctfHtml(narr, state, pack, status, lab) {
    var board = narr.ctfBoard(state, pack);
    var quests = narr.questBoard ? narr.questBoard(state, pack, lab) : [];
    if (!board.length && !quests.length) return '';
    var found = board.filter(function (c) { return c.found; }).length;
    var rows = board.map(function (c) {
      var mark = c.found ? '<span class="ctf-mk on">&#10003;</span>' : '<span class="ctf-mk">&#9633;</span>';
      var label = c.found ? esc(c.title) : (c.hint ? esc(c.title) + ' <span class="ctf-hint">&mdash; ' + esc(c.hint) + '</span>' : '<span class="ctf-hidden">??? &mdash; no hint; find it</span>');
      return '<li class="' + (c.found ? 'is-found' : 'is-hidden') + '">' + mark + ' ' + label + ' <span class="ctf-pts">' + esc(c.points) + ' pts</span></li>';
    }).join('');
    var st = status ? '<div class="ctf-status ' + esc(status.kind) + '">' + esc(status.msg) + '</div>' : '';
    var qrows = quests.map(function (q) {
      var mark = q.done ? '<span class="ctf-mk on">&#10003;</span>' : '<span class="ctf-mk">&#9633;</span>';
      return '<li class="' + (q.done ? 'is-found' : 'is-hidden') + '">' + mark + ' ' + esc(q.title) +
        (q.done ? '' : ' <span class="ctf-hint">&mdash; ' + esc(q.body) + '</span>') + ' <span class="ctf-pts">' + esc(q.points) + ' pts</span></li>';
    }).join('');
    var qdone = quests.filter(function (q) { return q.done; }).length;
    return '<div class="ctf-board">' +
      (board.length ? '<div class="ctf-head">CTF flags <span class="ctf-count">' + found + ' / ' + board.length + '</span></div><ul class="ctf-list">' + rows + '</ul>' : '') +
      (quests.length ? '<div class="ctf-head">Side quests <span class="ctf-count">' + qdone + ' / ' + quests.length + '</span></div><ul class="ctf-list">' + qrows + '</ul>' : '') +
      '<div class="ctf-submit"><input class="ctf-input" type="text" placeholder="ctf{...} or a side-quest answer" aria-label="Submit a captured flag or side-quest answer" spellcheck="false" autocomplete="off">' +
      '<button type="button" class="ctf-go">Submit</button></div>' + st + '</div>';
  }

  // Checkpoints authored in the manual body as <... data-checkpoint="id">. Returns the pack checkpoint
  // defs present in the DOM, in document order (so the mount can wire each to its trigger).
  function checkpointsInDoc(doc, pack) {
    var byId = {};
    ((pack && pack.checkpoints) || []).forEach(function (cp) { byId[cp.id] = cp; });
    var els = doc ? Array.prototype.slice.call(doc.querySelectorAll('[data-checkpoint]')) : [];
    return els.map(function (el) {
      var id = el.getAttribute('data-checkpoint');
      return { el: el, id: id, def: byId[id] || { id: id, lab: (pack && pack.lab) || '', title: el.getAttribute('data-cp-title') || id, body: el.getAttribute('data-cp-body') || '' } };
    }).filter(function (x) { return !!x.id; });
  }

  // ---- mount (thin DOM glue; returns a controller with test hooks) -----------------------------
  function mount(doc, opts) {
    opts = opts || {};
    var narr = opts.narrative || root.DonNarrative;
    var econ = opts.economy || root.DonGame || null;
    if (!narr) throw new Error('DonNarrative is required');
    var course = opts.course || 'cs3670';
    var lab = opts.lab || (course + '-lab0');
    var pack = opts.pack || {};
    var storage = opts.storage || null;
    var seed = opts.seed || ('seed:' + lab);
    var getBalanceCents = typeof opts.getBalanceCents === 'function' ? opts.getBalanceCents : function () { return null; };
    var getEcon = typeof opts.getEcon === 'function' ? opts.getEcon : function () { return null; };

    var state = narr.load(storage, course, seed);
    var ctfStatus = null;   // transient message shown under the flag submit box after a try
    function persist() { if (storage) narr.save(storage, state); }

    // where the dashboard renders: the checkwork overlay's modal, ABOVE the two columns -- NOT inside
    // #cwProgress, whose innerHTML the manual's own cwFill() rewrites when the button is clicked (that
    // would wipe the dashboard). Create the slot once if absent; fall back gracefully on a bare DOM.
    function dashHost() {
      var host = doc.getElementById('cwGameDash');
      if (host) return host;
      host = doc.createElement('div'); host.id = 'cwGameDash';
      var modal = doc.querySelector('#cwOverlay .cw-modal') || doc.getElementById('cwOverlay');
      var cols = modal && modal.querySelector('.cw-cols');
      var title = modal && (modal.querySelector('#cwTitle') || modal.querySelector('h2'));
      if (modal && cols) modal.insertBefore(host, cols);
      else if (modal && title && title.nextSibling) modal.insertBefore(host, title.nextSibling);
      else if (modal) modal.appendChild(host);
      else { var ov = doc.getElementById('cwProgress') || doc.body; if (ov.insertBefore) ov.insertBefore(host, ov.firstChild); else ov.appendChild(host); }
      return host;
    }
    function render() {
      var host = dashHost(); if (!host) return;
      var model = dashboardModel(narr, state, pack, progressStats(doc), getBalanceCents());
      host.innerHTML = dashboardHtml(model) + ctfHtml(narr, state, pack, ctfStatus, lab);
      ctfStatus = null;   // one-shot: cleared once shown
      applyGates();
    }
    // Gated bonus content: <div data-gate="id" hidden> in the manual body stays hidden (with a short lock
    // note naming what opens it) until the gate is open -- a qual, a rank, rep, or an item bought in FRMS
    // (read-only economy state). Bonus material only: a gate never hides anything a grade depends on.
    function reqText(r) {
      var quals = {}, ranks = {};
      ((pack.quals) || []).forEach(function (q) { quals[q.id] = q.title || q.id; });
      ((pack.ranks) || []).forEach(function (k) { ranks[k.id] = k.title || k.id; });
      if (r.qual != null) return 'the ' + (quals[r.qual] || r.qual) + ' qualification';
      if (r.rank != null) return 'the rank of ' + (ranks[r.rank] || r.rank);
      if (r.rep != null) return r.rep + ' points';
      if (r.owned != null || r.tool != null) return 'the ' + (r.owned || r.tool) + ' subscription in FRMS';
      if (r.staff != null) return 'staff member ' + r.staff;
      if (r.unlock != null) return 'an unlock';
      return 'more progress';
    }
    function applyGates() {
      var els = Array.prototype.slice.call(doc.querySelectorAll('[data-gate]'));
      if (!els.length) return;
      var byId = {}; ((pack.gates) || []).forEach(function (g) { byId[g.id] = g; });
      els.forEach(function (el) {
        var def = byId[el.getAttribute('data-gate')];
        if (!def) return;
        var ev = narr.evalGate(def, state, getEcon() || {}, pack.ranks || [], pack.completion);
        el.hidden = !ev.open;
        var lock = el.previousElementSibling && el.previousElementSibling.getAttribute && el.previousElementSibling.getAttribute('data-gate-lock') === def.id ? el.previousElementSibling : null;
        if (ev.open) { if (lock) lock.parentNode.removeChild(lock); return; }
        if (!lock) { lock = doc.createElement('p'); lock.className = 'gate-lock no-print'; lock.setAttribute('data-gate-lock', def.id); el.parentNode.insertBefore(lock, el); }
        var reqs = (def.requires && (def.requires.any || def.requires.all)) || [];
        var joiner = def.requires && def.requires.any ? ' or ' : ' and ';
        lock.innerHTML = '&#128274; <strong>' + esc(def.title || 'Bonus material') + '</strong>: unlocks with ' + esc(reqs.map(reqText).join(joiner)) + '.';
      });
    }
    // Submit a candidate flag: hash + match (never reveals the answer). New capture -> reward + pop-up.
    function doSubmit(val) {
      var r = narr.submitFlag(state, pack, val);
      state = r.state;
      if (!r.found && narr.submitAnswer) {
        var qa = narr.submitAnswer(state, pack, lab, val);
        state = qa.state;
        if (qa.found && !qa.already) {
          var pts = (qa.quest.reward && qa.quest.reward.rep) || 0;
          ctfStatus = { kind: 'good', msg: 'Side quest complete: ' + (qa.quest.title || qa.quest.id) + ' (+' + pts + ' pts)' };
          persist(); render(); showPopup({ title: 'Side quest complete', body: qa.quest.title || qa.quest.id, reward: { rep: pts } });
          return qa;
        }
        if (qa.found) { ctfStatus = { kind: 'warn', msg: 'Side quest already complete.' }; render(); return qa; }
      }
      if (r.found && !r.already) { ctfStatus = { kind: 'good', msg: 'Flag captured: ' + (r.ctf.title || r.ctf.id) + ' (+' + (r.ctf.points || 0) + ' pts)' }; persist(); render(); showPopup({ title: 'Flag captured', body: r.ctf.title || r.ctf.id, reward: { rep: r.ctf.points || 0 } }); }
      else if (r.found && r.already) { ctfStatus = { kind: 'warn', msg: 'Already captured.' }; render(); }
      else { ctfStatus = { kind: 'bad', msg: 'Not a valid flag or answer. Keep looking.' }; render(); }
      return r;
    }

    // brief, dismissible checkpoint pop-up (out of the way; auto-dismiss-able by the caller/UI)
    function showPopup(popup) {
      if (!popup) return null;
      var box = doc.createElement('div'); box.className = 'game-popup no-print'; box.setAttribute('role', 'status');
      box.innerHTML = '<div class="gp-card"><button class="gp-x" type="button" aria-label="Dismiss">&#215;</button>' +
        '<h4>' + esc(popup.title) + '</h4><p>' + esc(popup.body) + '</p>' +
        (popup.reward && popup.reward.rep ? '<p class="gp-reward">+' + esc(popup.reward.rep) + ' pts</p>' : '') + '</div>';
      var x = box.querySelector('.gp-x'); if (x) x.addEventListener('click', function () { if (box.parentNode) box.parentNode.removeChild(box); });
      (doc.body || doc.documentElement).appendChild(box);
      return box;
    }

    // FEED-IN: the first time a progress item is completed, award rep once (flagged so re-checking or a
    // reload never double-pays), fire any checkpoint bound to that item, then re-render.
    function feedItem(id) {
      if (!id) return;
      var flag = 'prog:' + lab + ':' + id;
      if (!state.flags[flag]) {
        state = narr.setFlag(state, flag);
        state = narr.awardRep(state, REP_PER_ITEM, 'progress');
      }
      markLabDone();
      persist(); render();
    }
    // Lab completion for the top rank: the first time every progress item in THIS manual is checked, set
    // labdone:<lab> (fire-once; unchecking later does not revoke it). Also run at mount, for a student who
    // finished the list before this existed.
    function markLabDone() {
      var p = progressStats(doc);
      if (p.total > 0 && p.done === p.total && !state.flags['labdone:' + lab]) state = narr.setFlag(state, 'labdone:' + lab);
    }
    function fireCheckpoint(cpDef) {
      var r = narr.reachCheckpoint(state, cpDef.def || cpDef);
      state = r.state; persist(); render();
      if (r.fired) showPopup(r.popup);
      return r;
    }

    // wire progress checkboxes: on change, feed the item + fire a checkpoint if the element carries one
    var cps = checkpointsInDoc(doc, pack);
    // Markers placed in a manual SECTION (<span data-checkpoint="id" hidden>, <span data-roll="id" hidden>)
    // fire when that section's "Mark this section complete" box is checked: the section is the h2 named by
    // the checkbox's data-sec, through to the next h1/h2.
    function sectionMarkers(t, attr) {
      var out = [], secId = t.getAttribute('data-sec');
      var h = secId ? doc.getElementById(secId) : null;
      if (!h) return out;
      for (var n = h.nextElementSibling; n && !/^H[12]$/.test(n.tagName); n = n.nextElementSibling) {
        if (n.getAttribute && n.getAttribute(attr)) out.push(n.getAttribute(attr));
        Array.prototype.slice.call(n.querySelectorAll ? n.querySelectorAll('[' + attr + ']') : []).forEach(function (m) { out.push(m.getAttribute(attr)); });
      }
      return out;
    }
    function onChange(e) {
      var t = e.target;
      if (!t || !t.classList || !t.classList.contains('progress-item')) return;
      if (!t.checked) { render(); return; }
      var id = t.getAttribute('data-done') || t.getAttribute('data-cp') || '';
      feedItem(id);
      var cpIds = sectionMarkers(t, 'data-checkpoint');
      var cpAttr = t.getAttribute('data-checkpoint'); if (cpAttr) cpIds.unshift(cpAttr);
      cpIds.forEach(function (cid) {
        var def = ((pack.checkpoints) || []).filter(function (c) { return c.id === cid && (!c.lab || c.lab === lab); })[0];
        if (def) fireCheckpoint({ def: def });
      });
      sectionMarkers(t, 'data-roll').forEach(function (rid) {
        var rdef = ((pack.rolls) || []).filter(function (x) { return x.id === rid && (!x.lab || x.lab === lab); })[0];
        if (!rdef) return;
        var r = narr.roll(state, rdef); state = r.state; persist(); render(); if (r.fired) showPopup(r.popup);
      });
    }
    doc.addEventListener('change', onChange);
    // CTF flag submit: delegated on the persistent host (render() rewrites its innerHTML each time).
    var host0 = dashHost();
    host0.addEventListener('click', function (e) {
      if (e.target && e.target.classList && e.target.classList.contains('ctf-go')) {
        var inp = host0.querySelector('.ctf-input'); doSubmit(inp ? inp.value : '');
      }
    });
    host0.addEventListener('keydown', function (e) {
      if ((e.key === 'Enter' || e.keyCode === 13) && e.target && e.target.classList && e.target.classList.contains('ctf-input')) {
        e.preventDefault(); doSubmit(e.target.value);
      }
    });
    markLabDone(); persist();
    render();

    // ---- gate helper (compose with the economy): hire a contractor to open a gate ----------------
    // Returns the economy workorder to apply; the CALLER charges DonGame then calls markGateHired.
    function hireGate(gate) { return narr.hireGateTx(gate, lab); }
    function markGateHired(gate) { state = narr.markHired(state, gate); persist(); render(); return state; }
    function gate(gateDef, econState) { return narr.evalGate(gateDef, state, econState || getEcon() || {}, pack.ranks || [], pack.completion); }
    // ---- "hire a contractor" to fix an intentional break (docs/INTENTIONAL-BREAKS.md) -------------
    // The bridge applied the actual fix; here we record the ECONOMY cost: the reputation hit (narrative,
    // persisted + in the Lab Report) and a workorder against the economy balance when one is writable.
    // Never blocks: a missing economy module just means the dollar cost is shown but not deducted here.
    function contractorCharge(o) {
      o = o || {};
      var rep = Math.abs(Number(o.rep) || 0);
      if (rep) state = narr.awardRep(state, -rep, 'contractor:' + (o.id || ''));
      try {
        if (econ && typeof econ.apply === 'function' && typeof opts.setEcon === 'function' && o.cost) {
          var tx = { type: 'workorder', lab: o.lab || lab, ref: 'contractor-' + (o.id || 'fix'),
                     amount: Math.round(Number(o.cost) * 100), note: 'hired a contractor to fix ' + (o.id || '') };
          opts.setEcon(econ.apply(getEcon() || {}, tx));
        }
      } catch (e) { /* economy not writable here -> cost shown in the UI, rep still charged */ }
      persist(); render();
      return state;
    }

    return {
      // test + host hooks
      get state() { return state; },
      render: render,
      progress: function () { return progressStats(doc); },
      model: function () { return dashboardModel(narr, state, pack, progressStats(doc), getBalanceCents()); },
      feedItem: feedItem,
      reachCheckpoint: function (id) {
        var fromPack = ((pack.checkpoints) || []).filter(function (c) { return c.id === id; })[0];
        var hit = fromPack ? { def: fromPack } : (cps.filter(function (c) { return c.id === id; })[0] || { def: { id: id, lab: lab } });
        return fireCheckpoint(hit);
      },
      submitFlag: function (v) { return doSubmit(v); },
      startQuest: function (qid) { state = narr.startQuest(state, qid); persist(); render(); return state; },
      completeQuest: function (qdef) { var r = narr.completeQuest(state, qdef); state = r.state; persist(); render(); return r; },
      roll: function (rdef) { var r = narr.roll(state, rdef); state = r.state; persist(); render(); if (r.fired) showPopup(r.popup); return r; },
      gate: gate, hireGate: hireGate, markGateHired: markGateHired, contractorCharge: contractorCharge,
      showPopup: showPopup,
      teardown: function () { doc.removeEventListener('change', onChange); }
    };
  }

  var api = {
    REP_PER_ITEM: REP_PER_ITEM, esc: esc, fmtUsd: fmtUsd,
    progressStats: progressStats, dashboardModel: dashboardModel, dashboardHtml: dashboardHtml,
    ctfHtml: ctfHtml, checkpointsInDoc: checkpointsInDoc, mount: mount
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.DonOverlay = api;
})(typeof window !== 'undefined' ? window : this);
</script>
<script>window.NARR_PACK = {"ranks": [{"id": "plebe", "min_rep": 0, "title": "Plebe"}, {"id": "jr_analyst", "min_rep": 60, "title": "Junior Watch Analyst"}, {"id": "analyst", "min_rep": 150, "title": "Watch Analyst"}, {"id": "sr_analyst", "min_rep": 350, "title": "Senior Watch Analyst"}, {"id": "team_lead", "min_rep": 650, "title": "Team Lead"}, {"id": "floor_cmd", "min_rep": 1000, "title": "Watch Floor Commander"}, {"id": "site_cmd", "complete": true, "title": "Site Commander"}], "quals": [{"id": "cryptography", "title": "Cryptography"}, {"id": "access-control", "title": "Access Control"}, {"id": "secure-dev", "title": "Secure Development"}, {"id": "assurance", "title": "Assurance & Evaluation"}], "ctfs": [{"id": "source-tell", "title": "The source tells on you", "lab": "bootcamp", "points": 20, "hint": "A manual's own source may carry more than the rendered page shows.", "sha256": "36b877a48fd379004324a1f3fb03d8d7488cce258311c3e5d04700e93b0fe345"}, {"id": "l0-hidden-note", "title": "The note that ls alone would miss", "lab": "bootcamp", "points": 25, "hint": "A prior technician left a turnover note in the practice data, but a plain listing hides it. List the directory so that names beginning with a dot show, then read the one that does not belong.", "sha256": "abbf6693893c803b83182f0626ce011d0d9674a4fdcde1ea6ce09b8d31745f81"}, {"id": "l0-grep-the-log", "title": "One line out of a long log", "lab": "bootcamp", "points": 30, "hint": "The first-watch log in the practice data is longer than it looks, and one line is a note, not an event. Do not read the whole file by eye; pull the one line that carries a marker out of the many.", "sha256": "26909ececc94ee180414fc1e9578a61fea1280fcd1be757b8ea295d2f75d3c42"}, {"id": "l0-decode-the-token", "title": "The field that is not plain text", "lab": "bootcamp", "points": 35, "hint": "The relay handover config keeps its values after an equals sign, the way the seeded log config and roster hold theirs. One value is encoded rather than written out. Cut that field out of the line, then decode it.", "sha256": "459a2ce04b259be7ec9b39425f95c38f1db28cd777d87b29f491b83b6124108e"}], "checkpoints": [{"id": "l0-checkin", "lab": "bootcamp", "title": "First watch: checking aboard hi-ws-it", "body": "You are the newest technician in the FCD-PAC IT shop, and hi-ws-it is waiting. There is no adversary today -- the work is to learn the seat so your attention is free for the security problem in the labs that follow. Find your bearings, then make the shell work for you rather than against you.\n", "reward": {"rep": 10}}, {"id": "l0-seat-ready", "lab": "bootcamp", "title": "The seat is yours", "body": "You can find where you are and move without thinking, recall and fix a command instead of retyping it, and pull the one line you need out of a long log. You left a tidy, graded end state in ~/range and confirmed it with checkwork. The seat is operating muscle memory now, not a puzzle.\n", "reward": {"rep": 30, "qual": "assurance"}}], "completion": {"labs": [], "ctfs": ["source-tell", "l0-hidden-note", "l0-grep-the-log", "l0-decode-the-token"], "checkpoints": ["bootcamp:l0-checkin", "bootcamp:l0-seat-ready"], "quests": []}, "lab": "bootcamp"};</script>

<script>window.DIND_CATALOG = {"off-host-backup": {"control": "Off-host pull backup", "threat": "Ransomware / destructive attack", "vector": "ATT&CK T1486 Data Encrypted for Impact \u00b7 T1490 Inhibit System Recovery \u00b7 T1485 Data Destruction", "suite": [{"name": "Offline / air-gapped copy", "fn": "recover", "layer": "Data", "sub": "direct", "note": "a recovery copy that sits outside the attacker's normal reach, and that survives compromise of the backup server"}, {"name": "Immutable / object-lock storage", "fn": "prevent", "layer": "Data", "sub": "direct", "note": "backups that resist encryption or deletion for the retention period, so the restore set is likely to stay intact"}, {"name": "Tested restore + IR runbook", "fn": "recover", "layer": "Process", "sub": "partial", "note": "turns whatever backup you hold into an actual recovery under pressure"}, {"name": "AIDE / file-integrity monitoring", "fn": "detect", "layer": "Host", "sub": "partial", "note": "catches the mass file change early, so less data is lost before you act"}, {"name": "EDR / behavioral detection", "fn": "detect", "layer": "Host", "sub": "indirect", "note": "may halt the encryptor mid-run, shrinking what has to be recovered"}, {"name": "Least privilege on the data shares", "fn": "prevent", "layer": "Identity & access", "sub": "indirect", "note": "shrinks what a compromised account can reach or encrypt"}, {"name": "Network segmentation", "fn": "prevent", "layer": "Network", "sub": "indirect", "note": "limits lateral movement to the file store"}, {"name": "SIEM correlation & alerting", "fn": "detect", "layer": "Monitoring", "sub": "indirect", "note": "ties the host signals into one timeline so the watch responds sooner"}, {"name": "Ransomware playbook + decision authority", "fn": "respond", "layer": "Policy", "sub": "indirect", "note": "who decides on reporting and the payment stance, agreed before the incident"}, {"name": "Breach-reporting obligations + counsel", "fn": "respond", "layer": "Legal", "sub": "indirect", "note": "meets notification duties and preserves the record for an investigation"}, {"name": "Off-host pull backup", "fn": "recover", "layer": "Data", "note": "the client is not issued a credential that can write to the backups", "this": true}], "overlap": "No single layer is likely to stop ransomware on its own. Prevention (least privilege, segmentation, immutability) shrinks the blast radius; detection (file-integrity monitoring, EDR, the SIEM) shortens how long the attacker goes unnoticed; recovery (an off-host pull backup, an offline copy, a rehearsed restore) is what brings the data back when the first two are beaten. The off-host backup is a RECOVERY control: it assumes breach and makes the outcome survivable, so it is stronger when paired with detection and immutability.\n"}, "file-integrity-monitoring": {"control": "File-integrity monitoring (AIDE)", "threat": "Tampering with data or binaries after a breach", "vector": "ATT&CK T1565.001 Stored Data Manipulation \u00b7 T1070 Indicator Removal \u00b7 CWE-345 Insufficient Verification of Data Authenticity", "suite": [{"name": "Off-host, read-only baseline", "fn": "detect", "layer": "Monitoring", "sub": "direct", "note": "the same integrity check, from a baseline held where the attacker is unlikely to be able to edit it"}, {"name": "Central SIEM FIM alerts", "fn": "detect", "layer": "Monitoring", "sub": "direct", "note": "the same detection, real-time and central instead of an on-demand local check"}, {"name": "Signed packages & secure boot", "fn": "prevent", "layer": "Host", "sub": "partial", "note": "a tampered binary fails its signature check, covering the binary-tampering half of the vector"}, {"name": "Least privilege / immutable files", "fn": "prevent", "layer": "Identity & access", "sub": "indirect", "note": "fewer accounts can change the watched files at all"}, {"name": "Approved-change baseline + update procedure", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "a known-good change process, so a legitimate edit is told apart from tampering"}, {"name": "Investigate & restore from known-good", "fn": "respond", "layer": "Process", "sub": "indirect", "note": "scope the change, then restore the file from backup"}, {"name": "AIDE / file-integrity monitoring", "fn": "detect", "layer": "Host", "note": "a cryptographic baseline detects a change to the attributes it is configured for on a watched path, at the next check", "this": true}], "overlap": "Integrity monitoring only DETECTS a change; it neither prevents nor undoes it. Prevention (least privilege, signed binaries) reduces what can be altered; recovery (a trusted backup) is what reverses it. The baseline itself should be held where the attacker is unlikely to reach it, or detection can be defeated first.\n"}, "least-privilege": {"control": "Least privilege", "threat": "A compromised account or process doing more than it should", "vector": "ATT&CK T1078 Valid Accounts \u00b7 T1068 Exploitation for Privilege Escalation \u00b7 CWE-250 / CWE-269", "suite": [{"name": "Separation of duties", "fn": "prevent", "layer": "Process", "sub": "partial", "note": "is intended to prevent any single account from both acting and approving; a cap on a different dimension of risk"}, {"name": "Just-in-time / scoped sudo", "fn": "prevent", "layer": "Host", "sub": "direct", "note": "standing privilege is narrowed to time-boxed, logged elevation"}, {"name": "MFA / CAC authentication", "fn": "prevent", "layer": "Identity & access", "sub": "partial", "note": "a stolen password alone is unlikely to be sufficient to use the account; covers the valid-accounts half of the vector"}, {"name": "Need-to-know + joiner/mover/leaver review", "fn": "prevent", "layer": "Personnel", "sub": "partial", "note": "access is granted to the role and revoked when the person moves or leaves"}, {"name": "Periodic access recertification", "fn": "detect", "layer": "Policy", "sub": "indirect", "note": "a scheduled review surfaces rights that outlived their need"}, {"name": "Privileged-access & command auditing", "fn": "detect", "layer": "Monitoring", "sub": "indirect", "note": "surfaces an account using rights it should not"}, {"name": "Revoke / disable on anomaly", "fn": "respond", "layer": "Identity & access", "sub": "indirect", "note": "cut the account the moment misuse is seen"}, {"name": "Least privilege / RBAC", "fn": "prevent", "layer": "Identity & access", "note": "each account and service holds only the rights its job needs", "this": true}], "overlap": "Least privilege is a PREVENTION control: it caps the damage any one account or process can do. It pairs with detection (auditing the use of privilege) and response (revoking access); caps alone do not tell you when a within-scope account is misused, so the monitoring layer still has to watch, and recertification still has to prune what is no longer needed.\n"}, "network-segmentation": {"control": "Network segmentation / microsegmentation", "threat": "Lateral movement and east-west spread after a foothold", "vector": "ATT&CK T1021 Remote Services \u00b7 T1210 Exploitation of Remote Services \u00b7 T1570 Lateral Tool Transfer \u00b7 TA0008 Lateral Movement", "suite": [{"name": "Network segmentation / microsegmentation", "fn": "prevent", "layer": "Network", "note": "deny-by-default between zones, so reachability no longer implies trust", "this": true}, {"name": "VLAN ACLs / NAC admission", "fn": "prevent", "layer": "Network", "sub": "direct", "note": "enforces the same separation at L2 and the switch port"}, {"name": "Host-based firewall", "fn": "prevent", "layer": "Host", "sub": "direct", "note": "each endpoint enforces its own isolation where the fabric cannot"}, {"name": "Physical separation / air gap", "fn": "prevent", "layer": "Physical", "sub": "partial", "note": "topology enforces the boundary for the highest-value segment when logical controls are not trusted"}, {"name": "Least privilege on reachable services", "fn": "prevent", "layer": "Identity & access", "sub": "indirect", "note": "fewer services a pivot can reach or abuse"}, {"name": "East-west flow monitoring / IDS", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "sees the lateral attempt the segment would have blocked"}, {"name": "Firewall change control", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "review helps catch the quiet rule that reopens the segment"}, {"name": "Authorization-boundary / interconnection agreements", "fn": "prevent", "layer": "Legal", "sub": "indirect", "note": "documents which connections across the boundary are sanctioned"}, {"name": "Containment playbook", "fn": "respond", "layer": "Process", "sub": "indirect", "note": "isolate the segment the moment movement is seen"}], "overlap": "Segmentation is a PREVENTION control: it caps where a compromised host can go. When the network cannot be re-segmented (flat legacy fabric, shared appliance), a host firewall or physical separation substitute directly; monitoring and least privilege reduce the damage without replacing the boundary. The boundary depends on the change control that keeps rules from quietly widening it.\n"}, "mfa-cac": {"control": "Phishing-resistant MFA (CAC / PIV)", "threat": "Credential theft, phishing, and account takeover", "vector": "ATT&CK T1078 Valid Accounts \u00b7 T1110 Brute Force \u00b7 T1566 Phishing \u00b7 T1111 Multi-Factor Authentication Interception \u00b7 T1621 Multi-Factor Authentication Request Generation \u00b7 CWE-287 / CWE-308", "suite": [{"name": "Phishing-resistant MFA (CAC/PIV, FIDO2)", "fn": "prevent", "layer": "Identity & access", "note": "a hardware-bound credential that a stolen password or phishing page is unlikely to be able to replay", "this": true}, {"name": "App-based / OTP MFA", "fn": "prevent", "layer": "Identity & access", "sub": "partial", "note": "raises the bar over a password alone, but push-fatigue and OTP phishing remain"}, {"name": "Conditional access / device trust", "fn": "prevent", "layer": "Identity & access", "sub": "partial", "note": "ties sign-in to a managed device, but does not resist phishing the way a hardware credential does"}, {"name": "Least privilege / limited blast radius", "fn": "prevent", "layer": "Identity & access", "sub": "indirect", "note": "a taken account can reach less"}, {"name": "Identity proofing at issuance", "fn": "prevent", "layer": "Personnel", "sub": "indirect", "note": "the credential is bound to a vetted person at the start"}, {"name": "Security-awareness training", "fn": "prevent", "layer": "Personnel", "sub": "indirect", "note": "fewer users hand a credential to a phishing page"}, {"name": "Credential lifecycle policy", "fn": "respond", "layer": "Policy", "sub": "indirect", "note": "issuance, revocation, and a lost-card procedure that cuts a compromised credential"}, {"name": "Geo-velocity (improbable-travel) / anomalous-logon alerting", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "flags use of a credential the attacker now holds"}, {"name": "Revoke / disable on compromise", "fn": "respond", "layer": "Identity & access", "sub": "indirect", "note": "cut the account and re-issue the credential"}], "overlap": "Phishing-resistant MFA is among the stronger preventive controls here because it reduces exposure of a replayable secret. Where a CAC reader or FIDO key is not available, app-based MFA and device-trust conditional access partially compensate, and training plus anomalous-logon detection narrow the gap they leave. Least privilege limits what a taken account is likely to reach, however the login was protected.\n"}, "stig-hardening": {"control": "Security configuration baseline (STIG hardening)", "threat": "Exploitation of insecure defaults and configuration drift", "vector": "ATT&CK T1190 Exploit Public-Facing Application \u00b7 T1068 Exploitation for Privilege Escalation \u00b7 CWE-1188 Initialization of a Resource with an Insecure Default \u00b7 CWE-1392 Use of Default Credentials", "suite": [{"name": "STIG / CIS baseline + OpenSCAP remediation", "fn": "prevent", "layer": "Host", "note": "reduces insecure defaults and assesses the state against a benchmark", "this": true}, {"name": "Golden image / infrastructure as code", "fn": "prevent", "layer": "Host", "sub": "direct", "note": "hosts are built hardened from one reviewed source"}, {"name": "Config management (Ansible) at fleet scale", "fn": "prevent", "layer": "Process", "sub": "direct", "note": "re-applies the baseline on a schedule and corrects drift"}, {"name": "Compliance scanning + reporting", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "surfaces the host that has drifted from the baseline"}, {"name": "Change control + configuration policy", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "an approved baseline and exceptions, documented"}, {"name": "Authorization (RMF ATO) + POA&M for exceptions", "fn": "respond", "layer": "Policy", "sub": "indirect", "note": "documents accepted deviations and a plan to close them"}, {"name": "Least privilege / restrict admin", "fn": "prevent", "layer": "Identity & access", "sub": "indirect", "note": "fewer accounts can loosen a setting"}, {"name": "Remediate / re-image on finding", "fn": "respond", "layer": "Process", "sub": "indirect", "note": "bring a non-compliant host back to the baseline"}], "overlap": "Hardening is PREVENTION applied once; config management and golden images are what keep it applied across a fleet and over time. When a host cannot be re-imaged, scheduled config management and compliance scanning substitute directly, catching and correcting drift; policy and least privilege keep the baseline from being quietly loosened.\n"}, "central-logging": {"control": "Centralized logging / SIEM forwarding", "threat": "Lost visibility and local log tampering after a breach", "vector": "ATT&CK T1562.006 Impair Defenses: Indicator Blocking \u00b7 T1070 Indicator Removal", "suite": [{"name": "Central loghost / SIEM forwarding (syslog over TLS)", "fn": "detect", "layer": "Monitoring", "note": "logs leave the host within seconds, so a later local edit does not alter the central copy", "this": true}, {"name": "Append-only / WORM log store", "fn": "prevent", "layer": "Data", "sub": "partial", "note": "the central copy resists rewrite, including by an administrator, during its lock period"}, {"name": "Host-integrity monitoring on log files", "fn": "detect", "layer": "Host", "sub": "partial", "note": "flags local tampering before or instead of forwarding"}, {"name": "Correlation + alerting rules", "fn": "detect", "layer": "Monitoring", "sub": "indirect", "note": "turns the collected logs into a timeline the watch acts on"}, {"name": "Least privilege on the logging pipeline", "fn": "prevent", "layer": "Identity & access", "sub": "indirect", "note": "fewer accounts can stop the forwarder or edit the source"}, {"name": "Log-retention + review policy", "fn": "respond", "layer": "Policy", "sub": "indirect", "note": "requires the records to exist, and be read, when needed"}, {"name": "Legal hold / chain of custody", "fn": "respond", "layer": "Legal", "sub": "indirect", "note": "preserves the record so it holds up in an investigation"}], "overlap": "Forwarding is a DETECTION enabler: it gets the evidence off the host before it can be erased. When a host cannot forward in real time, an append-only store plus on-host integrity monitoring substitute in part, though neither matches getting the record off the box. Correlation makes the collected logs useful; policy and legal hold keep them available when they matter.\n"}, "encryption-at-rest": {"control": "Encryption at rest (KMS-managed keys)", "threat": "Disclosure of data from a lost, stolen, or re-provisioned medium", "vector": "ATT&CK T1005 Data from Local System \u00b7 CWE-311 Missing Encryption of Sensitive Data / CWE-312 Cleartext Storage of Sensitive Information", "suite": [{"name": "Encryption at rest (KMS-managed key)", "fn": "prevent", "layer": "Data", "note": "the disk, volume, or snapshot is not readable without the managed key, absent a key or implementation compromise", "this": true}, {"name": "Key management + rotation (KMS/HSM)", "fn": "prevent", "layer": "Data", "sub": "direct", "note": "the control is only as strong as how the key is held and rotated"}, {"name": "Physical media control + sanitization", "fn": "prevent", "layer": "Physical", "sub": "partial", "note": "controls and wipes the medium when crypto is unavailable or on disposal"}, {"name": "Access control on the data store + keys", "fn": "prevent", "layer": "Identity & access", "sub": "partial", "note": "separates who may read the data from who holds the key; it does not protect a removed disk"}, {"name": "Encryption in transit (TLS)", "fn": "prevent", "layer": "Network", "sub": "indirect", "note": "covers the data on the wire, the other half of its lifecycle"}, {"name": "Access + key-use auditing", "fn": "detect", "layer": "Monitoring", "sub": "indirect", "note": "surfaces access to the data or misuse of the key"}, {"name": "Data-handling + retention policy", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "classifies what must be encrypted and for how long it is kept"}, {"name": "Breach-notification / data-spill obligations", "fn": "respond", "layer": "Legal", "sub": "indirect", "note": "governs the response when an unencrypted medium is lost"}], "overlap": "Encryption at rest is PREVENTION against disclosure from the medium; its strength depends largely on key management. Where a volume cannot be encrypted, physical media control and sanitization partially compensate on disposal, and access control plus auditing limit and surface who reaches the data. In-transit encryption covers the other half of the lifecycle.\n"}, "patch-management": {"control": "Patch / KB for a known vulnerability", "threat": "Exploitation of a known, unpatched vulnerability (CVE)", "vector": "ATT&CK T1190 Exploit Public-Facing Application \u00b7 T1203 Exploitation for Client Execution \u00b7 T1068 Exploitation for Privilege Escalation", "suite": [{"name": "Apply the vendor patch / KB", "fn": "prevent", "layer": "Host", "note": "removes the vulnerable code itself", "this": true}, {"name": "Virtual patch: red-teamed NIPS/WAF signature", "fn": "prevent", "layer": "Network", "sub": "direct", "note": "is intended to block the exploit packet when the patch cannot be applied; validate it against the real exploit, and against variants or evasions, before it is relied on"}, {"name": "EDR exploit/behavior detection, red-teamed", "fn": "detect", "layer": "Host", "sub": "direct", "note": "may catch the exploit's behavior where no patch exists; prove it fires against the actual exploit, and re-test after each signature or sensor update, before relying on it"}, {"name": "Vendor workaround / disable the feature", "fn": "prevent", "layer": "Host", "sub": "partial", "note": "the documented mitigation that reduces exposure until patched"}, {"name": "Restrict exposure (segmentation / firewall)", "fn": "prevent", "layer": "Network", "sub": "partial", "note": "shrinks who can reach the vulnerable service while it stays unpatched"}, {"name": "Vulnerability scan + KEV-driven priority", "fn": "detect", "layer": "Monitoring", "sub": "indirect", "note": "finds what is vulnerable and ranks it, e.g. the CISA Known Exploited Vulnerabilities (KEV) catalog"}, {"name": "Patch SLA + documented risk acceptance", "fn": "respond", "layer": "Policy", "sub": "indirect", "note": "governs the remediation window (KEV / BOD 22-01; DoD IAVM/CTO) and records the risk when a patch is deferred"}, {"name": "Tested rollback / change control", "fn": "recover", "layer": "Process", "sub": "indirect", "note": "lets the patch go in fast without breaking production"}], "overlap": "The patch is the specified control because it removes the flaw. When it cannot be applied (legacy system, uptime, no vendor fix), the DIRECT compensating controls are a detection or prevention signature on EDR and the NIPS/WAF; a vendor workaround partially compensates. A signature is a control only once it has been RED-TEAMED against the actual exploit code, packet, or behavior to prove it detects or blocks it, and re-tested after each signature or sensor update. An unvalidated signature should be treated as an assumption, not a control. Segmentation and exposure limits buy time; policy records the accepted risk for the window.\n"}, "uem-mdm": {"control": "Endpoint management (UEM / MDM) with compliance-as-code", "threat": "An unmanaged, non-compliant, or compromised endpoint outside the perimeter", "vector": "ATT&CK T1133 External Remote Services \u00b7 T1200 Hardware Additions (rogue-device case) \u00b7 T1078 Valid Accounts", "suite": [{"name": "UEM/MDM enrollment + compliance policy", "fn": "prevent", "layer": "Host", "note": "an enrolled endpoint carries an enforced, reported configuration wherever it lives", "this": true}, {"name": "Comply-to-connect / device attestation", "fn": "prevent", "layer": "Identity & access", "sub": "direct", "note": "a device proves compliance before it reaches anything"}, {"name": "Conditional access tied to device state", "fn": "prevent", "layer": "Identity & access", "sub": "direct", "note": "a non-compliant device is refused even with valid credentials"}, {"name": "STIG baseline on the endpoint", "fn": "prevent", "layer": "Host", "sub": "partial", "note": "the configuration the UEM then enforces and reports"}, {"name": "Remote wipe / lock", "fn": "respond", "layer": "Host", "sub": "partial", "note": "contains a lost or compromised device"}, {"name": "Compliance / posture reporting", "fn": "detect", "layer": "Monitoring", "sub": "indirect", "note": "surfaces the endpoint that has drifted or fallen out of management"}, {"name": "Acceptable-use + BYOD policy", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "sets what a managed endpoint must meet and who may enroll"}], "overlap": "UEM is PREVENTION for endpoints that live outside the perimeter: it enforces and reports a known state. Where a device cannot be fully managed, comply-to-connect and device-tied conditional access substitute directly by refusing an unproven device at the door; posture reporting and policy narrow the rest. Remote wipe is the response when an endpoint is lost despite them.\n"}, "supply-chain-integrity": {"control": "Software supply-chain integrity (signing, provenance, SBOM)", "threat": "A compromised, tampered, or typosquatted dependency", "vector": "ATT&CK T1195 Supply Chain Compromise \u00b7 T1195.001 Compromise Software Dependencies and Development Tools \u00b7 T1199 Trusted Relationship \u00b7 CWE-494 Download of Code Without Integrity Check \u00b7 CWE-1357 Reliance on Insufficiently Trustworthy Component", "suite": [{"name": "Signed artifacts + provenance attestation (SBOM for inventory)", "fn": "prevent", "layer": "Process", "note": "the build is intended to admit only artifacts whose origin and contents are verified; the SBOM inventories what shipped", "this": true}, {"name": "Pinned, hash-locked dependencies", "fn": "prevent", "layer": "Process", "sub": "direct", "note": "the build resolves to the exact reviewed versions, not a moving tag"}, {"name": "Private registry / vetted mirror", "fn": "prevent", "layer": "Network", "sub": "direct", "note": "dependencies come from a controlled source, not the open internet"}, {"name": "Dependency / CVE scanning in CI", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "flags a known-bad or vulnerable component before release"}, {"name": "Least privilege on the build pipeline", "fn": "prevent", "layer": "Identity & access", "sub": "indirect", "note": "limits what a compromised build step can reach or publish"}, {"name": "Vendor risk + procurement policy", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "vets suppliers and components before they are allowed in"}, {"name": "Contractual security terms / SLAs", "fn": "respond", "layer": "Legal", "sub": "indirect", "note": "binds the supplier to disclosure and remediation obligations"}], "overlap": "Signing and provenance are PREVENTION: they establish that a component is what it claims to be. Pinning and a vetted registry substitute directly where full provenance is not yet available, fixing what is pulled and from where; scanning catches a known-bad version, and least privilege limits the damage a tainted build step can do. Procurement policy and contract terms govern the suppliers upstream of these controls.\n"}, "physical-access-control": {"control": "Physical and personnel access control", "threat": "Physical or boot-level access that bypasses software controls (e.g. single-user mode)", "vector": "CWE-1263 Improper Physical Access Control \u00b7 nearest ATT&CK T1078.003 Valid Accounts: Local Accounts / T1542 Pre-OS Boot (no exact technique for a single-user / init=/bin/bash boot)", "suite": [{"name": "Locked server room / facility access control", "fn": "prevent", "layer": "Physical", "note": "the attacker is unlikely to reach the console that single-user mode needs", "this": true}, {"name": "Gates, guards, fences, mantraps", "fn": "prevent", "layer": "Physical", "sub": "direct", "note": "layered site perimeter that keeps unauthorized people off the floor"}, {"name": "Personnel background checks + clearances", "fn": "prevent", "layer": "Personnel", "sub": "partial", "note": "vets who is trusted with physical access; it reduces insider risk rather than blocking the console"}, {"name": "Bootloader password + disk encryption", "fn": "prevent", "layer": "Host", "sub": "partial", "note": "the host control that blocks a boot-parameter edit and unlocks data only with a passphrase; unobserved physical access may still defeat it by removing the drive or resetting firmware"}, {"name": "Require authentication for single-user mode (sulogin)", "fn": "prevent", "layer": "Host", "sub": "partial", "note": "the STIG setting that makes a single-user boot ask for the root password"}, {"name": "Surveillance cameras + access logs", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "records who entered and when, so misuse is attributable"}, {"name": "Visitor escort + badge policy", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "controls unescorted and unbadged presence in controlled space"}, {"name": "Access agreement + prosecutable-use banner", "fn": "prevent", "layer": "Legal", "sub": "indirect", "note": "sets the terms of access and the sanction for misuse"}, {"name": "Tamper-evident seals / asset custody", "fn": "detect", "layer": "Physical", "sub": "indirect", "note": "shows a chassis or drive was opened or moved"}], "overlap": "When a technical control can be bypassed with physical access (booting to single-user mode, pulling a drive), the compensating controls are PHYSICAL and PERSONNEL rather than additional software. A bootloader password, sulogin, and disk encryption raise the bar at the host, but physical possession can still defeat them, so the locked facility, vetted people, and recorded entry carry the weight. Cameras and custody seals make the access attributable after the fact.\n"}, "dhcp-snooping": {"control": "DHCP snooping + Dynamic ARP Inspection", "threat": "LAN-edge address spoofing: rogue DHCP server, ARP poisoning, on-path interception", "vector": "ATT&CK T1557 Adversary-in-the-Middle \u00b7 T1557.002 ARP Cache Poisoning", "suite": [{"name": "DHCP snooping (trusted ports)", "fn": "prevent", "layer": "Network", "note": "binds DHCP offers to the trusted uplink ports, so a rogue server on an access port is dropped and a snooping binding table is built", "this": true}, {"name": "Dynamic ARP Inspection", "fn": "prevent", "layer": "Network", "sub": "direct", "note": "validates ARP against the snooping binding table, so forged gateway ARP is dropped at the switch"}, {"name": "IP Source Guard", "fn": "prevent", "layer": "Network", "sub": "direct", "note": "ties a port to its leased IP and MAC, blocking source-address spoofing from the edge"}, {"name": "802.1X port authentication", "fn": "prevent", "layer": "Identity & access", "sub": "partial", "note": "only an authenticated device reaches the access VLAN, so an unmanaged rogue never joins"}, {"name": "Static gateway/server ARP + DHCP reservations", "fn": "prevent", "layer": "Host", "sub": "partial", "note": "pins the critical bindings so a poisoned entry cannot take hold on them"}, {"name": "arpwatch / IDS ARP-anomaly alerting", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "flags a changed MAC-for-gateway binding for the watch when prevention is absent"}, {"name": "Locked wiring closets + port discipline", "fn": "prevent", "layer": "Physical", "sub": "indirect", "note": "a rogue device needs a live, reachable port before any of this begins"}, {"name": "Switch change control", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "trusted-port designations are reviewed, not set ad hoc"}], "overlap": "Rogue DHCP and ARP poisoning are a switched-LAN problem, so the primary controls live in the switch: snooping decides which ports may answer DHCP, DAI and IP Source Guard enforce the resulting bindings, and 802.1X keeps unmanaged devices off the segment entirely. Where the switch cannot enforce them, static bindings on the critical hosts and ARP-anomaly monitoring narrow and surface the attack, and the locked closet removes the attacker's foothold before layer 2 is ever reached.\n"}, "dynamic-arp-inspection": {"control": "Dynamic ARP Inspection (DAI)", "threat": "ARP cache poisoning / on-path interception on the switched LAN", "vector": "ATT&CK T1557.002 ARP Cache Poisoning \u00b7 T1557 Adversary-in-the-Middle", "suite": [{"name": "Dynamic ARP Inspection", "fn": "prevent", "layer": "Network", "note": "validates ARP requests and replies on an access port against the DHCP-snooping binding table (and ARP ACLs for static-IP hosts), so forged gateway or host ARP is dropped at the switch; enabled per VLAN with trust set per port, and rate-limited on untrusted ports", "this": true}, {"name": "DHCP snooping (trusted ports)", "fn": "prevent", "layer": "Network", "sub": "direct", "note": "builds the binding table DAI enforces and keeps a rogue DHCP server off the access ports"}, {"name": "IP Source Guard", "fn": "prevent", "layer": "Network", "sub": "direct", "note": "ties a port to its leased IP and MAC, closing the source-address spoofing path DAI does not cover"}, {"name": "Static gateway/server ARP entries", "fn": "prevent", "layer": "Host", "sub": "partial", "note": "pins the critical bindings on the endpoints, narrowing where a poisoned entry can take hold even where DAI is absent"}, {"name": "802.1X port authentication", "fn": "prevent", "layer": "Identity & access", "sub": "partial", "note": "keeps an unmanaged attacker device off the access VLAN in the first place"}, {"name": "arpwatch / IDS ARP-anomaly alerting", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "flags a changed MAC-for-gateway binding for the watch where prevention is not enforced"}, {"name": "Locked wiring closets + port discipline", "fn": "prevent", "layer": "Physical", "sub": "indirect", "note": "a rogue device needs a live, reachable access port before any layer-2 attack begins"}, {"name": "Switch change control", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "trusted-port and DAI designations are reviewed, not set ad hoc"}], "overlap": "ARP cache poisoning is a switched-LAN problem, so the direct control lives in the switch: DAI drops forged ARP by checking it against the DHCP-snooping binding table, IP Source Guard closes the source-spoofing path, and 802.1X keeps unmanaged devices off the segment. Where the switch cannot enforce DAI, static ARP on the critical hosts and ARP-anomaly monitoring narrow and surface the attack, and the locked closet removes the attacker's foothold before layer 2 is reached.\n"}, "syn-cookies": {"control": "SYN cookies", "threat": "TCP SYN-flood resource exhaustion of the half-open connection table", "vector": "ATT&CK T1499.001 OS Exhaustion Flood \u00b7 CWE-400 Uncontrolled Resource Consumption", "suite": [{"name": "SYN cookies", "fn": "prevent", "layer": "Host", "note": "encodes the handshake state in the SYN-ACK so no backlog slot is held until the client's ACK returns, defeating the half-open flood", "this": true}, {"name": "Connection rate limiting (conntrack/nftables)", "fn": "prevent", "layer": "Network", "sub": "direct", "note": "caps new and half-open connections per source at the edge"}, {"name": "SYN proxy at the firewall or load balancer", "fn": "prevent", "layer": "Network", "sub": "direct", "note": "the edge completes the handshake and only passes established connections inward"}, {"name": "Backlog and timeout tuning", "fn": "prevent", "layer": "Host", "sub": "partial", "note": "buys headroom against a small flood, though not a large one on its own"}, {"name": "Upstream DDoS scrubbing / RTBH", "fn": "respond", "layer": "Network", "sub": "partial", "note": "diverts or blackholes the flood before it reaches the host"}, {"name": "Anycast + load distribution", "fn": "prevent", "layer": "Network", "sub": "indirect", "note": "spreads load so no single node absorbs the whole flood"}, {"name": "NetFlow / SIEM flood alerting", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "flags the SYN surge so the watch acts before service is lost"}, {"name": "DDoS runbook + provider contacts", "fn": "respond", "layer": "Policy", "sub": "indirect", "note": "who calls the ISP or scrubbing provider, agreed before the incident"}], "overlap": "SYN cookies solve the half-open table on the host itself, but a large flood is a capacity problem the host cannot win alone. Rate limiting and a SYN proxy move the work to the edge; anycast spreads it; upstream scrubbing and RTBH take the volumetric case off the wire entirely. Detection and a rehearsed provider runbook decide how fast the volumetric response actually starts.\n"}, "bcp38": {"control": "Source-address validation (BCP 38)", "threat": "IP source-address spoofing and participation in reflection/amplification DDoS", "vector": "ATT&CK T1498 Network Denial of Service \u00b7 T1498.002 Reflection Amplification \u00b7 BCP 38 / RFC 2827", "suite": [{"name": "Egress filtering (BCP 38)", "fn": "prevent", "layer": "Network", "note": "the edge permits outbound only from the enclave's own source prefixes, so no host can emit spoofed traffic or join a reflection attack", "this": true}, {"name": "Ingress filtering / uRPF", "fn": "prevent", "layer": "Network", "sub": "direct", "note": "drops inbound packets whose source address could not legitimately arrive on that interface"}, {"name": "Close or restrict open UDP reflectors (DNS/NTP)", "fn": "prevent", "layer": "Host", "sub": "partial", "note": "removes the amplifying services an attacker would bounce spoofed traffic off"}, {"name": "Response rate limiting on authoritative DNS", "fn": "prevent", "layer": "Network", "sub": "partial", "note": "caps the amplification an exposed resolver can produce"}, {"name": "Upstream RTBH / scrubbing", "fn": "respond", "layer": "Network", "sub": "partial", "note": "blackholes or cleans attack traffic beyond the enclave edge"}, {"name": "NetFlow spoof/asymmetry alerting", "fn": "detect", "layer": "Monitoring", "sub": "indirect", "note": "surfaces traffic sourced from addresses the enclave does not own"}, {"name": "MANRS / anti-spoofing peering agreements", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "providers enforce source validation at their edges, so the control holds beyond your own"}], "overlap": "Source-address validation is a neighbourly control: egress filtering keeps your hosts from spoofing or reflecting, ingress filtering and uRPF refuse spoofed packets arriving at you. Because a determined attacker uses networks that do not filter, the enclave also removes its own reflectors, rate-limits its resolvers, and relies on upstream scrubbing for the volumetric case. Monitoring and peering agreements extend the control past the edge the enclave directly controls.\n"}, "dns-rpz": {"control": "DNS Response Policy Zones (RPZ)", "threat": "Resolution of malicious domains for command-and-control, phishing, and malware delivery", "vector": "ATT&CK T1071.004 Application Layer Protocol: DNS \u00b7 T1568 Dynamic Resolution \u00b7 T1566 Phishing", "suite": [{"name": "DNS RPZ / sinkhole", "fn": "prevent", "layer": "Network", "note": "the enforcing resolver rewrites or refuses answers for known-bad domains, cutting the lookup before the connection is made", "this": true}, {"name": "Protective-DNS threat feed", "fn": "prevent", "layer": "Network", "sub": "direct", "note": "keeps the RPZ current with known-bad and newly-registered domains"}, {"name": "Egress to approved resolvers only", "fn": "prevent", "layer": "Network", "sub": "partial", "note": "clients cannot bypass the enforcing resolver with their own DNS"}, {"name": "DNS query logging to the SIEM", "fn": "detect", "layer": "Monitoring", "sub": "direct", "note": "surfaces lookups to bad or rare domains, and beaconing or tunneling the blocklist misses"}, {"name": "DNSSEC validation", "fn": "prevent", "layer": "Data", "sub": "indirect", "note": "rejects forged answers (integrity), a different half of DNS defence than reputation"}, {"name": "Web and mail content filtering", "fn": "prevent", "layer": "Host", "sub": "indirect", "note": "a second chokepoint on the same bad destinations at a different layer"}, {"name": "Blocklist governance + appeal path", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "who approves what is sinkholed, so enforcement is accountable"}], "overlap": "RPZ is reputation-based prevention at the resolver; it is only as current as its feed and only binds clients that cannot choose another resolver, so egress control to approved resolvers is its partner. DNSSEC covers a different failure (forged answers, not bad reputations), and query logging catches the tunneling and beaconing a blocklist never will. Governance keeps the block decisions accountable.\n"}, "pmf-80211w": {"control": "Protected Management Frames (802.11w)", "threat": "Wi-Fi management-frame spoofing: deauth/disassociation floods and evil-twin setup", "vector": "IEEE 802.11w \u00b7 ATT&CK T1557 Adversary-in-the-Middle (evil twin) \u00b7 T1498 Network Denial of Service (deauth flood)", "suite": [{"name": "802.11w PMF", "fn": "prevent", "layer": "Network", "note": "authenticates deauth/disassociation and other management frames, so a forged one is ignored by the client and AP", "this": true}, {"name": "WPA3-Enterprise / 802.1X (EAP-TLS)", "fn": "prevent", "layer": "Identity & access", "sub": "direct", "note": "per-user certificate authentication with no shared PSK to capture or crack"}, {"name": "Server-certificate validation in EAP", "fn": "prevent", "layer": "Identity & access", "sub": "partial", "note": "the client refuses an evil-twin AP that lacks the expected RADIUS server certificate"}, {"name": "Rogue-AP / wireless IDS monitoring", "fn": "detect", "layer": "Monitoring", "sub": "direct", "note": "flags a spoofed BSSID or a deauth flood for the watch"}, {"name": "Management-frame rate limiting on the AP", "fn": "prevent", "layer": "Network", "sub": "partial", "note": "blunts a deauth flood where PMF coverage is incomplete"}, {"name": "802.1X on the wired side + segmentation", "fn": "prevent", "layer": "Network", "sub": "indirect", "note": "limits what a joined wireless client can reach if it is compromised"}, {"name": "RF survey + controlled coverage", "fn": "prevent", "layer": "Physical", "sub": "indirect", "note": "reduces where an attacker can sit within usable range of the cell"}, {"name": "Wireless policy + rogue-AP response", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "approved SSIDs and APs only, with a defined response when a rogue appears"}], "overlap": "PMF closes the specific hole that an open deauth attack rides, but it is one piece of wireless defence. WPA3-Enterprise and certificate-validated EAP stop the credential capture and the evil twin that a deauth is often the opening move for; wireless IDS and frame rate limiting cover the gaps where PMF is partial. Segmentation limits the damage of a client that does join, and the RF survey and policy shrink the attacker's physical opportunity.\n"}, "waf": {"control": "Web application firewall (WAF)", "threat": "Web-application attacks: injection, cross-site scripting, and path traversal at the HTTP layer", "vector": "ATT&CK T1190 Exploit Public-Facing Application \u00b7 CWE-89 SQL Injection \u00b7 CWE-79 Cross-site Scripting \u00b7 CWE-22 Path Traversal", "suite": [{"name": "WAF request inspection", "fn": "prevent", "layer": "Network", "note": "inspects HTTP and blocks known attack patterns at the edge, a virtual patch in front of the application", "this": true}, {"name": "Input validation + parameterized queries", "fn": "prevent", "layer": "Host", "sub": "direct", "note": "fixes the flaw in the code that the WAF only screens from outside"}, {"name": "Patch or upgrade the application", "fn": "prevent", "layer": "Host", "sub": "direct", "note": "removes the vulnerability the WAF is standing in front of"}, {"name": "TLS termination + security headers", "fn": "prevent", "layer": "Network", "sub": "partial", "note": "CSP and HSTS at the proxy cover the client-side half of the web attack surface"}, {"name": "Rate limiting + bot management", "fn": "prevent", "layer": "Network", "sub": "partial", "note": "caps automated probing, scraping, and credential stuffing"}, {"name": "WAF/proxy logging to the SIEM", "fn": "detect", "layer": "Monitoring", "sub": "direct", "note": "attack attempts and blocks feed the watch for detection and tuning"}, {"name": "DAST / penetration test before exposure", "fn": "detect", "layer": "Process", "sub": "indirect", "note": "finds the holes before an attacker, so rules and fixes are ready"}, {"name": "Secure-SDLC + code-review policy", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "builds the input-handling discipline no edge control can supply"}], "overlap": "A WAF buys time: it screens the obvious attacks and virtually patches a known flaw while the real fix ships, but it does not repair the code. Input validation, parameterized queries, and patching remove the vulnerability at the source; headers and rate limiting cover the client side and the automation; logging, testing, and a secure-SDLC process turn the stopgap into a lasting fix.\n"}, "ai-guardrails": {"control": "AI / LLM guardrails and output validation", "threat": "A generative-AI assistant manipulated by injected instructions, or whose output is trusted and acted on without checking -- leaking or acting on enclave data", "vector": "OWASP LLM01 Prompt Injection \u00b7 LLM05 Improper Output Handling \u00b7 LLM02 Sensitive Information Disclosure \u00b7 LLM06 Excessive Agency \u00b7 CWE-1426 Improper Validation of Generative AI Output \u00b7 MITRE ATLAS (adversarial ML)", "suite": [{"name": "Input/output guardrail", "fn": "prevent", "layer": "Data", "note": "screens injected instructions on the way in and unsafe or sensitive content on the way out before it is used", "this": true}, {"name": "Treat model output as untrusted; run it non-privileged", "fn": "prevent", "layer": "Host", "sub": "direct", "note": "the CWE-1426 fix -- validate and sandbox what the model returns rather than executing it on trust"}, {"name": "Least agency: scope the assistant's tools, data, and actions", "fn": "prevent", "layer": "Identity & access", "sub": "partial", "note": "a compromised prompt reaches only what the assistant was granted (OWASP LLM06)"}, {"name": "Human in the loop for consequential actions", "fn": "respond", "layer": "Process", "sub": "partial", "note": "an analyst approves or overrules the model before it acts on the enclave"}, {"name": "Model and training-data provenance (AI-BOM)", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "know the lineage of the model and its data so a poisoned or tampered supply chain is caught (OWASP LLM03)"}, {"name": "Model governance with a human-accountable owner", "fn": "prevent", "layer": "Policy", "sub": "indirect", "note": "someone owns the AI system's risk decision and its authorization to operate (NIST AI RMF GOVERN)"}, {"name": "Log AI inputs and outputs to the SIEM", "fn": "detect", "layer": "Monitoring", "sub": "indirect", "note": "prompts, responses, and tool calls feed the watch for misuse and tuning"}, {"name": "DLP on the AI's egress", "fn": "prevent", "layer": "Data", "sub": "indirect", "note": "stops CUI from leaving through a prompt or a response (OWASP LLM02)"}, {"name": "Acceptable-use policy and user training for AI tools", "fn": "prevent", "layer": "Personnel", "sub": "indirect", "note": "the people using the assistant know what may and may not go into it"}], "overlap": "A guardrail alone does not make a generative-AI assistant safe. A guardrail screens the obvious injection and the unsafe output, but a determined prompt finds gaps; treating output as untrusted and scoping the assistant's agency limit what a successful injection can reach; provenance and governance address a poisoned supply chain and the accountability for operating the system; logging, DLP, and user training cover the watch, the data path, and the people. Together they defend the AI feature in depth.\n"}, "tabletop-exercise": {"control": "Tabletop exercise / cyber wargaming", "threat": "A real incident the team has never rehearsed -- slow, uncoordinated, error-prone response when it counts, with roles, authorities, and hand-offs worked out for the first time under pressure", "vector": "Incident-response and recovery readiness (NIST SP 800-61) -- exercises the detect / respond / recover phases and the human decisions a technical control cannot make", "suite": [{"name": "Tabletop exercise / cyber wargame", "fn": "respond", "layer": "Process", "note": "walks the team through a realistic scenario to surface gaps in the plan, the roles, and the decisions before a real incident does", "this": true}, {"name": "Incident-response plan + playbooks", "fn": "respond", "layer": "Process", "sub": "direct", "note": "the written procedure the exercise tests and improves"}, {"name": "After-action review + remediation tracking", "fn": "respond", "layer": "Process", "sub": "direct", "note": "turns each exercise and real incident into fixed gaps, not just a report"}, {"name": "Red-team / adversary emulation", "fn": "detect", "layer": "Host", "sub": "partial", "note": "a live test of whether the controls and the team actually catch the technique, beyond a discussion"}, {"name": "Purple-team exercise", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "red and blue work together so each detection gap found is tuned on the spot"}, {"name": "Business continuity / disaster-recovery drill", "fn": "recover", "layer": "Process", "sub": "partial", "note": "rehearses the restore and the fail-over the recovery plan assumes"}, {"name": "Role and authority pre-delegation", "fn": "respond", "layer": "Policy", "sub": "indirect", "note": "who can disconnect, notify, or spend is decided before the incident, not during it"}, {"name": "Staff training and awareness", "fn": "prevent", "layer": "Personnel", "sub": "indirect", "note": "the people in the exercise carry the judgment into the real event"}, {"name": "Detection and logging the scenario leans on", "fn": "detect", "layer": "Monitoring", "sub": "indirect", "note": "the technical watch the exercise exercises; it finds where that watch is blind"}], "overlap": "Technical controls decide what the enclave can see and block; an exercise decides whether the people can act on it. A tabletop or wargame rehearses the response an incident will demand -- the roles, the authorities, the hand-offs, the decisions under uncertainty -- and surfaces the gaps while they are cheap to fix. Plans and playbooks give the exercise something to test; red- and purple-team work prove the controls and detections for real; continuity drills rehearse the recovery; and the people carry the judgment the tools cannot supply. The exercise is where the other controls are put under load before an adversary does it.\n"}, "credential-brute-force": {"control": "Login rate-limiting / lockout (fail2ban)", "threat": "Password guessing, spraying, and credential stuffing against a LIVE login -- over the network or at a local console -- while it still accepts passwords. This is an ONLINE attack: the attacker must interact with the running service on every try, so the service can slow, block, or alert.", "vector": "ATT&CK T1110 Brute Force \u00b7 T1110.001 Password Guessing \u00b7 T1110.003 Password Spraying \u00b7 T1110.004 Credential Stuffing \u00b7 T1078 Valid Accounts \u00b7 CWE-307 Improper Restriction of Excessive Authentication Attempts", "suite": [{"name": "Login rate-limiting / IP ban after failed attempts (fail2ban)", "fn": "prevent", "layer": "Network", "note": "watches a network service's auth log and bans a source after repeated failures -- a NETWORK-facing control; blunts a remote burst and, with a long findtime/bantime, a low-and-slow trickle", "this": true}, {"name": "Account lockout / failed-attempt delay (PAM faillock, NIST AC-7)", "fn": "prevent", "layer": "Identity & access", "sub": "direct", "note": "caps attempts per account at the PAM layer, so it covers the LOCAL console and the network alike; tune the threshold so lockout is not itself a denial of service"}, {"name": "Phishing-resistant MFA (CAC/PIV, FIDO2)", "fn": "prevent", "layer": "Identity & access", "sub": "direct", "note": "a guessed or stuffed password alone is unlikely to be enough to use the account, network or local"}, {"name": "Key-based SSH / disable password auth", "fn": "prevent", "layer": "Host", "sub": "direct", "note": "with passwords off there is no password to guess over the network (the lab3 Task-5 fix)"}, {"name": "Strong password policy + breached-password check (NIST IA-5)", "fn": "prevent", "layer": "Identity & access", "sub": "partial", "note": "length over complexity, and reject known-breached secrets so credential stuffing is less likely to find a match"}, {"name": "CAPTCHA / bot management on web logins", "fn": "prevent", "layer": "Network", "sub": "partial", "note": "raises the cost of automated spraying and stuffing against a network web form"}, {"name": "Restrict who can reach the service (host firewall / network segmentation)", "fn": "prevent", "layer": "Network", "sub": "partial", "note": "a remote guesser on a segment with no path to the login never reaches it; it does not stop a same-segment or local attacker (lab3 Task 7)"}, {"name": "Physical / console access control + screen lock", "fn": "prevent", "layer": "Physical", "sub": "partial", "note": "the LOCAL case -- someone at the keyboard guessing a console, su, or sudo password: control the room, lock the screen, limit console logins"}, {"name": "Least privilege / limited blast radius", "fn": "prevent", "layer": "Identity & access", "sub": "indirect", "note": "a cracked account reaches less"}, {"name": "Failed-auth spike + impossible-travel alerting (SIEM)", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "the correlation rule that catches a spray rotating its source address, where a per-IP ban does not (lab3 Task 7)"}, {"name": "Disable / reset on confirmed compromise", "fn": "respond", "layer": "Identity & access", "sub": "indirect", "note": "cut the account and force a credential reset"}], "overlap": "These controls stop ONLINE guessing -- where the attacker interacts with the live service on each try -- whether the attempts arrive over the NETWORK (rate-limit, fail2ban, a host firewall or segmentation, CAPTCHA) or at a LOCAL console (account lockout at the PAM layer, physical access control, a locked screen); account lockout and MFA cover both. A per-source rate-limiter cuts a noisy burst but is weaker against a spray that rotates its address or a trickle under the threshold, and lockout can be turned into a denial of service, so the layers run together and the auth logs are watched for failed-attempt spikes. None of this reaches an OFFLINE attack: once the adversary holds the password hashes, rate-limiting and lockout do nothing -- that is a different control set (see offline-password-cracking).\n"}, "offline-password-cracking": {"control": "Slow, salted password hashing (resist offline cracking)", "threat": "An attacker who has already stolen the password hashes or a credential database and cracks them OFFLINE, on their own hardware and at their own pace -- where rate-limiting and account lockout cannot reach, because no live service is in the loop.", "vector": "ATT&CK T1110.002 Password Cracking \u00b7 T1003 OS Credential Dumping \u00b7 T1555 Credentials from Password Stores \u00b7 CWE-916 Use of Password Hash With Insufficient Computational Effort \u00b7 CWE-759 Use of a One-Way Hash without a Salt \u00b7 CWE-760 Use of a One-Way Hash with a Predictable Salt \u00b7 NIST SP 800-63B", "suite": [{"name": "Slow, salted password hash at a high work factor (memory-hard Argon2id / scrypt / yescrypt, or bcrypt)", "fn": "prevent", "layer": "Data", "note": "makes each of billions of offline guesses expensive so a cracker's throughput collapses; the cost is tunable and raised as hardware improves (OWASP Password Storage; NIST SP 800-63B)", "this": true}, {"name": "Unique per-user random salt", "fn": "prevent", "layer": "Data", "sub": "direct", "note": "defeats rainbow tables and cracking many hashes at once -- each hash must be attacked on its own (fixes CWE-759 / CWE-760)"}, {"name": "Secret pepper / key held in an HSM or KMS", "fn": "prevent", "layer": "Data", "sub": "partial", "note": "a hash dumped without the pepper is not crackable at all -- the secret is not in the stolen file"}, {"name": "Long, high-entropy passphrases (NIST SP 800-63B)", "fn": "prevent", "layer": "Identity & access", "sub": "direct", "note": "length enlarges the offline guess space more than anything else; reject known-breached secrets"}, {"name": "Phishing-resistant MFA", "fn": "prevent", "layer": "Identity & access", "sub": "direct", "note": "a password cracked offline is not enough to use the account on its own"}, {"name": "Protect the hash store (strict /etc/shadow perms, DB-at-rest encryption, least privilege)", "fn": "prevent", "layer": "Host", "sub": "direct", "note": "raise the bar to even OBTAIN the hashes -- the precondition for offline cracking (T1003 / T1555)"}, {"name": "Detect + alert on credential-store access or exfil (FIM, DLP, SIEM)", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "catch the dump of /etc/shadow or the credential database that precedes offline cracking"}, {"name": "Credential rotation / forced reset on a suspected dump", "fn": "respond", "layer": "Identity & access", "sub": "direct", "note": "a hash cracked next week unlocks nothing if the secret has already changed"}, {"name": "Honeytoken credential in the store", "fn": "detect", "layer": "Data", "sub": "indirect", "note": "a decoy that is never valid; a login with its cracked value is near-certain proof the store was taken"}, {"name": "Least privilege / limited blast radius", "fn": "prevent", "layer": "Identity & access", "sub": "indirect", "note": "a cracked account reaches less"}], "overlap": "Online defenses -- rate-limiting, lockout, fail2ban -- do nothing here: the attacker already holds the hashes and guesses on their own hardware. An offline attack is governed by arithmetic: the cost of one hash times the size of the guess space. A slow, salted, memory-hard hash makes each guess expensive, a unique salt forces every hash to be cracked separately, and a secret pepper the dump does not contain can put cracking out of reach; length enlarges the space the cracker must cover. Before any of that, protecting and watching the hash store raises the bar to obtain the hashes at all, and MFA plus prompt rotation blunt a crack that still succeeds. This is the offline counterpart to the online set (see credential-brute-force).\n"}, "memory-hardening": {"control": "Memory-corruption exploit mitigations", "threat": "Exploitation of a memory-safety bug (buffer overflow, use-after-free) to run attacker-chosen code", "vector": "ATT&CK T1203 Exploitation for Client Execution \u00b7 T1190 Exploit Public-Facing Application \u00b7 T1068 Exploitation for Privilege Escalation \u00b7 CWE-787 Out-of-bounds Write \u00b7 CWE-120 Classic Buffer Overflow \u00b7 CWE-416 Use After Free \u00b7 NIST SI-16 Memory Protection", "suite": [{"name": "Compiler/OS memory hardening (ASLR+PIE, NX/DEP, stack canaries, RELRO, FORTIFY_SOURCE, CFI)", "fn": "prevent", "layer": "Host", "note": "randomize and guard the address space so a corrupted pointer is unlikely to reach useful attacker code (NIST SI-16)", "this": true}, {"name": "Hardened memory allocator", "fn": "prevent", "layer": "Host", "sub": "partial", "note": "makes heap grooming and use-after-free reuse less reliable"}, {"name": "Patch / update to remove the bug", "fn": "prevent", "layer": "Host", "sub": "direct", "note": "the durable fix eliminates the vulnerable code; the mitigations only lower exploit reliability"}, {"name": "Memory-safe language / rewrite the risky component", "fn": "prevent", "layer": "Process", "sub": "direct", "note": "removes most of the bug class rather than mitigating it (CISA/NSA memory-safety guidance)"}, {"name": "Sandbox / seccomp / reduced syscall surface", "fn": "prevent", "layer": "Host", "sub": "partial", "note": "contains what a successful exploit can do next"}, {"name": "Least privilege (drop root; avoid SUID where possible)", "fn": "prevent", "layer": "Host", "sub": "indirect", "note": "a successful exploit inherits fewer rights"}, {"name": "WAF / NIPS exploit signature", "fn": "prevent", "layer": "Network", "sub": "partial", "note": "blocks a known exploit payload in transit while a patch is pending"}, {"name": "EDR exploit-prevention / anomalous child-process alerting", "fn": "detect", "layer": "Monitoring", "sub": "partial", "note": "flags a service process that suddenly spawns a shell"}, {"name": "Crash / core-dump monitoring", "fn": "detect", "layer": "Monitoring", "sub": "indirect", "note": "a burst of segfaults is often the failed attempts before a working exploit"}, {"name": "Isolate + rebuild the host on confirmed compromise", "fn": "respond", "layer": "Host", "sub": "indirect", "note": "contain and restore from a trusted image"}], "overlap": "Memory hardening does not remove a memory-safety bug; it lowers the probability that corrupting memory yields reliable code execution. ASLR, NX, stack canaries, RELRO, and CFI each target a different exploitation primitive, so an attacker generally has to defeat several at once, while a patch -- or a memory-safe rewrite -- is what removes the underlying flaw. Sandboxing and least privilege limit what a working exploit reaches, and EDR plus crash monitoring narrow the detection gap while a fix is pending.\n"}};</script>
<script>/* dind.js -- Compensating-controls / defense-in-depth overlay (issue #70).
 * A control chip in the manual opens a modal that reads two ways for the threat the lab's control faces:
 *   1. Defense in depth -- the full suite grouped by FUNCTION (Prevent / Detect / Respond / Recover),
 *      each control tagged with its LAYER, the lab's own control highlighted, and a note on how the
 *      layers overlap.
 *   2. Compensating controls -- the lab's control is the SPECIFIED control; every other control is
 *      tagged by how directly it would COMPENSATE (cover the same threat vector) if the specified
 *      control could not be used: direct / partial / indirect.
 * Pure vanilla JS, no deps, driven by window.DIND_CATALOG (inlined by the generator from controls.yml).
 * Narrative/reference only. */
(function () {
  "use strict";
  var CAT = window.DIND_CATALOG || {};
  var FNS = [
    ["prevent", "Prevent", "stop it happening"],
    ["detect",  "Detect",  "see it happening"],
    ["respond", "Respond", "act on it"],
    ["recover", "Recover", "get back to normal"]
  ];
  var SUB = {
    direct:   "Direct substitute",
    partial:  "Partial substitute",
    indirect: "Indirect substitute"
  };
  var openEl = null, lastFocus = null;

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  function close() {
    if (!openEl) return;
    openEl.remove(); openEl = null;
    document.removeEventListener("keydown", onKey, true);
    if (lastFocus && lastFocus.focus) { try { lastFocus.focus(); } catch (e) {} }
  }
  function onKey(e) { if (e.key === "Escape") { e.stopPropagation(); close(); } }

  function card(item) {
    var isThis = !!item.this;
    var c = el("div", "dind-card dind-fn-" + (item.fn || "prevent") +
                 (isThis ? " dind-this" : "") + (item.sub ? " dind-sub-" + item.sub : ""));
    var h = el("div", "dind-card-h");
    h.appendChild(el("span", "dind-card-name", item.name || ""));
    if (item.layer) h.appendChild(el("span", "dind-card-layer", item.layer));
    c.appendChild(h);
    if (item.note) c.appendChild(el("div", "dind-card-note", item.note));
    if (isThis) {
      c.appendChild(el("div", "dind-card-tag", "specified · this lab"));
    } else if (item.sub) {
      c.appendChild(el("div", "dind-card-sub dind-chip-sub-" + item.sub, SUB[item.sub] || item.sub));
    }
    return c;
  }

  function build(key) {
    var d = CAT[key];
    if (!d) return null;
    var back = el("div", "dind-backdrop");
    back.setAttribute("role", "dialog");
    back.setAttribute("aria-modal", "true");
    back.setAttribute("aria-label", "Compensating controls: " + (d.control || key));
    var panel = el("div", "dind-panel");

    var head = el("div", "dind-head");
    var htext = el("div", "dind-head-t");
    htext.appendChild(el("div", "dind-kicker", "Compensating controls · defense in depth"));
    htext.appendChild(el("h3", "dind-title", d.control || key));
    if (d.threat) htext.appendChild(el("div", "dind-threat", "vs " + d.threat));
    if (d.vector) htext.appendChild(el("div", "dind-vector", d.vector));
    head.appendChild(htext);
    var x = el("button", "dind-x", "×");
    x.setAttribute("aria-label", "Close");
    x.addEventListener("click", close);
    head.appendChild(x);
    panel.appendChild(head);

    // Compensating-controls framing: specified control + a legend of substitution strength.
    var spec = el("div", "dind-spec");
    spec.appendChild(el("p", "dind-spec-t",
      "Specified control: " + (d.control || key) +
      ". If it cannot be used, the controls below cover the same threat vector — " +
      "some directly, some only in part."));
    var leg = el("div", "dind-legend");
    ["direct", "partial", "indirect"].forEach(function (s) {
      var li = el("span", "dind-legend-item dind-chip-sub-" + s);
      li.appendChild(el("span", "dind-dot"));
      li.appendChild(el("span", null, SUB[s]));
      leg.appendChild(li);
    });
    spec.appendChild(leg);
    panel.appendChild(spec);

    var grid = el("div", "dind-grid");
    var suite = d.suite || [];
    FNS.forEach(function (f) {
      var items = suite.filter(function (s) { return (s.fn || "prevent") === f[0]; });
      if (!items.length) return;
      var col = el("div", "dind-col dind-col-" + f[0]);
      var ch = el("div", "dind-col-h");
      ch.appendChild(el("span", "dind-col-name", f[1]));
      ch.appendChild(el("span", "dind-col-sub", f[2]));
      col.appendChild(ch);
      items.forEach(function (it) { col.appendChild(card(it)); });
      grid.appendChild(col);
    });
    panel.appendChild(grid);

    if (d.overlap) {
      var ov = el("div", "dind-overlap");
      ov.appendChild(el("span", "dind-overlap-h", "How the layers overlap"));
      ov.appendChild(el("p", "dind-overlap-t", String(d.overlap).replace(/\s+/g, " ").trim()));
      panel.appendChild(ov);
    }

    back.appendChild(panel);
    back.addEventListener("click", function (e) { if (e.target === back) close(); });
    return back;
  }

  document.addEventListener("click", function (e) {
    var chip = e.target.closest ? e.target.closest(".dind-chip") : null;
    if (!chip) return;
    e.preventDefault();
    var key = chip.getAttribute("data-dind");
    var m = build(key);
    if (!m) return;
    close();
    lastFocus = chip;
    document.body.appendChild(m);
    openEl = m;
    document.addEventListener("keydown", onKey, true);
    var xbtn = m.querySelector(".dind-x");
    if (xbtn) try { xbtn.focus(); } catch (err) {}
  });
})();
</script>
<script>/* DoN Range — Global Network Terrain (shared module, issue #85)
 *
 * ONE canonical source for the layered world-terrain overlay, embedded in two places:
 *   - the SIEM "Operations Plot" landing page (dist/dashboard/app.html) — drawn UNDER the
 *     threat arcs; threat overlay stays the default, terrain layers toggle on beneath it.
 *   - the manual's Bearings -> Network -> "Global" tab (templates/manual.md.j2) — standalone.
 *
 * Offline, no deps. Equirectangular projection, 1000x500 (2:1), matching both hosts' `proj`.
 * All data is FOSS/public and illustrative (see sources in DONTerrain.meta). Positions are
 * approximate anchors (city/metro or org HQ), not datacenter or address-space locations.
 *
 * API:
 *   DONTerrain.svg({proj, W, H, layers, palette}) -> SVG fragment string (a set of <g> groups)
 *        proj(lat,lon)->[x,y]; layers = {land,graticule,cables,cloud,dod,rir} booleans;
 *        palette overrides colors (defaults use CSS vars so each host themes it).
 *   DONTerrain.data            -> the raw data (cables/cloud/dod/rir/anchors/land)
 *   DONTerrain.meta            -> {asof, sources, note}
 *   DONTerrain.LAYERS          -> ordered [{id,label,swatch}] for building toggles
 *   DONTerrain.initStandalone(container, opts) -> builds an SVG + toggle UI in `container`
 */
(function (root) {
  "use strict";

  var META = {
    asof: "2026-10-08",
    note: "Illustrative network landscape. Positions approximate; not operational data. DoD /8s are registered to the DoD NIC (origin AS721/AS749) and largely unadvertised/unrouted as of 2026-10-08; the 2021 AS8003 announcement has since been withdrawn and the space reverted. Refresh: cables & cloud ~6 months, IP/RIR yearly.",
    sources: "IANA IPv4 registry; ARIN whois/RDAP; Hurricane Electric BGP toolkit (bgp.he.net); NIST CSRC (DODIN); DISA/DoDD 5105.19; TeleGeography submarinecablemap.com & submarinenetworks.com (CC-BY); AWS/Azure/GCP public region docs; the five RIRs; PeeringDB; datacentermap.com; Wikipedia (IXP/base/UCC lists)."
  };

  // ---- simplified continent outlines [lon,lat], tagged by RIR (schematic) ----
  var LAND = [
    {rir:"arin",pts:[[-168,66],[-156,71],[-128,70],[-95,70],[-81,73],[-61,82],[-55,66],[-78,52],[-56,51],[-52,47],[-66,44],[-71,41],[-81,25],[-97,26],[-105,22],[-117,32],[-124,40],[-124,48],[-138,59],[-152,58],[-168,66]]},
    {rir:"ripe",pts:[[-45,60],[-20,70],[-18,83],[-55,83],[-73,78],[-58,64],[-45,60]]},
    {rir:"lacnic",pts:[[-81,9],[-77,1],[-80,-5],[-70,-18],[-71,-30],[-74,-45],[-75,-53],[-66,-55],[-62,-40],[-58,-34],[-48,-25],[-35,-8],[-50,0],[-60,6],[-78,11],[-81,9]]},
    {rir:"ripe",pts:[[-10,36],[-10,44],[-2,49],[2,51],[5,58],[10,64],[26,71],[30,66],[40,66],[30,58],[40,52],[48,47],[40,45],[29,45],[28,41],[23,40],[15,40],[12,45],[3,43],[-6,43],[-10,36]]},
    {rir:"afrinic",pts:[[-17,21],[-16,14],[-7,5],[9,4],[9,-1],[13,-6],[12,-17],[15,-29],[20,-35],[27,-34],[33,-26],[40,-16],[48,-12],[43,2],[51,12],[44,12],[33,28],[25,32],[10,37],[0,36],[-9,33],[-17,21]]},
    {rir:"ripe",pts:[[40,66],[60,70],[90,76],[115,74],[142,73],[160,70],[180,67],[170,60],[142,54],[135,48],[120,53],[100,52],[80,52],[60,56],[48,52],[45,56],[40,66]]},
    {rir:"apnic",pts:[[45,40],[55,40],[62,38],[70,24],[73,20],[77,8],[80,13],[88,22],[92,22],[98,16],[100,14],[100,7],[104,1],[108,3],[109,18],[122,40],[127,37],[122,31],[113,22],[105,18],[97,16],[88,20],[80,30],[70,30],[60,25],[52,30],[48,38],[45,40]]},
    {rir:"apnic",pts:[[113,-22],[113,-33],[123,-34],[138,-35],[147,-38],[153,-28],[146,-18],[135,-12],[125,-14],[113,-22]]},
    {rir:"apnic",pts:[[129,31],[132,33],[141,38],[140,42],[135,35],[131,32],[129,31]]},
    {rir:"apnic",pts:[[120,13],[122,18],[125,9],[126,6],[121,6],[120,13]]},
    {rir:"ripe",pts:[[-11,50],[-5,51],[-3,55],[-6,58],[-8,54],[-11,50]]}
  ];

  // ---- submarine cables: [name, [[lat,lon]...], touchesGuam] ----
  var CABLES = [
    ["JUPITER",[[34.98,139.96],[14.11,122.96],[33.86,-118.40]],false],
    ["FASTER",[[34.98,139.96],[25.18,121.41],[43.12,-124.41]],false],
    ["Pacific Light (PLCN)",[[24.86,121.80],[33.92,-118.42]],false],
    ["New Cross Pacific",[[35.17,129.00],[45.20,-123.96]],false],
    ["Trans-Pacific Express",[[24.86,121.80],[45.72,-123.95]],false],
    ["Pacific Crossing-1",[[34.34,136.87],[35.12,-120.62]],false],
    ["Southern Cross NEXT",[[-33.87,151.21],[-17.78,177.44],[1.87,-157.43],[33.86,-118.40]],false],
    ["Hawaiki",[[-33.87,151.21],[21.35,-158.13],[45.20,-123.96]],false],
    ["SEA-US",[[1.38,125.07],[13.46,144.70],[21.46,-158.22],[33.86,-118.40]],true],
    ["Asia-America Gateway",[[1.29,103.85],[13.51,144.80],[21.35,-158.13],[35.29,-120.66]],true],
    ["JGA-North",[[34.97,139.96],[13.46,144.70]],true],
    ["JGA-South",[[13.46,144.70],[-33.87,151.21]],true],
    ["HANTRU1",[[13.46,144.70],[6.96,158.21],[8.73,167.74]],true],
    ["GOKI (Guam-Okinawa-Kyushu)",[[13.46,144.70],[26.21,127.68],[33.77,130.49]],true],
    ["MAREA",[[36.76,-76.06],[43.27,-2.95]],false],
    ["Dunant",[[36.76,-76.06],[46.69,-1.97]],false],
    ["Grace Hopper",[[40.80,-72.87],[50.83,-4.54]],false],
    ["Amitie",[[42.46,-70.95],[44.89,-1.21]],false],
    ["Havfrue / AEC-2",[[40.15,-74.06],[55.75,8.33]],false],
    ["SEA-ME-WE-3",[[53.60,7.20],[31.20,29.92],[19.08,72.88],[1.29,103.85],[31.00,121.90],[26.50,128.00]],false],
    ["SEA-ME-WE-4",[[1.29,103.85],[13.08,80.27],[19.08,72.88],[31.20,29.92],[43.30,5.37]],false],
    ["SEA-ME-WE-5",[[1.29,103.85],[9.93,76.27],[11.60,43.14],[29.97,32.55],[43.30,5.37]],false],
    ["SEA-ME-WE-6",[[1.29,103.85],[13.08,80.27],[11.60,43.14],[31.10,29.60],[43.30,5.37]],false],
    ["AAE-1 (Asia-Africa-Europe-1)",[[22.30,114.17],[1.29,103.85],[19.08,72.88],[11.60,43.14],[29.97,32.55],[43.30,5.37]],false],
    ["IEX (India-Europe-Xpress)",[[19.08,72.88],[23.60,58.50],[29.97,32.55],[44.31,8.48]],false],
    ["Blue-Raman (Red-Sea leg delayed)",[[19.08,72.88],[23.60,58.50],[29.55,34.95],[44.41,8.93]],false],
    ["APG (Asia Pacific Gateway)",[[35.00,140.00],[31.00,121.90],[22.30,114.17],[1.29,103.85]],false],
    ["SJC (SE Asia-Japan Cable)",[[35.00,139.80],[22.30,114.17],[14.60,120.98],[1.29,103.85]],false],
    ["BBG (Bay of Bengal Gateway)",[[23.60,57.90],[19.08,72.88],[13.08,80.27],[5.42,100.33],[1.29,103.85]],false],
    ["ADC (Asia Direct Cable)",[[22.30,114.17],[35.00,139.80],[14.60,120.98],[1.29,103.85]],false],
    ["2Africa",[[43.30,5.37],[44.41,8.93],[6.45,3.40],[-33.92,18.42],[-4.04,39.67],[11.60,43.14],[31.26,32.30],[19.08,72.88]],false],
    ["WACS (West Africa Cable System)",[[-33.92,18.42],[6.45,3.40],[38.72,-9.14],[51.50,-0.10]],false],
    ["EASSy",[[19.60,37.22],[11.60,43.14],[-4.04,39.67],[-6.80,39.28],[-25.97,32.60],[-29.87,31.03]],false],
    ["ACE (Africa Coast to Europe)",[[47.80,-4.37],[38.72,-9.14],[14.72,-17.47],[6.45,3.40],[-33.92,18.42]],false],
    ["Equiano",[[37.96,-8.87],[6.45,3.40],[-22.68,14.53],[-33.92,18.42]],false],
    ["SEACOM",[[19.08,72.88],[-4.04,39.67],[-28.95,31.76],[43.30,5.37]],false],
    ["EllaLink",[[-3.73,-38.52],[37.96,-8.87]],false],
    ["SAm-1 (South America-1)",[[26.36,-80.08],[-3.73,-38.52],[-34.60,-58.40],[-33.03,-71.62],[-12.05,-77.05]],false],
    ["Curie",[[33.86,-118.40],[-33.03,-71.62]],false],
    ["Firmina",[[33.69,-78.89],[-24.00,-46.40],[-34.95,-54.95],[-36.50,-56.70]],false],
    ["Monet",[[26.36,-80.08],[-3.73,-38.52],[-24.00,-46.30]],false],
    ["FALCON (FLAG FALCON)",[[19.08,72.88],[23.60,58.50],[29.30,48.00],[25.12,56.33],[21.50,39.20],[29.97,32.55]],false],
    ["EIG (Europe India Gateway)",[[51.50,-0.10],[36.10,-5.35],[29.97,32.55],[19.08,72.88]],false],
    ["INDIGO-West",[[-31.95,115.86],[-6.20,106.80],[1.29,103.85]],false],
    ["Coral Sea Cable System",[[-33.87,151.21],[-9.44,147.18],[-9.43,159.95]],false],
    ["Tasman Global Access",[[-33.87,151.21],[-36.85,174.76]],false],
    ["Polar Express",[[68.97,33.08],[73.50,80.50],[43.12,131.89]],false],
    ["Quintillion",[[64.50,-165.40],[70.25,-148.30],[71.29,-156.79]],false],
    ["Far North Fiber (planned)",[[35.00,140.00],[64.50,-165.40],[70.00,-20.00],[63.43,10.40]],false],
    ["Apollo",[[40.12,-74.03],[48.73,-3.46],[50.83,-4.54]],false],
    ["EXA Express (Hibernia Express)",[[44.65,-63.57],[51.89,-8.49],[53.65,-3.00]],false]
  ];

  // ---- cloud regions: [name, lat, lon, kind] kind: aws|gov ----
  var CLOUD = [
    ["AWS us-east-1 (N. Virginia)",38.95,-77.45,"aws"],["AWS us-east-2 (Ohio)",39.96,-82.99,"aws"],
    ["AWS us-west-1 (N. California)",37.35,-121.96,"aws"],["AWS us-west-2 (Oregon)",45.84,-119.70,"aws"],
    ["AWS GovCloud US-West (Oregon)",45.6,-119.9,"gov"],["AWS GovCloud US-East (Ohio)",40.2,-82.7,"gov"],
    ["AWS eu-west-1 (Ireland)",53.35,-6.26,"aws"],["AWS eu-central-1 (Frankfurt)",50.11,8.68,"aws"],
    ["AWS ap-northeast-1 (Tokyo)",35.68,139.69,"aws"],["AWS ap-northeast-2 (Seoul)",37.57,126.98,"aws"],
    ["AWS ap-southeast-1 (Singapore)",1.35,103.82,"aws"],["AWS ap-southeast-2 (Sydney)",-33.87,151.21,"aws"],
    ["AWS ap-south-1 (Mumbai)",19.08,72.88,"aws"],["AWS sa-east-1 (Sao Paulo)",-23.55,-46.63,"aws"],
    ["AWS me-central-1 (UAE)",25.20,55.27,"aws"],["AWS af-south-1 (Cape Town)",-33.92,18.42,"aws"],
    ["Azure US Gov Virginia",37.4,-79.0,"gov"],["Azure US Gov Arizona",33.45,-112.07,"gov"],
    ["Azure US DoD (location undisclosed)",38.0,-85.0,"gov"],
    ["GCP us-central1 (Iowa)",41.26,-95.86,"aws"],["GCP us-east4 (N. Virginia)",39.04,-77.49,"aws"]
  ];

  // ---- DoD anchor + RIR HQs: [name, lat, lon, kind, note] kind: dod|rir ----
  var ANCHORS = [
    ["DISA HQ - Fort Meade, MD",39.108,-76.771,"dod","Operates & defends the DODIN; manages much of DoD IPv4 space."],
    ["ARIN - Chantilly, VA",38.89,-77.43,"rir","North America RIR"],
    ["RIPE NCC - Amsterdam",52.37,4.90,"rir","Europe / ME / Central Asia RIR"],
    ["APNIC - Brisbane",-27.47,153.03,"rir","Asia-Pacific RIR"],
    ["LACNIC - Montevideo",-34.90,-56.19,"rir","Latin America RIR"],
    ["AFRINIC - Ebene, Mauritius",-20.24,57.49,"rir","Africa RIR"]
  ];

  // ---- DoD-owned IPv4 /8 blocks (IANA, as of 2026-10-08). 7/8 excluded (ARIN, not DoD). ----
  // 4th field: origin ASN + routing state (bgp.he.net, 2026-10-08). AS721/AS749 = DoD NIC.
  var DOD = [
    ["6/8","Army Information Systems Center","DoD (Army) - DODIN","AS721 · unadvertised"],
    ["11/8","DoD Intel Information Systems","DoD - DODIN","AS749 · partial"],
    ["21/8","DDN-RVN","DoD legacy (DDN)","AS749 · unadvertised"],
    ["22/8","Defense Information Systems Agency","DISA - DODIN","AS749 · unadvertised"],
    ["26/8","Defense Information Systems Agency","DISA - DODIN","AS749 · unadvertised"],
    ["28/8","DSI-North","DoD - DODIN","AS749 · unadvertised"],
    ["29/8","Defense Information Systems Agency","DISA - DODIN","AS749 · unadvertised"],
    ["30/8","Defense Information Systems Agency","DISA - DODIN","AS749 · unadvertised"],
    ["33/8","DLA Systems Automation Center","DoD (DLA)","AS749 · unadvertised"],
    ["55/8","DoD Network Information Center","DoD NIC - DODIN","AS721 · unadvertised"],
    ["214/8","US-DOD","DoD - DODIN","AS721 · unadvertised"],
    ["215/8","US-DOD","DoD - DODIN","AS721 · unadvertised"]
  ];

  var RIR_C = {arin:"#4c6ef5", ripe:"#12b886", apnic:"#f08c00", lacnic:"#ae3ec9", afrinic:"#e8590c"};
  // ---- "who operates here" layers (public data) ----
  var UCC = [
    ["USINDOPACOM — Camp H.M. Smith, HI",21.3875,-157.9050,"geo","Indo-Pacific (geographic); China/DPRK focus"],
    ["USCENTCOM — MacDill AFB, FL",27.8493,-82.5010,"geo","Middle East / Central Asia"],
    ["USEUCOM — Stuttgart, DE",48.7375,9.0898,"geo","Europe / Russia deterrence; dual-hats SACEUR"],
    ["USAFRICOM — Stuttgart, DE",48.7240,9.1580,"geo","African continent"],
    ["USSOUTHCOM — Doral, FL",25.8126,-80.3400,"geo","Central/South America & Caribbean"],
    ["USNORTHCOM — Peterson SFB, CO",38.8230,-104.7000,"geo","North America homeland defense; co-located NORAD"],
    ["USSTRATCOM — Offutt AFB, NE",41.1183,-95.9126,"fn","Nuclear deterrence & global strike"],
    ["USTRANSCOM — Scott AFB, IL",38.5452,-89.8352,"fn","Global mobility / logistics"],
    ["USSOCOM — MacDill AFB, FL",27.8493,-82.5010,"fn","Special operations forces"],
    ["USCYBERCOM — Fort Meade, MD",39.1084,-76.7713,"fn","Cyberspace operations; co-located NSA"],
    ["USSPACECOM — Peterson SFB, CO",38.8230,-104.7000,"fn","Space domain ops (Huntsville move pending)"]
  ];
  var DIB = [
    ["Lockheed Martin — Bethesda, MD",38.9976,-77.1143,"air/space","AS6075"],
    ["RTX (Raytheon) — Arlington, VA",38.8954,-77.0723,"air/munitions",""],
    ["Northrop Grumman — Falls Church, VA",38.8735,-77.2297,"air/space",""],
    ["Boeing Defense — Arlington, VA",38.8599,-77.0529,"air/space",""],
    ["General Dynamics — Reston, VA",38.9586,-77.3570,"naval/land",""],
    ["L3Harris — Melbourne, FL",28.0836,-80.6081,"c5isr/space",""],
    ["BAE Systems Inc. — Falls Church, VA",38.8730,-77.2290,"land/naval",""],
    ["Huntington Ingalls — Newport News, VA",36.9893,-76.4360,"naval",""],
    ["Leidos — Reston, VA",38.9540,-77.3370,"it/intel",""],
    ["SAIC — Reston, VA",38.9560,-77.3610,"it/c5isr",""],
    ["Booz Allen Hamilton — McLean, VA",38.9240,-77.2280,"it/intel","AS7281"],
    ["CACI — Reston, VA",38.9560,-77.3610,"it/intel",""],
    ["Peraton — Reston, VA",38.9520,-77.3380,"it/intel",""],
    ["Palantir — Denver, CO",39.7497,-104.9970,"intel/data",""],
    ["Anduril — Costa Mesa, CA",33.6830,-117.9190,"air/autonomy",""],
    ["SpaceX — Hawthorne, CA",33.9207,-118.3278,"space/launch",""],
    ["Sierra Nevada Corp — Sparks, NV",39.5340,-119.7460,"air/space",""],
    ["Textron — Providence, RI",41.8236,-71.4128,"air/land",""],
    ["KBR — Houston, TX",29.7580,-95.3660,"it/services",""]
  ];
  var BASES = [
    ["Ramstein AB, Germany",49.4369,7.6003,"USAFE HQ / air mobility hub (EUCOM & AFRICOM)"],
    ["Kadena AB, Okinawa",26.3516,127.7692,"Major USAF base in the Pacific; 18th Wing"],
    ["Camp Foster, Okinawa",26.2797,127.7636,"III MEF / Marine Corps Installations Pacific"],
    ["Fleet Activities Yokosuka, Japan",35.2881,139.6719,"US 7th Fleet HQ; forward carrier homeport"],
    ["Yokota AB, Japan",35.7485,139.3485,"USFJ & 5th Air Force HQ; airlift hub"],
    ["Camp Humphreys, Korea",36.9627,127.0300,"Among the largest US overseas bases; USFK/8th Army HQ"],
    ["Osan AB, Korea",37.0906,127.0297,"7th Air Force HQ; forward air base"],
    ["Andersen AFB, Guam",13.5840,144.9240,"Strategic bomber/tanker hub, W. Pacific"],
    ["Naval Base Guam",13.4300,144.6500,"Submarine/logistics hub (Apra Harbor)"],
    ["Diego Garcia, BIOT",-7.3195,72.4229,"Indian Ocean naval/air support facility"],
    ["Al Udeid AB, Qatar",25.1173,51.3150,"CENTCOM forward air HQ; a major regional US air base"],
    ["NAS Sigonella, Italy",37.4017,14.9224,"Hub of the Med — maritime patrol / ISR"],
    ["NSA Naples, Italy",40.9833,14.2060,"US 6th Fleet / Navy Region Europe support"],
    ["Pituffik Space Base, Greenland",76.5312,-68.7032,"Northernmost US base; missile warning"],
    ["Lajes Field, Azores",38.7619,-27.0908,"Mid-Atlantic air refueling / transit"],
    ["Camp Lemonnier, Djibouti",11.5472,43.1593,"Enduring US base in Africa; CJTF-HOA"]
  ];
  var COMMERCIAL = [
    ["Google (Alphabet) — Mountain View",37.4220,-122.0841,"AS15169"],
    ["Microsoft — Redmond",47.6423,-122.1391,"AS8075"],
    ["Amazon — Seattle",47.6220,-122.3366,"AS16509"],
    ["Meta — Menlo Park",37.4847,-122.1484,"AS32934"],
    ["Apple — Cupertino",37.3349,-122.0090,"AS714"],
    ["Cloudflare — San Francisco",37.7909,-122.3947,"AS13335"],
    ["NTT — Tokyo",35.6833,139.7667,"AS2914"],
    ["Deutsche Telekom — Bonn",50.7260,7.1320,"AS3320"],
    ["China Telecom — Beijing",39.9042,116.4074,"AS4134"],
    ["Reliance Jio — Mumbai",19.0760,72.8777,"AS55836"]
  ];

  var CHOKE = [
    ["Luzon Strait",20.50,121.00,"Taiwan-Philippines gap; a dense trans-Pacific cable cluster, seismically active."],
    ["Strait of Malacca",2.50,101.00,"Indian Ocean<->South China Sea; busy shipping + Asia-Europe cable corridor."],
    ["Singapore",1.29,103.85,"SE-Asia cable nexus at the Malacca exit; 25+ systems land or branch."],
    ["Bab-el-Mandeb",12.60,43.40,"Red Sea / Gulf of Aden gate; 2024 cable damage cut multiple Asia-Europe systems."],
    ["Suez Canal",29.97,32.55,"Red Sea<->Mediterranean gate; most Asia-Europe cables transit here."],
    ["Egypt land crossing",30.50,32.30,"16+ Asia-Europe cables cross Egyptian soil; a single-country terrestrial chokepoint."],
    ["Strait of Hormuz",26.60,56.30,"Persian Gulf gate; Gulf cable systems funnel through."],
    ["Marseille",43.30,5.37,"Mediterranean mega-landing; Europe's gateway for Asia/Africa/ME cables."],
    ["Fortaleza",-3.73,-38.52,"South Atlantic hub; Brazil's junction for Europe, US, and Africa cables."],
    ["Guam",13.46,144.70,"US Pacific territory; concentrated trans-Pacific landings."]
  ];
  var IXP = [
    ["IX.br Sao Paulo",-23.55,-46.63,"among the largest globally, ~45 Tbps peak"],["DE-CIX Frankfurt",50.11,8.68,"~19-27 Tbps"],
    ["Equinix IX (Ashburn)",39.04,-77.49,"global platform, ~19 Tbps"],["PIT Chile (Santiago)",-33.45,-70.67,"~15 Tbps"],
    ["AMS-IX Amsterdam",52.37,4.90,"~12 Tbps"],["JPNAP Tokyo",35.68,139.69,"~8 Tbps"],["NetIX Sofia",42.70,23.32,"~7 Tbps"],
    ["LINX London",51.51,-0.10,"~5.8 Tbps"],["MSK-IX Moscow",55.75,37.62,"~4.4 Tbps"],["France-IX Paris",48.85,2.35,"top-tier EU"],
    ["Netnod Stockholm",59.33,18.06,"Nordic anchor"],["DE-CIX New York",40.71,-74.01,"US East"],["HKIX Hong Kong",22.42,114.21,"E-Asia"],
    ["SIX Seattle",47.60,-122.33,"US NW"],["Any2/CoreSite LA",34.05,-118.24,"US West"],["Equinix Singapore",1.29,103.85,"SE-Asia"],
    ["DE-CIX Mumbai",19.08,72.88,"S-Asia"],["MIX Milan",45.46,9.19,"IT anchor"],["Espanix Madrid",40.42,-3.70,"Iberia"],
    ["VIX Vienna",48.21,16.37,"Central EU"],["TorIX Toronto",43.65,-79.38,"Canada"],["NAPAfrica Johannesburg",-26.20,28.04,"a leading African IX"],
    ["UAE-IX Dubai",25.20,55.27,"Middle East"]
  ];
  var ASN = [
    [3356,"Lumen (Level 3)",32.51,-92.12,"Tier-1 backbone"],[174,"Cogent",38.90,-77.04,"Tier-1 backbone"],
    [1299,"Arelion (ex-Telia Carrier)",59.33,18.06,"Tier-1 backbone"],[3257,"GTT",38.88,-77.10,"Tier-1 backbone"],
    [2914,"NTT GIN",35.68,139.69,"Tier-1 backbone"],[6461,"Zayo",40.01,-105.27,"backbone/fiber"],
    [15169,"Google",37.42,-122.08,"hyperscaler"],[16509,"Amazon (AWS)",47.61,-122.33,"hyperscaler"],
    [8075,"Microsoft",47.64,-122.13,"hyperscaler"],[32934,"Meta (Facebook)",37.48,-122.15,"hyperscaler"],
    [13335,"Cloudflare",37.77,-122.39,"CDN/edge"],[20940,"Akamai",42.37,-71.09,"CDN"],
    [714,"Apple",37.33,-122.03,"content"],[31898,"Oracle (OCI)",30.27,-97.74,"cloud"]
  ];
  var DCHUB = [
    ["Ashburn - Data Center Alley (VA)",39.04,-77.49,"Among the world's densest DC clusters; a large share of global traffic transits here."],
    ["Dallas-Fort Worth, TX",32.78,-96.80,"Major US-central interconnection hub."],["Silicon Valley / Santa Clara, CA",37.35,-121.96,"US West colo + cloud core."],
    ["Chicago, IL",41.85,-87.65,"US-Midwest hub (350 E Cermak)."],["Frankfurt, DE",50.11,8.68,"Europe's #1 DC metro (FLAP-D)."],
    ["Amsterdam, NL",52.37,4.90,"EU interconnection core (FLAP-D)."],["London / Slough, UK",51.51,-0.59,"UK DC cluster (FLAP-D)."],
    ["Singapore",1.29,103.85,"APAC interconnection hub."],["Tokyo, JP",35.68,139.69,"North-Asia DC core."],
    ["Mumbai, IN",19.08,72.88,"India cable-landing + DC hub."],["Sao Paulo, BR",-23.55,-46.63,"A leading LatAm DC + IXP metro."],
    ["Paris, FR",48.85,2.35,"FLAP-D."],["Dublin, IE",53.35,-6.26,"FLAP-D; hyperscaler cluster."]
  ];
  var SECTOR_C = {"air/space":"#5b8def","air/munitions":"#8c5bef","naval/land":"#2b6f8f","naval":"#1f5673","c5isr/space":"#2aa198","land/naval":"#7a8c3a","it/intel":"#8a93a8","it/c5isr":"#8a93a8","it/services":"#8a93a8","intel/data":"#e0a44a","air/autonomy":"#d6655a","space/launch":"#b06bd6","air/land":"#6a8f3a"};


  // default palette; hosts can override to match their theme
  var PAL = {
    land:"#243442", landStroke:"#33475a", grat:"#1d2b38",
    cable:"#5a9bf0", cableGuam:"#ff922b", cloud:"#51cf66", gov:"#f06595", dod:"#ff6b6b",
    rir:RIR_C, text:"#9aa7b2", ucc:"#f2c14e", dib:"#6a8cc4", base:"#4fb477", comm:"#8aa0ad", choke:"#ff922b", ixp:"#22b8cf", asnT:"#9aa7b2", asnH:"#51cf66", dc:"#e0a44a"
  };

  function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}

  // Build an SVG fragment string for the enabled layers. Caller provides proj/W/H.
  function svg(o) {
    o = o || {};
    var proj = o.proj || function(la,lo){return [(lo+180)/360*(o.W||1000),(90-la)/180*(o.H||500)];};
    var W = o.W||1000, H = o.H||500;
    var L = o.layers || {land:true,graticule:true,cables:true,cloud:true,dod:true,rir:false};
    var p = o.palette || PAL;
    var out = [];
    var P = function(la,lo){var xy=proj(la,lo);return xy[0].toFixed(1)+","+xy[1].toFixed(1);};
    var _seen={};
    function anchorXY(la,lo){ var xy=proj(la,lo); var key=xy[0].toFixed(0)+"_"+xy[1].toFixed(0); var n=_seen[key]||0; _seen[key]=n+1; if(n){ var ang=n*2.399; xy=[xy[0]+Math.cos(ang)*7,xy[1]+Math.sin(ang)*7]; } return xy; }
    function pt(xy,shape,color,title,r){ r=r||5; var cx=xy[0].toFixed(1),cy=xy[1].toFixed(1); var head='class="nt-mark" data-cx="'+cx+'" data-cy="'+cy+'"'; var t='<title>'+esc(title)+'</title>';
      if(shape==="star") return '<text '+head+' x="'+cx+'" y="'+(xy[1]+4).toFixed(1)+'" text-anchor="middle" font-size="14" fill="'+color+'">\u2605'+t+'</text>';
      if(shape==="diamond") return '<path '+head+' d="M'+cx+' '+(xy[1]-5.5).toFixed(1)+' L'+(xy[0]+5).toFixed(1)+' '+cy+' L'+cx+' '+(xy[1]+5.5).toFixed(1)+' L'+(xy[0]-5).toFixed(1)+' '+cy+' Z" fill="'+color+'" stroke="#0b1620" stroke-width=".6">'+t+'</path>';
      if(shape==="square") return '<rect '+head+' x="'+(xy[0]-3.5).toFixed(1)+'" y="'+(xy[1]-3.5).toFixed(1)+'" width="7" height="7" rx="1" fill="'+color+'" stroke="#0b1620" stroke-width=".6">'+t+'</rect>';
      if(shape==="tri") return '<polygon '+head+' points="'+cx+','+(xy[1]-5).toFixed(1)+' '+(xy[0]+4.5).toFixed(1)+','+(xy[1]+3.5).toFixed(1)+' '+(xy[0]-4.5).toFixed(1)+','+(xy[1]+3.5).toFixed(1)+'" fill="'+color+'" stroke="#0b1620" stroke-width=".6">'+t+'</polygon>';
      return '<circle '+head+' cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="'+color+'" stroke-width="1.4">'+t+'</circle>'; }

    if (L.graticule) {
      var gl = ['<g class="nt-grat">'];
      for (var lon=-180; lon<=180; lon+=30){var a=proj(90,lon),b=proj(-90,lon);gl.push('<line x1="'+a[0].toFixed(0)+'" y1="'+a[1].toFixed(0)+'" x2="'+b[0].toFixed(0)+'" y2="'+b[1].toFixed(0)+'" stroke="'+p.grat+'" stroke-width=".5" vector-effect="non-scaling-stroke"/>');}
      for (var lat=-60; lat<=60; lat+=30){var c=proj(lat,-180),d=proj(lat,180);gl.push('<line x1="'+c[0].toFixed(0)+'" y1="'+c[1].toFixed(0)+'" x2="'+d[0].toFixed(0)+'" y2="'+d[1].toFixed(0)+'" stroke="'+p.grat+'" stroke-width="'+(lat===0?1:.5)+'" vector-effect="non-scaling-stroke"/>');}
      gl.push('</g>'); out.push(gl.join(""));
    }
    if (L.land || L.rir) {
      var lg = ['<g class="nt-land">'];
      LAND.forEach(function(poly){
        var pts = poly.pts.map(function(q){return P(q[1],q[0]);}).join(" ");
        var fill = L.rir ? (p.rir[poly.rir]||p.land) : p.land;
        var op = L.rir ? ' fill-opacity=".45"' : '';
        lg.push('<polygon points="'+pts+'" fill="'+fill+'"'+op+' stroke="'+p.landStroke+'" stroke-width=".6" vector-effect="non-scaling-stroke"/>');
      });
      lg.push('</g>'); out.push(lg.join(""));
    }
    if (L.cables) {
      var cg = ['<g class="nt-cables">'];
      CABLES.forEach(function(c){
        var pts = c[1].map(function(q){return P(q[0],q[1]);}).join(" ");
        var col = c[2] ? p.cableGuam : p.cable;
        cg.push('<polyline points="'+pts+'" fill="none" stroke="'+col+'" stroke-width="'+(c[2]?1.5:1.0)+'" stroke-opacity=".85" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"><title>'+esc(c[0])+(c[2]?" (via Guam)":"")+'</title></polyline>');
      });
      var gu=proj(13.46,144.70);
      cg.push('<text class="nt-mark" data-cx="'+(gu[0]+5).toFixed(0)+'" data-cy="'+(gu[1]-4).toFixed(0)+'" x="'+(gu[0]+5).toFixed(0)+'" y="'+(gu[1]-4).toFixed(0)+'" fill="'+p.cableGuam+'" font-size="10" font-weight="700">★ Guam</text>');
      cg.push('</g>'); out.push(cg.join(""));
    }
    if (L.cloud) {
      var clg = ['<g class="nt-cloud">'];
      CLOUD.forEach(function(r){
        var xy=proj(r[1],r[2]); var gov=r[3]==="gov";
        clg.push('<circle class="nt-mark" data-cx="'+xy[0].toFixed(1)+'" data-cy="'+xy[1].toFixed(1)+'" cx="'+xy[0].toFixed(1)+'" cy="'+xy[1].toFixed(1)+'" r="'+(gov?4:3)+'" fill="'+(gov?p.gov:p.cloud)+'" stroke="#0b1620" stroke-width=".7"><title>'+esc(r[0])+(gov?" (DoD-accredited)":"")+'</title></circle>');
      });
      clg.push('</g>'); out.push(clg.join(""));
    }
    if (L.dod) {
      var dg = ['<g class="nt-dod">'];
      ANCHORS.forEach(function(a){
        var xy=proj(a[1],a[2]);
        if(a[3]==="dod") dg.push('<rect class="nt-mark" data-cx="'+xy[0].toFixed(1)+'" data-cy="'+xy[1].toFixed(1)+'" x="'+(xy[0]-4).toFixed(1)+'" y="'+(xy[1]-4).toFixed(1)+'" width="8" height="8" fill="'+p.dod+'" stroke="#0b1620" stroke-width="1"><title>'+esc(a[0]+" — "+a[4])+'</title></rect>');
        else if(L.rir) dg.push('<circle class="nt-mark" data-cx="'+xy[0].toFixed(1)+'" data-cy="'+xy[1].toFixed(1)+'" cx="'+xy[0].toFixed(1)+'" cy="'+xy[1].toFixed(1)+'" r="3" fill="'+p.text+'" stroke="#0b1620" stroke-width=".7"><title>'+esc(a[0]+" — "+a[4])+'</title></circle>');
      });
      dg.push('</g>'); out.push(dg.join(""));
    }
    if (L.ucc) { var u=['<g class="nt-ucc">']; UCC.forEach(function(a){u.push(pt(anchorXY(a[1],a[2]),"star",p.ucc||"#f2c14e",a[0]+" \u2014 "+a[4]+" ["+(a[3]==="geo"?"geographic":"functional")+"]"));}); u.push('</g>'); out.push(u.join("")); }
    if (L.dib) { var d2=['<g class="nt-dib">']; DIB.forEach(function(a){d2.push(pt(anchorXY(a[1],a[2]),"square",(SECTOR_C[a[3]]||p.dib||"#6a8cc4"),a[0]+" \u2014 "+a[3]+(a[4]?" \u2014 "+a[4]:"")));}); d2.push('</g>'); out.push(d2.join("")); }
    if (L.bases) { var b2=['<g class="nt-bases">']; BASES.forEach(function(a){b2.push(pt(anchorXY(a[1],a[2]),"tri",p.base||"#4fb477",a[0]+" \u2014 "+a[3]));}); b2.push('</g>'); out.push(b2.join("")); }
    if (L.commercial) { var m2=['<g class="nt-comm">']; COMMERCIAL.forEach(function(a){m2.push(pt(anchorXY(a[1],a[2]),"ring",p.comm||"#8aa0ad",a[0]+" \u2014 "+a[3],4.5));}); m2.push('</g>'); out.push(m2.join("")); }
    if (L.choke) { var k2=['<g class="nt-choke">']; CHOKE.forEach(function(a){k2.push(pt(anchorXY(a[1],a[2]),"diamond",p.choke||"#ff922b",a[0]+" \u2014 "+a[3]));}); k2.push('</g>'); out.push(k2.join("")); }
    if (L.ixp) { var i2=['<g class="nt-ixp">']; IXP.forEach(function(a){i2.push(pt(anchorXY(a[1],a[2]),"diamond",p.ixp||"#22b8cf",a[0]+" \u2014 IXP "+a[3],4));}); i2.push('</g>'); out.push(i2.join("")); }
    if (L.dc) { var dc2=['<g class="nt-dc">']; DCHUB.forEach(function(a){dc2.push(pt(anchorXY(a[1],a[2]),"square",p.dc||"#e0a44a",a[0]+" \u2014 "+a[3]));}); dc2.push('</g>'); out.push(dc2.join("")); }
    if (L.asn) { var as2=['<g class="nt-asn">']; ASN.forEach(function(a){var hy=/hyperscaler|CDN|content|cloud/.test(a[4]); as2.push(pt(anchorXY(a[2],a[3]),"square",hy?(p.asnH||"#51cf66"):(p.asnT||"#9aa7b2"),"AS"+a[0]+" "+a[1]+" \u2014 "+a[4]));}); as2.push('</g>'); out.push(as2.join("")); }
    return '<g class="nt-terrain">'+out.join("")+'</g>';
  }

  var LAYERS = [
    {id:"land",     label:"Landmasses",      swatch:PAL.land},
    {id:"cables",   label:"Submarine cables",swatch:PAL.cable},
    {id:"cloud",    label:"Cloud regions",   swatch:PAL.cloud},
    {id:"dod",      label:"DoD / DISA",      swatch:PAL.dod},
    {id:"rir",      label:"RIR regions",     swatch:PAL.rir.apnic},
    {id:"ucc",     label:"Combatant Commands",swatch:"#f2c14e"},
    {id:"bases",   label:"Overseas US bases", swatch:"#4fb477"},
    {id:"dib",     label:"Defense Industrial Base",swatch:"#6a8cc4"},
    {id:"commercial",label:"Commercial tech/telecom",swatch:"#8aa0ad"},
    {id:"choke",   label:"Cable chokepoints",  swatch:"#ff922b"},
    {id:"ixp",     label:"Internet exchanges",  swatch:"#22b8cf"},
    {id:"asn",     label:"Backbone & cloud ASNs",swatch:"#51cf66"},
    {id:"dc",      label:"Data-center hubs",    swatch:"#e0a44a"}
  ];


  // ---- pan / zoom engine (shared by all embeds) ----
  var SVGNS="http://www.w3.org/2000/svg";
  function _z(svg){ if(!svg.__z) svg.__z={k:1,tx:0,ty:0}; return svg.__z; }
  function _clamp(svg){ var z=_z(svg),W=svg.__W||1000,H=svg.__H||500;
    if(z.k<1)z.k=1; if(z.k>9)z.k=9;
    var minx=W-W*z.k, miny=H-H*z.k;
    z.tx=Math.min(0,Math.max(minx,z.tx)); z.ty=Math.min(0,Math.max(miny,z.ty)); }
  function _apply(svg){ var z=_z(svg), vp=svg.querySelector(".nt-vp"); if(!vp)return;
    vp.setAttribute("transform","translate("+z.tx.toFixed(2)+","+z.ty.toFixed(2)+") scale("+z.k.toFixed(4)+")");
    var inv=1/z.k, m=vp.querySelectorAll(".nt-mark");
    for(var i=0;i<m.length;i++){ var cx=+m[i].getAttribute("data-cx"),cy=+m[i].getAttribute("data-cy");
      m[i].setAttribute("transform","translate("+cx+","+cy+") scale("+inv.toFixed(4)+") translate("+(-cx)+","+(-cy)+")"); } }
  function _xy(svg,e){ var r=svg.getBoundingClientRect(); return [ (e.clientX-r.left)/r.width*(svg.__W||1000), (e.clientY-r.top)/r.height*(svg.__H||500) ]; }
  function _zoomAt(svg,px,py,f){ var z=_z(svg); var wx=(px-z.tx)/z.k, wy=(py-z.ty)/z.k; z.k*=f; if(z.k<1)z.k=1; if(z.k>9)z.k=9; z.tx=px-wx*z.k; z.ty=py-wy*z.k; _clamp(svg); _apply(svg); }
  function applyZoom(svg,opts){ opts=opts||{}; svg.__W=opts.W||1000; svg.__H=opts.H||500;
    // wrap current children into a .nt-vp viewport (innerHTML re-render drops the old one)
    if(!svg.querySelector(".nt-vp")){ var vp=document.createElementNS(SVGNS,"g"); vp.setAttribute("class","nt-vp");
      while(svg.firstChild){ vp.appendChild(svg.firstChild); } svg.appendChild(vp); }
    _clamp(svg); _apply(svg);
    if(!svg.__zwired){ svg.__zwired=true;
      svg.addEventListener("wheel",function(e){ e.preventDefault(); var p=_xy(svg,e); _zoomAt(svg,p[0],p[1], e.deltaY<0?1.2:1/1.2); },{passive:false});
      var drag=null;
      svg.addEventListener("pointerdown",function(e){ drag={x:e.clientX,y:e.clientY,tx:_z(svg).tx,ty:_z(svg).ty}; try{svg.setPointerCapture(e.pointerId);}catch(_){ } svg.style.cursor="grabbing"; });
      svg.addEventListener("pointermove",function(e){ if(!drag)return; var r=svg.getBoundingClientRect(); var z=_z(svg); z.tx=drag.tx+(e.clientX-drag.x)*(svg.__W/r.width); z.ty=drag.ty+(e.clientY-drag.y)*(svg.__H/r.height); _clamp(svg); _apply(svg); });
      function end(){ drag=null; svg.style.cursor="grab"; }
      svg.addEventListener("pointerup",end); svg.addEventListener("pointerleave",end);
      svg.addEventListener("dblclick",function(e){ e.preventDefault(); var p=_xy(svg,e); _zoomAt(svg,p[0],p[1],1.8); });
      svg.style.cursor="grab"; svg.style.touchAction="none"; }
    return { zoomBy:function(f){ _zoomAt(svg,(svg.__W||1000)/2,(svg.__H||500)/2,f); },
      reset:function(){ var z=_z(svg); z.k=1; z.tx=0; z.ty=0; _apply(svg); },
      fit:function(b){ var W=svg.__W||1000,H=svg.__H||500; var pr=function(la,lo){return [(lo+180)/360*W,(90-la)/180*H];};
        var a=pr(b.n,b.w),c=pr(b.s,b.e); var bw=Math.abs(c[0]-a[0])||1,bh=Math.abs(c[1]-a[1])||1; var z=_z(svg);
        z.k=Math.max(1,Math.min(9, Math.min(W/bw,H/bh)*0.92)); var mx=(a[0]+c[0])/2,my=(a[1]+c[1])/2;
        z.tx=W/2-mx*z.k; z.ty=H/2-my*z.k; _clamp(svg); _apply(svg); } };
  }
  var PRESETS=[
    {id:"world",label:"World",bbox:{n:78,s:-56,w:-170,e:179}},
    {id:"conus",label:"CONUS",bbox:{n:50,s:24,w:-125,e:-66}},
    {id:"pacific",label:"W. Pacific / INDOPACOM",bbox:{n:46,s:-42,w:108,e:179}},
    {id:"europe",label:"Europe",bbox:{n:61,s:34,w:-11,e:41}},
    {id:"asia",label:"E/SE Asia",bbox:{n:46,s:-11,w:94,e:150}},
    {id:"mideast",label:"Mid-East",bbox:{n:41,s:11,w:32,e:64}},
    {id:"atlantic",label:"N. Atlantic",bbox:{n:60,s:25,w:-82,e:12}}
  ];

  root.DONTerrain = {
    svg: svg, data: {land:LAND, cables:CABLES, cloud:CLOUD, dod:DOD, anchors:ANCHORS, rirColors:RIR_C},
    meta: META, LAYERS: LAYERS, palette: PAL, applyZoom: applyZoom, PRESETS: PRESETS
  };
})(typeof window !== "undefined" ? window : this);
</script>
<script>window.GLOSSARY_CATALOG = {};</script>
<script>/* gloss.js -- Glossary definition overlay. A glossary shortcode in the manual renders as a hover term showing
 * OUR short definition plus a "Full definition" button; clicking it opens this overlay with the complete
 * entry -- the FCD-PAC owner definition in full and every authoritative (NIST/CNSSI/DoD) source with its
 * citation. Pure vanilla JS, no deps, driven by window.GLOSSARY_CATALOG (inlined by the generator from
 * glossary.yml). Kept visually distinct from the compensating-controls (dind) overlay on purpose. */
(function () {
  "use strict";
  var CAT = window.GLOSSARY_CATALOG || {};
  var openEl = null, lastFocus = null;

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function close() {
    if (!openEl) return;
    openEl.remove(); openEl = null;
    document.removeEventListener("keydown", onKey, true);
    if (lastFocus && lastFocus.focus) { try { lastFocus.focus(); } catch (e) {} }
  }
  function onKey(e) { if (e.key === "Escape") { e.stopPropagation(); close(); } }

  function defBlock(tagText, bodyText, url) {
    var d = el("div", "gloss-ov-d");
    var head = el("div", "gloss-ov-dh");
    if (url) {
      var a = el("a", "gloss-ov-tag", tagText);
      a.href = url; a.target = "_blank"; a.rel = "noopener";
      head.appendChild(a);
    } else {
      head.appendChild(el("span", "gloss-ov-tag", tagText));
    }
    d.appendChild(head);
    d.appendChild(el("p", "gloss-ov-t", bodyText));
    return d;
  }

  function build(key) {
    var g = CAT[key];
    if (!g) return null;
    var show = g.show || (g.owner ? "both" : "source");
    var back = el("div", "gloss-backdrop");
    back.setAttribute("role", "dialog");
    back.setAttribute("aria-modal", "true");
    back.setAttribute("aria-label", "Glossary: " + (g.term || key));
    var panel = el("div", "gloss-panel");

    var head = el("div", "gloss-ov-head");
    var htext = el("div", "gloss-ov-headt");
    htext.appendChild(el("div", "gloss-ov-kicker", "Glossary"));
    htext.appendChild(el("h3", "gloss-ov-title", g.term || key));
    head.appendChild(htext);
    var x = el("button", "gloss-ov-x", "×");
    x.setAttribute("aria-label", "Close");
    x.addEventListener("click", close);
    head.appendChild(x);
    panel.appendChild(head);

    var body = el("div", "gloss-ov-body");
    if (g.owner && (show === "both" || show === "owner")) {
      body.appendChild(defBlock("FCD-PAC", g.owner, null));
    }
    if (g.sources && (show === "both" || show === "source")) {
      g.sources.forEach(function (s) {
        body.appendChild(defBlock(s.cite || "reference", s.text || "", s.url || ""));
      });
    }
    panel.appendChild(body);

    back.appendChild(panel);
    back.addEventListener("click", function (e) { if (e.target === back) close(); });
    return back;
  }

  document.addEventListener("click", function (e) {
    var btn = e.target.closest ? e.target.closest(".gloss-more") : null;
    if (!btn) return;
    e.preventDefault();
    e.stopPropagation();
    var key = btn.getAttribute("data-gloss");
    var m = build(key);
    if (!m) return;
    close();
    lastFocus = btn;
    document.body.appendChild(m);
    openEl = m;
    document.addEventListener("keydown", onKey, true);
    var xb = m.querySelector(".gloss-ov-x");
    if (xb) try { xb.focus(); } catch (err) {}
  });
})();
</script>

<script>(function(){
  var LAB="bootcamp";
  var DON_REVISION="v0.0.011 20261112";
  // ---- Debug-log capture (for the "Export Debug Log" troubleshooting bundle) ----
  // Ring buffer of recent JS errors + console warnings/errors, captured from page load so a
  // one-click export shows what went wrong without the student digging. Kept small; no PII.
  var __donErr=[];
  function __donLog(kind,msg){ try{ __donErr.push(new Date().toISOString().slice(11,19)+" ["+kind+"] "+String(msg).slice(0,500));
    if(__donErr.length>100)__donErr.shift(); }catch(e){} }
  window.addEventListener('error',function(e){ __donLog('js', (e&&e.message)||'error'); });
  window.addEventListener('unhandledrejection',function(e){ __donLog('promise', (e&&e.reason&&e.reason.message)||e.reason||'rejection'); });
  ['error','warn'].forEach(function(m){ var o=console[m]; if(typeof o==='function') console[m]=function(){ try{__donLog(m, Array.prototype.join.call(arguments,' '));}catch(_){} return o.apply(console,arguments); }; });
  var __donLastCW=null;   // last checkwork raw output this session (for the debug bundle)
  function key(i){return "donwork:"+LAB+":q"+i;}
  // checkwork goals are always part of the meter's total (denominator); how many PASS comes
  // from the live check (0 until run), persisted per lab. Default the count to the lab's goals.
  var CWKEY='doncw:'+LAB, cwTotal=7, cwPassed=0, cwState='none', cwGoals=[];   // 'none'=never run, 'ok'=ran, 'error'=attempted but grader/bridge failed; cwGoals = per-item [{name,desc,pass}]
  try{var _cws=JSON.parse(localStorage.getItem(CWKEY)||'null'); if(_cws){if(_cws.t)cwTotal=_cws.t;cwPassed=_cws.p||0;cwState='ok';if(Array.isArray(_cws.g))cwGoals=_cws.g;}}catch(e){}
  // ---- Lab duration: ENGAGED wall-clock, not raw first-open -> export. We sum activity "beats" and count
  //      a gap only when it is <= ENG_CAP; a longer gap (a break, an overnight, a closed laptop) is idle
  //      and adds nothing -- so leaving the lab open never balloons the time, while thinking between
  //      actions still counts. The AUTHORITATIVE value is the host bridge's ledger (it also sees the
  //      student's container work and in-lab web UIs -- FRMS, the SOC SIEM); this browser mirror, fed by
  //      the manual's own activity and idle-capped the same way, is the fallback when the bridge is
  //      unreachable at export. Only a duration is ever shown, never a timestamp. ----
  var ENG_CAP=20*60*1000, ENGKEY='donengaged:'+LAB;   // 20 min idle cap; matches the bridge ledger
  var __engActive=0, __engLast=null;
  try{ var _es=JSON.parse(localStorage.getItem(ENGKEY)||'null');
       if(_es){ __engActive=parseInt(_es.a,10)||0; __engLast=_es.l?parseInt(_es.l,10):null; } }catch(e){}
  function engBeat(){
    var now=Date.now();
    if(__engLast!=null){ var gap=now-__engLast; if(gap>0&&gap<=ENG_CAP) __engActive+=gap; }
    __engLast=now;
    try{ localStorage.setItem(ENGKEY, JSON.stringify({a:__engActive,l:__engLast})); }catch(e){}
  }
  var __donEngagedMs=null;                               // authoritative engaged ms from the bridge, cached by donPrep
  function engLocalMs(){ engBeat(); return __engActive; } // idle-capped browser mirror, incl. the open window
  function donDuration(){
    var ms=(typeof __donEngagedMs==='number'&&__donEngagedMs>=0)?__donEngagedMs:engLocalMs();
    if(!(ms>=0)) return '';
    var mins=Math.floor(ms/60000), h=Math.floor(mins/60), m=mins%60;
    return h+':'+('0'+m).slice(-2);   // h:mm
  }
  // Activity wiring: a visible-tab heartbeat (credits reading/analysis) + input/click/keydown/scroll
  // (throttled). The heartbeat also beats the bridge ledger, so pure manual reading is counted there too.
  (function(){
    var lastBridge=0;
    function tick(visible){
      engBeat();
      if(visible){ var now=Date.now(); if(now-lastBridge>30000){ lastBridge=now;
        try{ fetch(location.origin+'/api/beat?lab='+encodeURIComponent(LAB)+'&src=manual',{cache:'no-store'}).catch(function(){}); }catch(e){} } }
    }
    var thr=0;
    function act(){ var now=Date.now(); if(now-thr<5000) return; thr=now; tick(document.visibilityState!=='hidden'); }
    ['input','click','keydown','scroll','pointerdown'].forEach(function(ev){
      try{ document.addEventListener(ev, act, {passive:true}); }catch(e){ try{document.addEventListener(ev, act);}catch(_){} } });
    try{ document.addEventListener('visibilitychange', function(){ if(document.visibilityState!=='hidden') tick(true); }); }catch(e){}
    try{ setInterval(function(){ if(document.visibilityState!=='hidden') tick(true); }, 60000); }catch(e){}
  })();
  try{window.__donDuration=donDuration;window.__engLocalMs=engLocalMs;
      window.__donSetEngaged=function(m){__donEngagedMs=m;};}catch(e){}  // test hooks
  // ---- Hosted videos: set the stream URL at runtime (kept out of the build so pandoc's
  //      --embed-resources cannot fetch + embed the media; the manual stays small). ----
  (function(){function _setv(){try{document.querySelectorAll('video[data-vsrc]').forEach(function(v){
    if(!v.getAttribute('src')) v.src=v.getAttribute('data-vsrc'); });}catch(e){}}
    if(document.readyState!=='loading') _setv(); else document.addEventListener('DOMContentLoaded',_setv);})();
  var shots={};
  // One-time: learn the donlab launcher version from the bridge, for the exported report footer + debug log.
  try{ fetch(location.origin+'/api/ping',{cache:'no-store'}).then(function(r){return r.json();}).then(function(j){ if(j&&j.donlab) window.__DLVER=j.donlab; }).catch(function(){}); }catch(e){}
  // restore + autosave answers (best-effort; localStorage may be disabled on file://).
  // Handles both free-text answers (textarea) and tabular data-entry (input) cells.
  // Wired NOW for the boxes already parsed, and AGAIN at DOMContentLoaded for the ones that follow this
  // script in the page (the Debrief boxes: Independent Research, What You Learned, Feedback) -- before
  // this second pass those three were never saved or restored. Each box is wired once (data-don-sv).
  // Autosave, and make the RESULT truthful so nothing is lost silently: a failed write (localStorage
  //  full/disabled) flips data-save-err, which the writing-box cue turns into a loud "not saved" warning;
  //  a verified write (read back equal) sets data-don-saved, the only thing that lets the cue say "saved".
  function saveNow(t){
    var i=t.getAttribute('data-ans');
    try{ localStorage.setItem(key(i),t.value);
         if(localStorage.getItem(key(i))!==t.value) throw new Error('readback mismatch');
         t.removeAttribute('data-save-err'); t.setAttribute('data-don-saved','1'); }
    catch(e){ t.setAttribute('data-save-err','1'); t.removeAttribute('data-don-saved'); __donLog&&__donLog('save',(i+': '+(e&&e.name||e))); }
  }
  function wireSave(t, noRestore){
    if(t.getAttribute('data-don-sv')) return; t.setAttribute('data-don-sv','1');
    if(!noRestore){ try{var v=localStorage.getItem(key(t.getAttribute('data-ans'))); if(v!==null) t.value=v;}catch(e){} }
    t.addEventListener('input',function(){ saveNow(t); });
  }
  function wireAllSaves(){ document.querySelectorAll('textarea[data-ans], input[data-ans]').forEach(function(t){ wireSave(t,false); }); }
  wireAllSaves();
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',wireAllSaves); else wireAllSaves();
  // Safety net: a keystroke in ANY answer box that is somehow not wired yet (typed before DOMContentLoaded,
  // or a box added later) is saved anyway -- delegated, capture phase, no restore (never clobber typed text).
  document.addEventListener('input',function(e){ var t=e.target;
    if(t&&t.matches&&t.matches('textarea[data-ans], input[data-ans]')&&!t.getAttribute('data-don-sv')){ wireSave(t,true); saveNow(t); } },true);
  // ---- screenshots: persisted in IndexedDB so they survive reloads/crashes
  //      (localStorage is too small for images). Best-effort; falls back to in-memory. ----
  var IDB=null;
  function idbPut(rec){try{if(IDB)IDB.transaction('shots','readwrite').objectStore('shots').put(rec);}catch(e){}}
  function idbDel(id){try{if(IDB)IDB.transaction('shots','readwrite').objectStore('shots').delete(id);}catch(e){}}
  function syncShots(i){var box=document.querySelector('.shots[data-shots="'+i+'"]');shots[i]=[];
    if(box)box.querySelectorAll('img').forEach(function(im){shots[i].push(im.src);});}
  function renderShot(box,i,id,data){
    var w=document.createElement('span');w.className='shot';w.setAttribute('data-id',id);
    var im=document.createElement('img');im.src=data;w.appendChild(im);
    var x=document.createElement('button');x.type='button';x.className='shot-x no-print';
    x.textContent='×';x.title='Remove screenshot';
    x.addEventListener('click',function(){idbDel(id);if(w.parentNode)w.parentNode.removeChild(w);syncShots(i);});
    w.appendChild(x);box.appendChild(w);
  }
  document.querySelectorAll('input[data-shot]').forEach(function(inp){
    inp.addEventListener('change',function(){
      var i=inp.getAttribute('data-shot');var box=document.querySelector('.shots[data-shots="'+i+'"]');
      Array.prototype.forEach.call(inp.files,function(f){
        var r=new FileReader();
        r.onload=function(){var id=i+'::'+Date.now()+'-'+Math.random().toString(36).slice(2);
          idbPut({id:id,q:i,data:r.result});renderShot(box,i,id,r.result);syncShots(i);};
        r.readAsDataURL(f);
      });
      inp.value='';   // allow re-selecting the same file
    });
  });
  try{
    var _rq=indexedDB.open('don-'+LAB,1);
    _rq.onupgradeneeded=function(){_rq.result.createObjectStore('shots',{keyPath:'id'});};
    _rq.onsuccess=function(){IDB=_rq.result;
      try{var _all=IDB.transaction('shots').objectStore('shots').getAll();
        _all.onsuccess=function(){(_all.result||[]).forEach(function(rec){
          var box=document.querySelector('.shots[data-shots="'+rec.q+'"]');
          if(box)renderShot(box,rec.q,rec.id,rec.data);});
          document.querySelectorAll('.shots[data-shots]').forEach(function(b){syncShots(b.getAttribute('data-shots'));});};
      }catch(e){}};
  }catch(e){}
  // Student email for the report: reuse a saved NPS address if we have one, else the
  // caller (an export click) prompts for a .edu address. Never prompts on its own so the
  // headless report test can call buildDoc() directly.
  function storedEmail(){try{return localStorage.getItem('donmail')||'';}catch(e){return '';}}
  function getStudentEmail(){
    var e=storedEmail();
    if(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) return e;   // already have one -> use it
    for(var i=0;i<3;i++){
      e=prompt('Enter your NPS .edu email address (it goes on your lab report):', e||'');
      if(e===null) return '';                            // cancelled
      e=e.trim();
      if(/^[^\s@]+@[^\s@]+\.edu$/i.test(e)){try{localStorage.setItem('donmail',e);}catch(_){}return e;}
      alert('Please enter a valid .edu email address, e.g. yourname@nps.edu.');
    }
    return '';
  }
  // Basic report fingerprint: SHA-256 of "email|lab|done/total". The inputs are NOT printed
  // on the report -- the instructor knows the recipe and recomputes it to verify. Async
  // (browser SubtleCrypto); the export handlers await it before building the doc.
  function donStamp(email){
    var its=document.querySelectorAll('.progress-item'), md=0;
    its.forEach(function(c){if(c.checked)md++;});
    var input=(email||'')+'|'+LAB+'|'+(md+cwPassed)+'/'+(its.length+cwTotal);
    if(!(window.crypto&&crypto.subtle&&window.TextEncoder)) return Promise.resolve('');
    return crypto.subtle.digest('SHA-256', new TextEncoder().encode(input)).then(function(buf){
      return Array.prototype.map.call(new Uint8Array(buf),function(b){return ('0'+b.toString(16)).slice(-2);}).join('');
    }).catch(function(){return '';});
  }
  // ---- FRMS in the Lab Report (cs3670): ONLY what the student did in FRMS (their actions, justifications,
  // changed assumptions), computed by the SAME engine FRMS uses, fetched fresh at every export. FRMS runs on the host
  // (:5174, or this origin in a combined preview); if it cannot be reached the report says so.
  var FRMS_REC={status:'none'};
  function frmsRefresh(){ return Promise.resolve(); }
  function frmsSection(){ return ''; }
  // Every export waits for a fresh FRMS record, then the fingerprint.
  // ---- Deliverable diffs: what the student wrote in each prose deliverable (~/deliverables/*.md) vs the
  //      pristine template, computed by the bridge at export (docker exec diff) and folded into the Lab
  //      Report. The full edited file still rides the .lab. Fails silently off the bridge (section omitted). ----
  var DELIV_REC={status:'none',items:[]};
  function deliverablesRefresh(){
    return bridge('/api/deliverables?lab='+encodeURIComponent(LAB)).then(function(d){
      DELIV_REC={status:'ok',items:(d&&d.deliverables)||[]};
    },function(e){ DELIV_REC={status:'unreachable',error:String(e&&e.message||e),items:[]}; });
  }
  function deliverablesSection(){
    var items=(DELIV_REC&&DELIV_REC.items)||[]; var changed=items.filter(function(i){return i&&i.changed;});
    if(!changed.length) return '';
    var esc=function(x){return (x||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');};
    var out=['<h2 style="border-bottom:1px solid var(--rule);color:var(--accent2);font-size:1.15em;margin-top:1.8em">Deliverable changes</h2>',
      '<p style="font-size:.9em;color:#9aa7b0">What you wrote in each prose deliverable, shown as a diff from the template you were given. The full files are in your <code>.lab</code> submission.</p>'];
    changed.forEach(function(i){
      var meta=(i.container||'')+(typeof i.added==='number'?'; +'+i.added+' / −'+i.removed+' lines':'');
      out.push('<p style="margin:.9em 0 .15em"><strong>'+esc(i.file)+'</strong> <span style="color:#9aa7b0;font-size:.85em">('+esc(meta)+')</span></p>');
      out.push('<div class="a" style="white-space:pre-wrap;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.82em;overflow-x:auto">'+esc(i.diff)+'</div>');
    });
    return out.join('\n');
  }
  function engagedRefresh(){
    // Pull the authoritative engaged "time in lab" from the bridge ledger (cross-surface: manual +
    // container + in-lab web UIs). Cached into __donEngagedMs so the synchronous buildDoc stamps it;
    // if the bridge is unreachable, __donEngagedMs stays null and donDuration falls back to the mirror.
    return bridge('/api/engaged?lab='+encodeURIComponent(LAB)).then(function(d){
      if(d&&d.ok&&typeof d.active_ms==='number'&&d.active_ms>=0) __donEngagedMs=d.active_ms;
    }).catch(function(){});
  }
  function donPrep(mail){
    return frmsRefresh().catch(function(){})
      .then(function(){return deliverablesRefresh();}).catch(function(){})
      .then(function(){return engagedRefresh();}).catch(function(){})
      .then(function(){return donStamp(mail);}, function(){return donStamp(mail);});
  }
  try{window.__donFrmsRefresh=frmsRefresh;window.__donFrmsRec=function(){return FRMS_REC;};
      window.__donDeliverablesRefresh=deliverablesRefresh;window.__donDelivRec=function(){return DELIV_REC;};}catch(e){}

  function buildDoc(email, stamp){
    var esc=function(x){return (x||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');};
    var _em=(email===undefined||email===null)?storedEmail():email;
    var h=['<!doctype html><meta charset="utf-8"><title>'+LAB+' report</title>',
      // Match the MANUAL's dark theme on screen (owner 2026-10-18: the report is read on screen, never
      // printed; it must always carry the manual's dark palette, not an invented one). Tokens mirror
      // docs/theme/theme.css :root (the manual's dark tokens) so the report looks like the manual. The
      // The report must look IDENTICAL on screen and as an exported PDF (owner 2026-10-20): dark bg to the
      // page edges, only text light. html carries --bg so @page{margin:0} + full-bleed print body leave no
      // white margins; print-color-adjust:exact (inherited) keeps every panel/box background in the PDF.
      '<style>:root{--bg:#000001;--panel:#16212c;--panel2:#1b2836;--ink:#dbe4ea;--muted:#8aa0ad;--accent:#5aa9d6;--accent2:#8fd0a6;--rule:#293a48;--code:#0b131b}',
      'html{background:var(--bg);-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact}@page{margin:0}',
      'body{font-family:sans-serif;max-width:760px;margin:1.5em auto;padding:1em;background:var(--bg);color:var(--ink)}',
      'h1,h2,h3{color:var(--accent)}h1{border-bottom:3px solid var(--accent)}h2{border-bottom:1px solid var(--rule)}a{color:var(--accent)}',
      '.q{margin-top:1.4em}.q .p{font-weight:bold;color:var(--ink)}',
      '.a{white-space:normal;overflow-wrap:break-word;word-break:break-word;border-left:3px solid var(--accent2);padding:.4em .7em;margin:.4em 0;background:var(--panel);color:var(--ink);line-height:1.5}',
      '.a u{text-decoration:underline}.a ul{margin:.2em 0 .2em 1.2em}',
      'table{border-collapse:collapse;margin:.5em 0;font-size:.85em}th,td{border:1px solid var(--rule);padding:.25em .5em;text-align:left;vertical-align:top;color:var(--ink)}th{background:#00337a;color:#fff}tr:nth-child(even) td{background:var(--panel)}',
      '.rpthdr{text-align:center;margin:.1em 0 .3em}.rpthdr img{max-height:64px;border:none;margin:0;background:transparent;padding:0}',
      '.rptprog{background:var(--panel);border:1px solid var(--rule);border-radius:6px;padding:.5em .8em;margin:.7em 0;font-size:.92em}',
      'img{max-width:100%;border:1px solid var(--rule);margin:.4em 0}',
      '@media print{.a{break-inside:auto}.q{break-inside:auto}html,body{background:var(--bg)!important}body{margin:0;max-width:none;padding:.5in .6in}}<\/style>'];
    h.push('<div class="rpthdr"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUoAAADkCAYAAAD+SG0vAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAAAGYktHRAD/AP8A/6C9p5MAAIAASURBVHja7F11XBvnH37eu7hACO7aQt1W29qua9eua7eua+fuvv3m7u7u3m2ddFvdV3d3CrQBglsCcb+73x+BQEgCCVDP8/nkA7m7nL73vF//EoRxViMlJUXM4/EiKRclJ5QrguVoCQhENKDgADEAEcApOEBEUZBwLCJBgSIc+ByBDADAQQZwfIDQAIlw75mTABAGOCwNIKKD02IB6DtYbwKIE2A5ADoAIICNI8QKABxHDIRwDMcRF0U4I8cRM8dxDgLSBIqzE5ZYQHEGAHaOZY0UIRbOxTdCDINKpTKER0UY7UHCt+DMQEZGhojn5MWA54zjgHhwVCwhbAwHJACIAiGR4LgoAApwJBIEkQAUAAThu+eDpmaiNgCcASAGAHoOpImA1YIjGo5wGoqiNITj6jknT2MjNm1lZaU1fOvCRBnGCUZWVlYkcZJUjnAJIEw8OBJDCIkF2HgQEgcOMeAQC4IEAPLwHTu54AAzATQgqAcHDcBpOBANAacFR9WD4hpYhmgpjqpheEylWq22he9amCjD6ARpaWlRfCCLgM5iwSVRFBI5IAscyQK4LABR4bt0RsMGoBrgSgDUEEKqOZaUEKCGA1PN47iaooqK6vBtChPlGU+ENE33ohnkcoTtTUBlcmDTAZIGcEkA4Z0u1yIScBAKOETIWACAWMRC0Hz2kXL3MgEPEInc/8vEHGia87uvyOZ9BMI3f0eEB4+3lFoOkGpwXCUHlFAgJRxhSxhCStRqdW34LoWJ8pTHsGHD+MaGhlQXeFkA249Q6AuOywJIFoDMk32PI6QslJEMImQs5FI30ckl7v/l0pb/3R+xkINMwkEg4CATsxCL3OQol7An9Jx7TUsLD6zgYQdQBXAlIKSEY5uJFEyJ1G4vPFhXZw7fojBRnlDkpqdnMoQM5DgygAM7iIAMBJANtxf3hEl2EXIWkTIWcUoGcUoGkTIWMVEM4qPdhNiyLiGGAZ/HnXb3OUyUPQYWgBogBQBbQEAVcWCP2BmmsLKysjF8e8JE2e370is9PY8hZBQ4cg4BOxAgAwBEHq8DUhQQE8UgOdaFpFgGibEuJMYySI5zIS7aTYTKCAZCAXfG3/wwUZ4QNADIB4cijsJ+iuMOSGy2g2EJNEyUAZGTkxPBOtiBAHseRbgxHMhoANE9eQw+j0NaggvJ8QyS4lxIiHGTYFIcg6RYF+KjT0/pL0yUZxxqCLg9IGQPWLKHApN/tLy8JEyUZyEyMjIUPOB8DpgAjpsAkH49cS8IARJjXMhMcSEj0YX0FCeykp3ITHYhOc4Fmj677rPJLoCTpcAwBAa7MOB2dhcNi5Pv+f7G+xw4zvtxWG0EDpf3MoeTwGYn4DjAYKbCFHfcwFUCZCdAthPC7RSapXvyG/JNYaI8A68zJzNzEjhugpscMRTdsCtSFJCa4ESfTBd6ZzjQK82J9GQXMpOdEJ1GqrHJLoDeJmz9WJu/W4Uw2IWwu2iYbEKYHHzYnDwY7EJY7DzYGB50FiHsDA2Lw01wBrsQDEPgZCmY7N2LYWc/fKfLvzVaKLAsYLFRcLkAu4PA5iCwOwisdgKjiYK1+X+TmYLVRmC1U7DY3N/NVgoGM4HRQmAwUTCYKVisYRJuBwZAPsDtIIT8qFKrt5/pF8w7G55qv9h+UhtrXtmV30rELPplO5Cb4UJuhgN9spzone6AWHRqEaLZwYfGLEGtQQqNRQyNSYwGswT1BikazBJoTGLPcp1NBJ1FBIY78+bJFg99ZyFIIbECCxibSdNgpqAzUtDqKDQZaOgMFDQ6Go16Go16Ck16Clo9Db3pjCZXGsBAgAxkWVQBCBPlmQBbhE0CV3Cqc1aKE0PyHBiUa8fgPg70SnOAPklj3slQqDbIUdEkR1lTBKoNctQZpc2kJ0GDUYw6k/t7W9U1jB5mBQpQRLBQRARPvi6GoFFPodFAQ9tEQav3Jtb6Rho1DTRqtTSa9HT4JoeJ8hTQExhG4m8o0jSHAb0cGD3QjuEDbBiU60CE9MTFDDZZRSjRKlCtl6HGIEWpNsr9v1GGEm0kyhojz0ip76x4sWjOE76FjE4mcgdBTQMPdVoKNQ081Gho1Gvcf2saaNRoedAZwup/mCiPM/gcJ2bbmWMfvlGPWy4zQio+fsRod9Eo1kbhWIMCKo0SxQ1RUGmjUKyJRKU+Ak4mPPjDcMfGZiY7kZkMuOPH/ZNpdQMP1fU0ymt5qKjmobyGj/IaGmW1fFht4Qk1TJTdBMtxEhDvgTSwt71HSJLhCEo0UcivjW4mwSioNFFQNShQoYsAG5YIw+ghMs1KdkdR+ENDE42KWh7Ka3gor+WhvJoHdTUPpZX8cERAmCiDJUpaQhGu3cALbR8cB5Q2KpBfG9P8icWRumgU1EXD5jzzbmOv5Ggcq9KeVS+D0S6AXOg4Lc89NopBbBSDoX18JVK9iYKqnI9jZXxU1vFwrM3/XDh0N0yULaB5EHPthEeRkOtQSiysi8aeygTsrUjA7op4HKiOh9lxdjhMIiRCfP/ITJz/+HdnzYvgZCg8tegCfHnlyjPu2iJlLIb1tWNYX28SNZgpFJUKcKSEj8IS999jZXw4XWEt6KwkSo7jJO2XiYW+avfsXf3xw45B2F8V1+1YwNMZ00bmYdyATAzKSsSBkpqz4poXH8nBL7v74f0ZayHhO8+OCVHKYnh/G4b3by2L6WIIjpXzsXG3CO//rAgzZDPOCuNFc0uDTiXKlYVZ2FySclaTJABcfm5fAMCtk4edNdf8w/ZBsDj5WFmYcXZLTjSHPpkOjB8eril81hEl5Uei9EeU1uMUixghEZ4290ok4GHK8N4AgBsvHAKRwFvpIISAzzuz4v4qdBFYVZgJAFhwMPe0OvewszCsevfo++9LCL5EaXEcn9vxyb2X4o6P5oFh2VPqpijlYjx/3QRESISIkAgh4NOIV8ghFws964/99BiEfB54NAWFVISfVu3BfZ8tOq1J8dEFE+FiKQh4DOQCO4q1Ck+86uIj2fhq6xDQhIVCbAdFOCglVozNqgSfPrWen94mxB/7+uCe0fvDTBYmyhOpovf87Czk83DN+IFYu78Yv67Zd0pdb6PRis8WbsUPj87CBYOy/G6TEuOuLOdiWDzz4yq8M3fDaf2MUxUGvDltAy7/8XIcqYvxWa+zinD/P5M937Oidfju6uWnHEkCwCcbz8Hu8sTjQpQME9x2hHCus4Ebzg4bJUf5xHw4nb6kyKeZHj/2kJxEiAQ8vHjDBPDoU+92l9Y2YeJTP+DuTxbAZPUfGqM1WDDluZ9Oe5JsQa/YRmx7+Fdc1l8V+MUgHO4afQAHnvgRF+SUn3LXYLAJ8enGYdhWlnRcQnycTJBCA0fOCs/X2RGJSnE+D9PpZx4UHAepYVSeu7ZiTlI0rh0/yCNl9kqOxqShORjWK/kUmEg4fLtsJ658/Xe/6/9YfwBr9hWfUUNCLnTg31vnYUBig68WwGOw6aE5+PrKFZAKTj4P1BhkPrbITzcNQ6NFDK1ZDJVG2fNE6QyOKDkKjrOBQs6W8CAHaadW+5sxBbyekSiFfB7S4iKRmaDEjGYPMgB8ct8lePv2i5ColIMQgi35ZZj6/M+nzH0KRNrXXTAYT36/Alb7mSU8VOrkOFLrq37bXTSixadOi+71qlTc+dfFSFYYkRFlQIZSj38P9vas/+9oOrJimkCTnhMtna7g9kVxXJgozxyBknJw7QaRvxlT0E3Ve/KwXvjsvkvRKzkahPjuP0omRpTMHam0/mAJLn3xl4Dq7snApaPyAABNJiv+9+USXDIqD1eNGwClXIwrx/bHL6v3nVHj4scdAz1OnJHp1eDTLDaXpAAAlhzJxqNxp0ZbmWuHFkDAY3Ddr5fhWIOv9PjAv5PxyIILkaowIENpQFa0Do+P34He3Tj/4IPOqbOCKMOqdxt010a5as8xnPfoN3j3742wOwPbuE9FkoxTyDA8NwX7VNUY/sAX+HXNPlz9xh+Y9sJslNXrcPe0kWfUkHCxFH7YMRBSgRNvXbIemx/6DWvv+wMvXrQFFOGwJD/nlDrfWQOPYv6t/0LE9z+unAyFEq0CFOFw33l7u0WSIaneHMJEeSap3j4vij/VuwdslBq9GU//sBID7v4Ey3cd9bvNn+sPnlIkCQCXjMzFd8t24dxHvkZxTetLtmxnEfrf9TF2FVWib1rcGTMmluRnY3haLQqe+Q5PTdgBmnDgUSxevmgz5t06D/m1MWiyik6pc57atwQ3Dsv3u25URhXW3f8HVt3zJwYn13Vf9Q5WZqDCqvcZRZTtVWGHq+dV77Y4VqXF+oMluHh4b591z117AX5etbdDqfNEY+3+Evy4co/fdSarAw9/veSU9Np3FcNS6zBjwDG/66b3V2FA0q+o1MkRJT51MlQazBL8sa+P33XfXbUC/RI0PXasYFVvjuPCXu8zBTRNO4NRLXo6PGhEbkrLYML7/2zCpsNqAEBqbCTuvHj4KXWP1HVNnaurDHvGjIlUhaHD9ZlKnV+P+MnEu2tGetJrs6ObkBPT+sx2lSf26LGCJUqKC9soz2jV259Xr6fDg0bkpoJhWdz1yQI88d1yjHvsW4x97FtsPFSKZ68dD4kw3L4hjOBQa5Tiqy1DkKow4KMZa3D4qR+w/eFfMSqjCgCwu6KHiTJIG2VY9T6zmNLRvuGkPxtlT0qUCVFyxERIcPkrv2Hx9kLP8s2H1Tj/8e9w6ag8nNs3Hav3qcIsEEan+G7bILxw0Rb8b+wej0NHyLNi1d1zMeuny7GrPKGHJcquCyFhojxdeZLlOUAxJ1T1zk2NwUXP/uRRt9ujLXmGEUZneObC7eBRvhqPTOjAojv+wa1/TIODoXvMzh50eFCYKM8o1dve/rHb7L4DoSezMDYcLA2/3WH03ItKBTYLCXkMfr1hMVw92IPJ5gjWmcMLE+WZAiIk+vbtavV++ohEScI1+E4FfLvNneoZIXKAJmwb6cnpJfWL+YxXXGGkyA4+zSJCZIeQx5w1BXgBgCYcaF7PaUR6Y5Cl9DjowkR5hiC1uLixIj2DQxtDpd7ohyjFYaI8FXDP31N6bF8yoQN8ioVCbAOfx0IucEDEd0HMZyAXOiATOBAptiNSZIdcZIdCbIOi+XuE2IFIUfP/Ivtp20+nKzAYg5NOeSyv6Wy4H2cFUa4HXNmACYDcMxBM/iRKe5ilzjC0hNP0RPA4TTjEyCyIllgRI7MiWmJDrMyCWKkFSqnVvU5sRYzMhjiZGfFyM8T807MKmd4UFFFySdVHdUfDRHlGoaktUfobCEqJNcwsYQQEwxHUGaWoM0qBIJNfIkV2JEWaECczIznShDiZBUkKI+LlZiTKTUiMMCNVYUSE6NSapHXGoGyUhvXAWVGP8qwhSg5oJEBaq+pN+5Eow6p3MFDIRCAgiJAIQdMUpCIBBDwaYiEfIr57SElFAgj4/u1cCqnIb9EQL4nGbAPrp9CizmT1qr9otjngcDHef52t30+6ZGYTQm8ToqAuusPtIkR2pCqMSIsyIFVhRHKkAelKA1IiDUhXGpGm0J/Q4sGG4CTKprNlzJ81REnaPVT/EuWZS5QKmQjRcgmiIyRQyiVQysWQiYWIkokhEwvcH5EAkVIRIiQizzK5WAiFTAyKEChkotPuuv0RqMnmgNFih95sg95sg9HqgNFqh8lqh95sb15m92zTaLRCa7Qc1zJzBpsQ+bVC5Psp+wa4vd5pUQZkReuRFa1DZnQTspQ6ZMXo0Sumqccl0iBV78azhT/OIqIkjRy4NgPBV6KR8J0Q8hjYXad+86yYSCniFTLEKaRIio5AbKQUiUo54qNkHjJ0/xVDKReDpiicjZCKBJACnvJ23YHF7kSj0QKtwYJGoxUavRnadt8b9GZUa42o15nQoDf3WNqni3VXByrRKgCk+6xPkJuRE9uE7GgdsqKbkB2jQ6/YJuTGNnaJRHWmYN4BEpYozzzVm21qm52jD+DVixLbUGuUnrTz5PNoJCnlSI1TIDU2EikxEUiNVSAtLhLJ0ZFIVMoRp5CecZ0QTwdIhHxIhJGePkKdjjmOQ73OTZ61TUbUNrrJs0qjR02jERUNelRq9KjWGrtdIKXWKEWtUeqpp9mCpydux5vTQmvh4WIIrLYgbJSEC0uUZ55ISRrbCJQBVYsoyfEnSrlYiJzkaOQktXyUyEmKRnZiNBKj5aBIuAXpmTHkCOKjZIiPkqF/RnyH29Y1mVClNaBKY0BFgw4VDXqU1jahpKYRJbWN0BosXToHURe87jpj0NpHWKI88yRKNLWlH7OVgosh4NFcO4myZzzfIgEP2YnR6Jseh6wEJbISo5CVqERWghKZCVGdOjPCOLvQQqhDc5L8rrc5XKjWGlBS2+gmz5omz/+FFQ0w2/zHeHZF7Q7SPgnChm2UZ97s7mf205soREd6e0aVPRBLeemoPCx65abw2x9Gj0Ek4Lkn2kQlMMR7HctxqNIYUFrbiJd+WYP1B0tatZcuBMkbgyRKLixRnoFEyZLG9n1zmvS+RJkQYe72sYwWR/jN9gPG5cJ/q/5DWVkZ7HY77HZ3lIHNZoPd7p6grFYrHA4HOI6D0eCuGWm322GzudczDAOTyeS1X6lEAh6fj+joaERHRyMxKRHZOTnonZuLXr16gabPbHsuRQhSYyORGhsJpdzbaRXZBYmyoSlY1ZvowkR5hoEFqSHwJspaLY2cNO+Qj5ROCroGpbpYztwwI47jYDAYYLFYYLFYoNfp0NDQgPq6emi1GtTV1kGj0YDP5+Pe++/HgIEDPL9dsmQJHnv4kRN6vpGRkRh97rmYecUVOH/8+Wc8aTaZvE1HkeLQibK6ITha4ECqw0R5pr3gNFdB2kVq1DT4vjSpPUCUOtOZkeGja2rCKy+9jCP5+WhqaoLVaoXVGvy19erdy4sozxszBjNnzUJVVRWMRiNqa2rQ2Hh8zVx6vR4rli/HiuXLEZ+QgLvuvhs33HgDaN6ZOfR1Zu9JOqILqndtAx30OxUmyjMMSqWyWqfRMgA8o6BGwztORHlmSJSHDh3C4kWLQvpNv/79MXLUKAwYOACTJk/2WhcTE4N3P3jfa9mxo0fx9BNP4sCBAwH3OWLkSNxx552Ii4+DVCYDj6bBMCy0Wg0qKytxtKgIGzdsRGFBATgucD/qutpavPbKK5g/bx6++vYbJCZ2ryp4UWERjuTno1ilQnFxMcxmMwwGA6wWC4QiEcRiMUQiIeLi45GamorevXPRf0B/pKSmHj+ibDdJd8WZUxOkROl0OsNEeaZhz549zuz0jDoAHrdibb0foowydftYBosdHMeF7NnW6/WorKhAbU0tGhoaoNFo4HI5MWXqVOTl5Z3wezZm7Fh8/d23MJvNoGkaJqMJKtUxzPn1NzidvlkqM2fN8iHCzqXO3nj8qSdx43XXd0i+Ey6c6LM8IzMDw845BwDwxFNPoa62Fr/PmYNffp4No9EYcH+HDx3CzOmX4a9//kZaenpI53u06Cjm/Por1q1di+rqrmmecfHxGH3uaIwaNQqjRo9GalpaDxKl9yTdFRtljSYoidJSWVkZ9nqfkeo3UEHaEKW/AdETEiXDsjBaHYiQCIPa/tfZv+CTjz6CTqfzu/7br7/BQ488jDvvuuuE2tgIIbhw0iSf5fHxCXjnrbd8lo8bf36XjpORmdnJg+OC2k98QgIeeewxXH/DDXj+ueewdvWagNs2NDTgrjvuxL8L5kMq7TxutqK8HK+/9hrWrl7TodQaDOrr6rBw/gIsnL8AAJCSkoLBQ4Ygr08ecvPyMOyccxARERH6+OY4GCz2dhJl6Kp3TRCqNwHKzybuOKuIEuAqADKyowEh4TuhlFjRaOleypvebAuaKPfu2ROQJAHA4XDg/XfexZr/VuO9Dz5ARmbGSb2LUy+Z5pcoeV20+0kkkg7Xs1xoaYBx8fH45rvv8MG77+Hrr74KuJ3q2DF89803ePjRRzvc35LFi/H8M8/6eNs9UltkJEaOGoWcXr0QFxcLHs/dNE6j0aCqshJlZWU4fPgQLGb/QeOVlZWorKzEksWLAQByuRwbt26BXC4PWZNh2NZ7xaNYSAWhESXDAvVNQUzGBBVnE3OcZURJvB5uIO9eqsLYbaJsMlmRGhtcqtub77yNSy+7DFpNAzas34AVy5f73W7f3r24dOpUPPn007jhphtPWtB6UlISxBIJrBbvF99m7ZpttjOJrisSHCEEjz/1JPR6Pf74/feA283+6WfcfuedAUlp+dJlePR/D4Nlfck6IyMDjz7+OC6aclGnziHG5UJBQQHWrF6NpYuXoKSkJOC2JpMJVBdy8/XtHDmxMgtCHSINjTwwTBA/4s4uojyrKiVQ7WZBq534zUJIVRi7fax6XfC2TrFYjAkTJ+DKq6/G5199ibvvvSfgtlarFa+89BJuvuFG1NbUnpzphhCkpqb4LO9IKu5wtubxOpRGWbbrqu5zL77QoR3SaDRi65YtftepS9V4/NFH/ZLk2HHjsHjZUky9ZFpQHnSax0P/AQPwv0cewco1q/HTL7MxcNBAv9umpacFZQ7wHXPeMcDx8tBjgoO0T551EuXZVVKGJRW+A+P4eL5rGrtOtvc98AAEAkGH22zdsgXTpkzB8qXLTsqtjI2N9Vmm1Wq7PhA7kKC6YxMUiUS44647O9ymTF3md/mnH3/sCYRvC0VUFD75/DOIOzEZdDTRjB03Dv/Mn4/X3nzDhxRzevXqkTGXIA89P7ymPtheOVyYKM9UMLSvAbqmwfcW9ETQeY2260QplUrRt1+/zlUtvR4P3n8/nnzs8YD2s+OF6OgYP0SpOT5EyXavVNnEiRM7NFP4I2KbzYZlS5f63X7yRZO75Gzxd83XXncdfvvjD9BtqkGlpKR0kSgNJ0yiZDjqrHLmnFVEybKszyzoz06ZodSfVIkSAPL6BB8ONO/ff3Hp1GnYu2fPCbuXymilz7JGbdejRchxkigBtze8o9jFmFhf0s8/fBgul//KOwkJCT16LwcMHIDzx4/3fE9OTu6RMRcnC50og87KocIS5RmLsrKyOgBebsDyar4vScV1PzystqmbRBli3GRFeTmuvfpqfPLRR2Bcx7+NiVKp7FHVu6PCwqF6vYM1FbSgT58+vs+vNrD9V6VS9fj9HDbsHM//XY2rbE+UXZEoSyr4wWk9ZmllmCjPYKESgNcoL/YzMHLjG0GR7kkx3ZUoc/P6hG5acDH47JNPcfWVV6G8rOwkqN6nno2yBS6X/zYOCYkJyPNDlDQVWAVdtWIliouLe/R+jhk7BjRNQyQSYcjQoT0y5rpS4EVVEZREWZ3fkG86m4jjrOsPQEAKvInSd2BI+E6kRXXPTtkTqndXw3/279uHS6ZOxd9z555Q1VurOV42yu4RpcvlQkmx/3Ccq66+2u+x0zPSO9zffXff06N56v3698eylSuwZPlyxMTEdG3MtbOLx4eoelusFOq0wRCl9zsUJsozEBzYgvY2Gavdl5D6xGu7dZzuOHMAd9BxUpJvEde4uLjgBr3ZgmeefAoP3HsfdE09XzYwOtq3q6DZbIbN1rVYSkIFnhTYbjpzli5Z4tfZpVQqcdMttwSQ6POQkBjYFlmsUmHWjMuhOnasx+5pdk5Ot5IJuitRFlfyg0yCYsNEeeYTJQq8X0JAXeXPTtk9ojRa7T4BwCGr334cOrfcdhuefvbZTsOHWrBi+XJMu3gqtmze0rMSpdJ/+9WuSlkEoXmlg0VjYyM+ePc93+MRgldffx0KhSKghHvd9dd3uO+K8nJcOXMWNm3ceNLHNcOyPrG76SFqRcXBqd0gQGGYKM/8Cy4Ixi6T102JEgBKarqnmuX5sVMWFRbijrvuxLxFC9E7t3dQ+6mrrcWtN92Et998028xiy5JlDH+iVKr6dp9o46DM0en0+G+u+/2W7zigYcexJSpF3f4+9vuuKPTUB2j0Yg7br0N77z1FhyOk1ewuVJj8OpjHiezQBZiibVgHTmcn3coTJRnGCxOZxHcTp0OB0ifuO4TZWld91Ref97YI0eONJNoHuYvWoRbb789KFsmy7L4/tvvMGvG5T3iiJDL5X6l2q7GUoYa59gZ9u/bh1kzZmD3rt0+x/nfI4/gf490XkBYJBLh86++hFDYcc4+wzD47ptvMePSS3EkP/+kjOv2k3KGUhf6PiqDI0pXmCjPfFRXV1vQrvKJyh9RngISpT/Vu6Sk2GMHFAqFeO6F5zH7t187tKd5EW1+PmZccmmH+c9Bq9/RPRciRHrAmcNxHPbu2YMH778fV86c5ZNxExMTgy+/+RoP/u+hoM+r/4ABeP/DD70CwgPhaNFRzLxsBj7/9LMTEqLV0VjLVIbujAzS460rKyurCRPl2YF2nm9fooyWWhEj616l8tLa7kmU6enpEIu9i3MwLgZHi456LTv3vPOwdMUKTLvkkqD2a7Va8cKzz+GeO+9CU2PXz9GfnbKrqneoEqXRaERlZSUO7N+Pv+fOxUsvvIgJ54/HVbOuwPKly7x+I5ZI8MBDD2Lthg0+xYSDwcXTpuKTzz4LqjqSy+XCxx9+iMsvm4GDBw6eOKKsbS9RhpY0wTBAeU1QRFl4NhIG72y8aA6kgIDzGKjUVTwwDNC+1GOfOA02mbpejbq7EiVN0+jVu5fPC1dYUOBTUCEyMhKffP4ZJkyciJdffLHDwrUtWP3ffzh48CDe++ADnDfmvJDPz5/nu6sSZUe9zFu83lu3bMFDDzwYtBc/Ly8P02fMwOWzZnYYcB4Mplx8MX7+9Rc8eP/9QU0uR/LzceXMmbjx5pvw2OOPdzkv/ESp3mW1fDhdnZtwyFmodp+1EmV7h47TRVBW6ytVDkxq6NFZvkvqd15gO6U/XHb5DCxZsRwjRo4Mav/1dXW45cYb8dYbb4bsjPCbxth4HCTK5qZwarU6IEnSNI3snBxcNmMGnnvheSxbuRJLVizHXffc3W2SbMGo0aMxf9GioPLw3VIag59//AlTp1yM7du2nVCiTA9RojyqDrqh2FlJlGenRMkxBSDec0RRCR9Zyd4e4WEp3Stjpq5tAsOyHabnBSMV+dgNOiBKwJ0r/Nsfv+P7b7/DRx980Kmnm+M4/PDdd9i2dSs++uRjZOfkBClR+gZGdzXfu0Ovd7NEed3112Pw4MFoatLBbDZBoVAgIjISkZGRiIqKgkgkOu5jJyUlBf/Mn4cP338fP37/Q1AxnhXl5bjxuutx0y0346lnngk6tCu0Sdl7AsmMDs1GefhYcEWmCXd2qt5npURJBIJDaOf5PqzyHbznpHaPKB0uBhUN3Suw4a84RmFBQacvKEVRuOueuzFv4QL06h1cGNGR/HzMuHQ6fp8zp8sSZVNTF6Xojjz3bUyUffv1w3ljzsPkiy7CiJEjkZeXh8TExBNCki0QCAR4+tln8evvc4IuYMFxHGb/9DOumnVFj6eX6s02aPStweV8mkVmiKr3waPBEaWL4g6FifIsgUqlMhDgaGcDpW+CBnJh92LjjpTVd1P19iVKs9mM8rLgqlz16dsXCxYvwi233RpUGJHVasWLzz0flKPHn42ysYvOoWAkylMNI0eNwrJVK3H9jcFXmz986BBmXDodO7Zv77HzKCj3NhHlxDRBQDMhaFhAviqo0KAGtVqtDhPlWQQWnFeA3aFjfLR/HynCYXByXbeOk99NolQoFH5DfwoLgjcVCYVCPP/ii/jpl18QH2SJsNX//YdpU6Zg86bNgYlS6Y8otT3+rBiWOWXHkVQqxSuvvYrf//oLmZ01SWuGwWDArTfdjKVLlvTIOeSXeY/RviGGtqmr+TCYg6KCXWcrX5y1REk44vXQzVYKpX5KrnVX/W4/iLukfofo0AmEMWPHYOmK5bh42tSgtq+vr8etN90U0NHjT/W2mC1+q4IHo5oGXHeKSpRtMXzEcCxevgw333pLUNKlw+HAow8/jDX/re55okwILej/4NHgAs0JCRPl2ciUu33UomO+dsph3STKw+qeIMrQHTodSaifffEF3vvgA8hksqAI7IfvmjN62tVh9Kd6u6XKnm33zDDsaTGkRCIRXnjpJfw4++egipcwLgb/e/BB5B8+3KNjLC8uNKLMD9KRw3JcmCjPNtgZZh8AZ2dEeU43Pd8F5fVgu1lP0V+GzpEuEmULLp81E0tWLMfwEcODu44jR3wcPcoARNnU40TJnFZja+y4cVi6YgUumjKl021tNhueevyJbuXgtzfv9E0ITfU+FJx9Eiwhe85WvjhribKystJKgCPeKogvUfaKbYRC3PUqQBa7s9sZOv4kyrra2m5LbikpKZjz5594+tlnO81nBlodPXffeSeaGpsglUr9ept7WqJkWfa0G19Ryih88fVXePLppzttPVtYWIh//v67S8dpMllRrW0NBaIJh96xwd9/hgXyi4OSKMvVanXt2coXp1Uc5bBhw/i6Ol064bNZYNlUDlQUIZwcgJDjiBmEqwfHHRVZZLuCqcDMgdsFkEEeKa1YABdDwKO5tnYZDEutw5qj6d1QjWqRnajs8u+zsrIgEAh87IQFRwq6lFHjNVNSFO64606MO/98PP7oo0EVdVjz32pMOzAF737wAZRKpU91nq4QZUc2ytNNomyLu+65G0nJSXjs4Uc6vI7ff/0N1153XejSZDu1OyumCWJ+8HnmqnIBrLZgMnLIriDHaiRh2dGE47JZjsRQFMQcR1wcxxkJSCMIW8lSVAlN02qVSmU/XZ7jKUuUWVlZkRTLDgYwlOO4IQCG6DSaPNCE5666RdxUx7XSnjvejsAmMTPZ6RkrOXBflJSVBe7nSshucLjDowY5CI6V89En05uQhqfWdJMo63DZ6L5d/j3N4yGnVy8fEis4cqTbRNmC3rm9MW/hAnz2ySf4+quvwLg6JqcWRw+fz/ejendBgu6AKFn29CVKALjk0kuh1+vx0vMvBDZtFBSgqbEJUcqobqnd/UJVu48FqXZ3Yp/MTk+/HKDuB8NeAIDiQEBIy2PlmsNkOQAEFMuBY11MdnrGUQLs40D2cRyzzwXsLS8vbzoVn+EpoXqnpKQoM9MyJ2VlZDydnZExNzs9Q0UYtonjsJ7j8CFAbgRIf4AES+w0gKkEZGlWRsaijIwMhV+e9PPwD/sZOGMyu9dwbs+x6m7fo5506AScNXk8PPLYY5j7zz/IysoKSgr05w3vStC5owMbXVe86F3Bzz/+hBFDh+H7b7/r8X1ff8MNGDN2TMfSnSr0aul7Vd5ja2iINvU9+cEF6hPinyh7J/WOyUrLWAmQeQA3MQROoQH04YDrAO49QqjVfEI1ZqdnlGanZ/ybnZ7+XHZGxpScnJzYU4GjTrRESWenZGeCx/QnHNeXBYYAZBgBMlslwp4F4XApDWzIysoaV1JS4pUmExkTc0in0VoBeEr07D4swpWTvUvoj82uBI9i4WK7Nq/sKup+w7q84+DQCYRBgwdj4dIleO+dd/Dr7F9Crgep04WejdRRnrnFYj0hg/PrL79EY2Mj/lu1CnfcdWeP7/+mW27tMC7V4QjdobPrqPfYOic1tApo2w8GZZ/kGEL2+ozJ5ORoF8+xiQB5PXibMtwfMhMcwDldyE7PKAewByD7OLBHQNOHSkpKigGcMFWDl5ubKy8qKjL22FVmZIhoF50C2pUKjkoFQRrA9gZIPwB9AEbs5sSOiv8HRqxShNREOdKSpFDIhZCKeZCI+TBbXahtMGPfEQ1KK30uZyBh2XcB3O01m+7Z48zOyNgNDmNblm074Dtw5EIHhqbUYmd5UpfuSaVGj2qtAUnREd0gSt9YypbalMcjfU8sFuPFl1/GxAsn4eknnkBNTfAvoEEfOlHarIHJ0GI2H/cXobq6Gprm5mhd7OnWKQYMHNDheolEHNo9c7h8QoOGpQYfjlaj4aGyLihZ6Yharda1X+ik+R/AD0lmp0VicF40EmLFkIj5sFidMFtd0BntKK82o7zaCE1TSA7SNPeHu5yAAAyL7PQMOwcUUMARlkMRoVDGsWwlR9OVTqezvLKyssdm15ycnAie0+Z4Kzs9404AGgI0cCAaAuhYQEcAHSGci+M4B8eRltEqoii3BMYBUQAUYBEJQmIALgUc4kEzbhuip+Vr6COPpgmyUiPRr5cC/XKU6JsThb45SsilndtUDhRq8doXe7C/oE08GYfbMzIyPlKr1YXt9Mf1ABnbfvCkxHsbxMfnVHSZKAFg99EqTB/ds0TJuBgcO3qs0xewOzhvzHlYunIFXnvlFcz/d15wRGkIrSCD1WLpsCmZRqMBx3Fd7koZlK2vTSyjSlUMl8sVVP3J0MZ04OK/fD4fvXNzQ9rfvuJqONvYkjOUesRKLUH/3p9QEECgXNd+SVZK1gAQ9qa2y4YPiMNz9w5F/96dOy6NZieOqBpxRNWEw8cacUSlQ0mFHgwTtPYiJMBgDhhM3O4KEEKBsByENA/Z6ekaAlLFgWsAIU3gOB0AHSGEBQCWRRMhHI8QIm/mMhFYKAAoQKAAuGiAxABcDOd0fsRjCfc8zeEKAEkckNRS1Ip4eMRNdG3HqI8m5jHUdlGspQl6ZSjQv5cS/XtHoV8vJXIzFRCLujZQB+VFY84HE3HFg6tQUNzUOk45bhaAN9ptvg6Al5V920EhrpzkTZTnZ5fj3bUju3yNu45WYvroPl3+vVKpRHR0tE+9x4MHDxxXogSAiIgIvPfBB5g0eTKef+bZTr3a+hAlyoaGhk7Vcq1W2+U2rsGgbTdFXVMTFsyfjyuuvLJHj3H4UOB6EuePHw+pVBrS/nYWtle7Q7NP7jwYnCbCAevbL6N47BUc1yoBDchV4pf3JoDPC848JZfyMXJQPEYOim+dMG0uFJXqkH+sEYePugn0mFoHF9MVbiExHBADEI+Tty13ufmMeHMZge8XjlSIrNJXeWq1WpedlvkkCDf7ROj6UZFC5GYqkJ0WidysSPTrpURepgJCAd2jxxEKaNwwvTee+2hH24sf5iOVEbKN5mADIGo7gK6c1M5OmVUJPs3CyVBdJspumzUyM32IcsP69bj+hhtOiJ1m8kUX4Zzhw/Hyiy9i2ZKlPaZ6HzzYeSXwA/v2Y+KkC4/btVVUeDvs3nztdeTl5aH/gJ6ZhFiWxVdffOn/lSYE9z5wf7fHVKiOnB2HgrNP8pzCDb7Xg1FthaerpuYETZIBzT0iHgb3icHgPq0Tot3BoLCZPItK9FCV6XFUrUOT/sQ4+AjIo/kN+SYeABSXl/6anZ5xN4Bzu69eEMQqRUiKkyEhVoyEGCnSEqXITotA70wFohUnrhxWZISPmj6i/QK1Wm3LTs/YAeD8lmX+DNyyZjvljrKuqd+7iiq7rT76SxnctnUbTCZTUOmIPQGlUolPP/8cU6dOw0svvOC3onkoEqXJZMLPP/7U6XbvvvMOIhUKDBo8yG9IUndRWVHpYz644drr8MLLL2HmrFndem4Mw+CVF1/Crp07/a6/5dZbMWjQoG4TZSiOnOqGoO2Th45WH22fE0kTwp3bVgRLjpMel/EmFNAYlBuNQbneY1+rs+FoqQ6qMgMqas2o1ZhR22BFVZ0ZmiZrKCp8R3PEalW5+h+g1evNUQSPshy2tRVAB/eJwaTzUuB0sbDaXJ4Tb5H+IuQCyCV8yKV8RMgESIyVIlYpAk0TnAo4WurzwibnJOekqKpUld5mSqwjpJUoazU8lFXzkZ7k7YW8IKe8y0TZaLSipLapW4Hn/gq+Wi0W/Pn7H8fFS9sRpky9GCNHjcLLL77oUwWnI6JkWRZvv/kW9u/bh7raWtTX1weVvlesUuGaZlVYLBZDJpMhIiICEyddiCeffrrb16PRNPgl8acefwK/zv4Ft91xOyZNnuzTw6gzFBQU4JUXX/TpBtmCCRMn4MlnQj9/vdmGY1XaNlJpaI6coO2TBD72yZz09IEciNfMfKS4CeOGJ56w8RetEGH0kASMHpLgZ2Ji0dBoR3W9CUaz0/2xOGEwOjxSqt3BeKRYPo/Cf1sqvX0aAEuApzzmwZZ/jqnVO7IzMv4BB49hRl1lxA2X9YZUfPoVQncxHBasVvsReZlRAP5pJwWvY1nu5fZqSXuiHJddjrfXjOryOW3JL+sWUQayDX76yccYMXKkTx+d425GUUbhk88/w9RLpuGl51/weI0ZhgHjcoH24wyxWCz45eef4epGl0Kr1Qqr1YqGhgY4Xa4eIcq4uDifpm1tbYuP/u9hiEQijD73XAweMgT9B/RHSmoqUlJSPOmfHMdBo9GguqoKO3fsxLq1a7Fzx46Ax5x1xRV47c03uiQhbyso9wrb6huvQVQIqba7DgWt2fnYJ1lCRpF2AtvitWrceWWfU0JIomnKrc3GBjepmSxOfDe3oN38gNmqsrK9PkQJAIRhnuEo+jIAAgDQGez46d9CPHBD/9OOKL//uwDl1b5RTyzhzm1PlAKJZLvNZLYA8HSA2nFQhKsu8s6CHJNZ1S075YaDJbjpwiFd+m1tTS327vFfk8BituCKyy/HgAEDEKlQQCKVwOl04o4778TwESOO+72+aMoUjBgxEq+98goWL1qEESNH+iVJAJDJZJi3cAH27d3bPKh54Av4kIjdt14eEeFXzTUaDT5ta4UiEYadM6xHruG1N97AC889jy2bNweMG7XZbFi3di3WrV3rs47P54PjuKAmgLj4eDz1zNO4bMaMLp/vhoOlXt/HZoZmAw/SPsnync5NvkImfKSFohIdfp5XiNuv7HPaccVP/xZBZ/CyeVrg4r3YdoHXaFZVVBRnpWd8QQBPd/gf/ynETTN6I0ImOG0ufM6io/jgh/0BNAmMb78sPz/fkZ2esR3AhM7slGOzKrH2WFqPDO7OcCQ/HyqVCocOHMTSJUs6DKFhWRYHDhzwWpaQkHhCiLJFuvzwk4/x4ssvQR7RcRhU3379gm7QdaKQmpaGn3/9BZUVFVi4YCFW/7cKR/KPBJ1nHoz5IDUtDTfedCOuvvbakD3cnY2lMdnBZ48VV/CDtU8eKKyq8jVCc61mqrZ4+9t9EIl4uP7SXqcNV+iNDvz0b/s2QNwH7c1zPnfLwbheF9K8W+COkYTB5MCP/xTi4VsGnvIXXd9oxSuf7sbKzR0OmkEpKSnKysrKdnosWQdwE1r3ReNYGR+90r1fgKl9VF0myuKaRlQ06JEaG9nptgsXLMBjDz/Sob0yOjoa8gg5ZDI55HI5ZDIZ5BFyKCIVSM9Ix9Qg+3z3JBRRUTidkZKaivsffAD3P/gAdDoddu3cifzDh1FYUIhjx46iuqo66JJoiqgo9O/fD0OHnYPzLxiPAQMGdFpJKBhY7E7sOVblLVFmBS9RrtsVnErqLywoJzU1mwP8Fj7gOOClT3Zh655avPTQOYhTik/55/393wUwmLyywup4ItF77bfzIcrKysrGrLSMTwiBx2b387wi3DIrFwq58JS82LIqE378txD/riyGzc60e9gELC0AzXhEa0rI440DsKCdTLYWIK+1XbJmp9iHKC8boMLjiyZ0+Vw3HVbjugs693BmZ2cjKysLVqvVbQtLTUFqaiqyc3KQm5uLzMzMgOptGD1E+goFJk2ejEmTJ7chAw4NDQ1oqK+HTqeHzWqF3W6H0+WEgC+AVCZFbGws4hMSoFQqj8t5bckvg6NNoHlWtA6piuCD/NfuCM4+SXHEx5HDEd6EtjHTDC0EzTq8gqtXbq7Ahl3VmDU5C7fOykNGivyUfL5Nejtmzy9qf4Xv+ctU9PumOVjXZ0Ka9xgAOeA2dv6+6Bjuu/7UsVXWa61Yva0SC1ersTe/wW/xGZbioS7pPIjNdVA0Fbad+ia2J8risrId2enpGnc0vhvrd4pxz5XeAzA7ugm5sVoUNUR3WWUKhij7DxiAVWvXhNnqFAMhBHFxcUFVMD9eaK92jwtB7dabKOwtCErgsUrsFl9jLOEuaPvVENULdqES8dVbQLhW8rbZGcxZfAxzFh/DkL4xmHFhBiaMTkFirOSUeZa/LToGi9XV1izXSItE3/rb1i9RVlZWNmanZ34LcI+1LJs9/yhuu6IPREL6pFwUw3AoKG7C2u1VWLu9CvnHGjuqzAWbKAb1iSPhFESAA+VNlCBTATzY/hAgZBk4eNKy9hcK0aSnERXpLaVe0q8YReu7SpQlYbYJo3tEeaidfTIreKLcsFsEhgnGM03WHqyra59kTwGY6GUGkCbBJopGZfpFiKvbDqHVNzJj3xEN9h3R4KVPdyM1UYbzhiVgwqgUjBmWAAH/5BQwszsYzFnULsqB4LNAdS8C6m481vWhi6IfACAE3AGeC1ercfW07BN2MepKI7bsq8WWPbXYurcWJkvntiEXX4rG6H4wRmR5qhvYJHFgKR4o1jN7ZGVmZuaWlpZ6yd2EJUs4wnmIkmGBDXtEmDHBe7xM7VuMD9Z3zUlSVKlBTaMRiUr5afVyMgwDk8kEh8MBm9UKi8UKp9MBk8kEl4uB0WCA0+X0NBez2WywWMxeXmCn0wWLxftesiwLozFwTRahUOhT9EMsEkMgbHUuikRiCAQCyCPk4PP5kEllEIpEEAqFkMll4PN4kMvlEAgEEDXHYHaUd30qw2p3+lSjGheCfXL9ziAlOsItbr8oJz19JAfEtVW7bUK3ecEhjERV6iTIDWooGo+A7/D/TCtqTPhziQp/LlFBIuZh1OB4nDc0AecNTUBOeuQJu4//rirxKszBAWa+0/lZQD4M+EJXVFRnZ2TMBoe7Wpb9+E8Brrw4CxR1fGKlrDYXtu2rw9odVdi4sxrV9UEm+BMCqygWhqheMMtSwBGqnV2FglUSD6mp1QBOc9xUAN4GCgG9Ek6XA83hUQCwbqfYhyjHZFZCIbZBZ+1altF/e1VdDhPqKmw2G3RNOjTpmqBraoJep4fRaIDJZILRaILRaITJZILJZIRBr3d/N5rc600mWC0WnEmQSCWQyyMgl8sREeH+2/KJiIyAvM2yyMhIREUpER0TDWVUFMSSk6c+bjykht3ZOvmkRRmQExNcrVuGBTbtC2rMcsTJ88lR5QCv9p1WaaJXqSWOUDBEZsEYkQGpsRwROhXE1sB5/BarC2u3VWHtNvd7GRctxvnDk3DBqCSMPSexy7UeOgPLcvjx7/aebnzr18PfGVG6xTP6PdDM7XAX2URxhQHrtldj4rnJPXbSJosT/22uxPKNZdi6r87HGdMxOcbALE+DWZ4CF6/jwWuRJnoRJecmyo/abqNSqQzZ6ekbAeJJKt64RwSni4DPa9Xz+TSLKXml+HNf12LGlu0s6jZRarVaaDVa1NfXQ9PQgCZdE/Q6HZqadNA1NaGxsRG6pqbm5XpYrVaE0WY8mC2wmC2oqw29DYxQKESUMgpRiigoo5VQKqOhiFIgKkqJqKgoxMXHITY2FnHx8YiNjQ2qH1GwWL7be26fkhd8yNmeIyLoDEGpuvvbh8e0MVm13kNJYgCWpWCKyIApIgN8pwkyQxkkpmqI7NoOK9nXa634e0Ux/l5RDKGAxqjB8Zg6Pg2Tz0sNqmpYsFi9tRLqKi+J10G5eB929JsOibK4sliVk565gAM3y2OrXFDUbaJkWQ6b99Ri7rJirNtR5Ukn6nRGpEWwShNgkcbDIkkCwwteorNK2z9UMs5fLU6OI0sIwYWtRE5h12EBzh1s91G/u0qUq/Ycg4thwaO9B63VYkFdXT00Gg00DQ2or6+HVqtBfV3z3/oGNDQ0QKvRdCuzJYxu2rfsdtTW1KK2JjiSjYyMRGxcC3nGebzi0dHRSExMhDI6GokJiZBIO5dUl+/ytqtdlFcc9Hmv2xFsNXP4qN25qalJLmBI240sss5TFp18GZqi+6Epuh9oxg6xpRYSUw0k5hrQjK1DG+KGndXYsLMaL/B3YvzIZFx1cTbGDU/stkY7e377DCzuL/8TQ7ASJQAO7BcA8RDltn21KKk0ICsl9NqKNjuDP5eq8PO8IlTWdtr7CxzFg1UcC6skHhZpIhxCRZdvjpMvg1MQAb7D48UWuGy2CwHM974h7GIG1Mft7TrtifLivJLgsnQ4DjRjA89lBe2ygWasgNaGBx5+HDyXDRpNAzQNGtTV15/y6i1FEcilfPB5FMQiHsQiGgI+DZmED5oiiJALwKMoSKU8CPm0x/EnEfPBa5faJhLSEPK97YR8AQWJkAeW42A0OdupjSxMFu/JoW0NAqPJCSfDwmRxunN57QxMZvcyo9kJh5OFze6C2eLsYtmurkOv10Ov13uVcvMHsViM+Ph4xMbFIrbZsx4b2/w3LhZOSgRVeS1A8TyazcRe5cET5c7g4hpZhlriI6RQ1MVoUwfCLooCQ4cmKTO0ECZ5Okxydxim0N4EsbnW/bFpQFj/k7/DyWLV5gqs2lyBlHgpbpmVh2um5XTJsawq02PnQe+ceJaiPu908ghm59np6YfcPWvcuGVmLp6/L/jUMY4D5v9Xive/34/6xo5VQBdPDIssGWZ5KqziOB97Y3cQXb+vnfeb+664rOwu3+vNyAfg6QaWmuDC2h98+95M++5KrDycAr7T5CFCvssI2mUFz2UFz2EGz2kGAXdKEJ1cykdUpAhRcgEi5ALIpHxEygWQSXiQS4XNf1u+8yGXChAh40MmFXgI8kyAw8nCaHbAYHLCaHLCaHHAYHTAaHbCYHLAaHbAaGkupmByoslgR5POjiaj/YSV9+rYgEjDxRNDHkljysBqxEczSIl3IU7JIC6aQUaSCzKJd4vfglIBpj+QEMzua4rL1MloV2A2Oz1jHoDLW743RfdDY0zPJaEQjoXYWgepsRISUxV4ro55IlYpwpN3DMGMSZkhVaR/+bPd+G2hl0S5t7hMPaxHiDInPf1+DsTDuhEyAbb8OSMoY6vZ6sIjb27xGGz9SnsCOUyyVJjlKbCLoo/bAJNYapFYsa7zQZGR8Q44PNl22f3XGuByAXVaGg1NNMpreKhq4OFkNQjk8yhERwkRr5QgWimCMkIIRaQAUREiKCOFUES4P1ERAs9fmj5r27j3GFiWQ5PBDp3Bjka9AzqDmzy1Ohsa9XY0GWxo0NpQ32hDg9YKnfHkEGukjEWskkF8NIPUBBdU5Xzszg9GAuS+Ly4r8ypF1a9fP4HNZNagOa4aAKrSJsEmPn6FlIU2LaTGSsiM5eA7A2ufk85LwYfPnBsUF1msLpx79Xzv6BmO3FxcXvpLjxBlbm6u3GWzVwLw6NtvPjoSV03N7lSSvPXptdi8p9avwdcsS4Yhshes0vgTMngIxyJD9W/bMCEQgkfBcYQjJA0c0kCQQjhkcUD0iR7chLjLR0VHiRAbJUKMUoSYKBHioyVQKoSIj5YgJsq9TBEhDLPWaSK9NjRaUaexQNNkQ53GCq3OhtoGCzQ693dNkxVanR0se/I1D47gHTDUvyzNVqjV6loAyEpLm0gItdozWdBClGZffvyaC/mQZiMi9CrIDWV+1fMJo5LwzWvjOz2d35ccw4sft20myWkYQlLVanWnZZeCvtLs9PTPAPJAy/eBeUrM+3xKh7/ZsrcWNz+51kdt0Ct6QRfdN2QbRzCgGRtolx08l9ltG3RaW22ETiuE9kYQjj2hg08kpJEY20xySjHilGJEK4SIi5G4/yrFiG1eFpb6zk4wDAutzo56rdUjjdZpLdA22VCrtUDTaENNg5tsTyCh2gGuorlNdEbLQps4Fpq4oXDxJO53+AQRJs3YEKU9ggidyisLCAD+/GgSzhnQcWfb6fcsxxFVU1vB5B2VWh1Ujb6gA5UIx33NkVaiPFjYiKISHXKzFAF/s+ewdwwVS/FRlzwGFklC8HeH40CzDlCsAzTjAOWyN9sDreAxNtAuC2iXDTzGAtppO+H2QImYh6Q4KRJixIiPliApXoL4aAniY8VIipUiPkYclv7C6JwEaApx0WLERXfscHExHOo0FtTUW1BVb0JtgxW1Gguq682oqbegtsGCxp6zowoBkuMz8VsbkFK2slnwIWBoERie2P2hhXDxxGBoMVx893eGJ4aLJwZHuhfkz9AiaOKGwhiZiaTyNaDYVhX60FFth0R5RNXkRZIAWJrjvgn22EETpaq8PD8nLWMnR1rbKfyzogTP3Tc04G/aVw+hWCcSK9aBpXhgaBE4igZLeOBonmc9OIBiXSAcA4pxeN2ME27nkQsQHyNGUpyb8OKjJUiMkyAhRoLEWAkSYiWQSfjhtzyMEwYeTZAcL0VyvBTnwD8x2B0MqustqG1obo9Qb0atxk2iLYRqNPfMe0U4zu24dHUep8tS/GYyFYClBGBpARhKAJbmgyV8gAAsJWhmMb7bRMZxoFgnKNYBnssCvt3oVytURnYc+vTPyvZhVGRdUZk66CDUkELfWQo/Ea6VKBeuKcWTdw0O6A31V6bdTYguUKzppA64SLkACbESJMU2S4OxklbJMFaCpFjJccsMCCOM42rTE9DITJEjs4OqPWarCzX15mZCtaCmwYyqOjNqNVbU1JtR02AJPvkjSFCsE5TDieMhWowYFLhIicPJYtGaMm9FFexPoew/NCagqD/AsB+guRJ4o96ONdsqMWWs//qM6ckyZCTL20fBH/cZN0YpQmKsFHFKMRJiJYiNFiMhWoL4GBHiYsIkGEYYUjEPOemRHeZXN+rtbhKttzSTqBk19VbUaMyo01hRr7UGnSxyPNE7M7LDqkRrtla2r2Cutzmd848bUZaUlOhz0jPnc+Cub1m24D91QKIEgPNHJEHtU/Mt9BlSGSlEdLPHNypSCGWk+/9ohQhRkQLER0sQqxQjJkp0omzLZyXMVhc4jvNrcjhY2AiGZTGkb3BhI7sONeC/LZWw2NxqoNXKIDKCjzHDkjBhVGsTt6Xry7C/QOtVaSZCJoCmyYan7xoCmiYorjBgx4E6SIR8CAXu7aKjRMjNVCBSLgg/uC5AGSmEMlKIvjmBizHrjPZmx1OrA6qh0e3Nr2+0orE5bKpdcdwexfgRHTf8m7+6nYbN4c/q6uqQsjtCFqtYjvmJEMpDlBt3VcNgcgRsFXH+iCSf4pi/vT8RkXKBl9GZ4wABn4JExINUwoeAT0Em4UMi5p0xgc6nAlwMBx5NsHZ7NYQCCi4XC4PZHXCtNzqgN7mDruu1VmSlRuC5e4fiYGEj3v1+H3YcqMOIgfF4+/GRfoly+cYyaHW2oIly+IBYlJQb8NxHO3DZhRm4aWYu3v12P36ZfxQP3zLQ06tp2vh0rN9ZjfmrSnHlxdnISJY3azNVeO5et408OzUCtQ0W3PzkWmQky3HBqGSs3lqJeq0VLz1wTqehbIA70+f7uQVYvbUSZqsLOWmRePT2gQGz0BoabbDZXVAqRKdlA76egEIuhEIuRK+MjrdjGBZNhua40+a/Lf/b7C6PZGqyuMCwLDiOg8HkhEzCh1hEQyZx+wsoiuCFj3b6cExHRL5pV007xRg/hXqdIT/dkvLyddlpGRUgSG3R/1dursCVU/wPxJGD4iAW8TypZgBwRNWI267oE2atHkKdxgKaphAT5WvQrqwzY/6qUsxbVYIBuUo8eecQpMRL8cz72yEW0khLliMuWoRFa8oQoxDh/hv6gabk0OrtKCl3p3sOzFPi4vPTsH1/HUYPiUdqov8e4pt316Ci1oxX/8cEnV4WHeWOCEiKk2JQbjS+ff18TLp5Mb76PR93XtXH0xq5pbr++JFJuGhMKgCgb47Ca18tvaXPHZKA5+4digdu6I+LbluCVz7fjXHDkzrtyvfyZ7tQ22DF7HcnwO5gcM+LG6FS672IkmE4/LKwCLP/LQKPRyE+RoKyagMoQjCoTwxmTc7C+JFJ0Ops2H9Ei6R4CZSRQsilAkjEZ6+5p2V8+hujoWDOYu80UJmEj2H9A9snV26shNPl5fg5ekyt3nHciRIAC0Lmti3qu3RdWUCiFApojBgYhw07W1MA12yrDhNlCKhtsOKIqhETRvsvRlJRY8brX+3BnA8u9JFsUuKlePDG/piz6ChGD0lASrwUHAdcd2kO/ndzawrauu3VEAhoXD+9dxvVuL5VDWsOcXI42YDSVWGpDhwHrN1Whanjg+sr1NJDpqWojFTMwwWjk/DX0mKUVBrRpyX8rHk93aYgwiXjvcWYFqlE2EzSkXIBZl2UhW/+PIIdB2tx2cTMgOeh1dkwd1kxfn1vImQSPmQSPh67bZBX4RKGYXHvy5uwfX8dPn1+DMaPTPIyIzz13nbwKDXGj0xCtEIEk8WJS+9ejmiFCG88OgIXnpvivtc7qrB6ayViFCLENtvRoxUiSEQ8ZKdH+uTFh9GK9hl+Y4Yldni/lqz3duIQgj+7ctwu6bQcS/5q+33b/jqvIpg+6vdwb9F49+H69sbVsxJanQ0HCxuxYlM5fvq3EK9/uQc3P7kWX/95xGu7HQdr8fHsgwH3ExUpwOGjjbj/5Y3tZ08PemUoYG/jxbx1Vp7X+giZwMeONHxA60wtbzattNUM2kuTF4xMAo8mWLRWHbykQbWxvTQjPtptmI9WCNuYfLhmyYS0kVK8X5AWEm+RQgEgpVn65diOyaeg2E3ybe/fgNxoZKe1SpMf/XQQa7dV4bX/jfAiyRYzwkfPnouk+FanQkpCq4TbQpIAcMHIZHAc8MWcfKzfWY25y4vx8BtbMOO+FV6tcgtKdPh3VbgifgusNhe2769rp3YHrmDU0GjzKYABlp3blWN3SRcoqSjZlZ2ermoJRmUYDss3lOPGGb39bj9hdBJe/QJe6svG3TWYPiHjjH6om3bXQF1lQkyUCDMnu6WZ869fCIZloTM4wKMpmCxOKCKEmD4xHdEKMfr3plGn8bYzHz7qDpbdebAeIwb6qhktAe2b99TiyXe244NnRvuUooqPEUHfnHdMCHxsypFyAarqzGBZzm8Zq5Z6gLZARLmnFhePS4fDyWLDzmrojPagmtG1HKttmkCD1oq45gwmH6LsoIthi0TZVu1vIZ6BfTpu9CURuX/zyexDGD0kATyaQCrmeST0eq0VP/5biKyUCEyf6H/cDsqLRmGxzvO9qVkYiI/1VTdtNve5PnjjAAzKiwbLcvjwxwNe9nhVmQ7vfrvfbz3G+kYr/lpaDE2TDUlxEkwZm4b0ZBkOFGnRL0d5Rkqlm/fUennZCQHGDQ9MlEvXl4FpWymK4JCqrDz/hEmU7gFI/m77ffG6soDbpiTIfGK6OiqScbqA49wdIEsrvcOfCkp0uOTuZThQqIXOYMPzH+2AxeoCy3KIVYrxxiMjsfbX6di74ArweRRkYh5evP8c3H99Pzxxx2BcfmFWO6J09yH5eZ7/6AGFXACRkEasUoTF69R48+u9PtskREvQZAjseYyUCcCyHAxm/9vIml9Ui92XKN31RWswakg8LhqXBqeLxYoNwfVxIc0hCi2EZrMzWLOtCndf29f7GM0Dfum6Mnzz5xF8MScf7363z5sonYyPRHmoqBEXjEzutCxg/97RkEv52F+gwdvf+N6/hWvUcDhZTDw3ucOoiinjUls1hiY3Ufpr29rQrIG1SM8URXDNJd5JMBXVJmh1Nnz262Gf38cpxbh8UgbmLDqKAb2VSE+WwWBy4KqHVmHQpXNx+f0r8PAbW/DhTwfxz8oS7DpUj3rt6V28uT1n5GVFIT4mcFjQ4vaaDcf91dVjd9m6zNHkL8Jyz7R833ekAVV1ZiTH+2/sfv6IJJRWtr7om3bXgGHY0ya3ubTSiI273O0pKmtMUFcboa40wu5g8NRdQ3DnVa021+c/2IE7r+zrGfiZKRGo1VqQnijDU3cN9lJpE2IlqK43g2E4jyo5ME/pRULHyvQYNzwRa7ZVorLWhJQEb2cKTVMQCXj44qWxuOXpdfh5XhFilGLcc03fNhKlBJX5gcvyy2VuIjSanH4lQVmzZGW2uPyorU2QS/lIjJVg0rkpePnTXVi4Ru3z4vsnytZJZ/ehBvzwTwGum94LN83I9drOxbpV4pYQoboGC5h22Rl2h/u73uiAi+FQWNyEHQfq8ceHEzs9DwGfwt3X9MX7PxzAz/OK0Ctd4dUfaucBt722b6+O+5a3DUXS6tzEFOsnLbGh0QqaJohVCr0ECi+irHW3IPllfiGunpaN7FRvsne53NL/0H6xHhPYly+NQ2aaHJpGG7bsqcEXcw4jM0UOkZAHVZkeTheLB27oj4dvGeiOCmi0old6JJLjZYiPFvuYM04VsCyH9TurfDglECprTThY5N3ZgWPouV09fpdZqrS09ACAI22lq2UbAhcRHT/S2xGhNzqwv0B7ykmIgaS2zBQ5poxNxa8LirB2exU+e3EMds+bhe1/z/QqQGs0O3GgSIvkhNYJY/rEDIiFPNA05UWSAJAcLwXDcKgLMNuXVhmRECPGLTPzwDCcn+rMzS9oBB+xSjE+f3EseDTBBz/s97JvxcWIO7QLt7zgeqN/iVLaHA7kr8Hbpt01GNQnGnqjAyzLoXd6JPbkNwTV86jlteTAISstAp++MAYP3NDfR2pjXG6JcvqFmbj7mr549eHhGD/Ce0zZm6XdP5eqMOrKeZhx3wpMHpPcodTRFnde1QcjB7krWb382S4Ul+vbkJYpoHQY2Abtvt+xUb6/0TTaEB0p6lBQqKgxYew5iXAxHF7/Yo8fqdSKhBixx9Rw7pAETDzXLT2PGBiHjGQ3sV4/vTcWf3Mx9i28Ek/cMRhpSW7tbuLoFHz3VwGufWQ1Fq0pDZgjfrRUf9LfzUNHG9HQaAuaKJeuL2/XdYLsKaksOXbCibJZGvBSv1dtDqxujRgY5xMesWl3zSlFlLUaC979bp+PjbCtVJabpYDTxSJSJoBYxENMlAjTLkjzsYkt39g6aQgFdMDMgaQ49/Jqn86gLWq3FrlZCowZloDURBn+WVEMs9XlR/0WolZjxbjhiXj90ZEAgGc/2IF1O9yzcEKMBDpjx6o3AOgDBAZLRDwQApit/oiyFtv21mHGfStw5/MbYGo2MywOwqnDeezW7gDnQDGzzmaibGt7m9guCqAl5e6F+4Zh17+zMHxAHH5dcAzl1cFlhtE0hc9fHIOMZDmcLhYfzz7ks++ObKS+ROl+sWOVIh9bqt7kJqXlG8qx61A9dh6sR2W7MVBRY8JLD5yDmCgRNu2uwZqt3hJVncaK1ES5jx25BeU17utOT5Z5bLfXXpKDAb2jPNK83cFAwKdw51V9fM4TcDvIbn92nd8x117IOJ5YvbXSZ2If2jdwJcRVm3y46K/uHL9bROmCt6v9QKE2YAVzAZ/CyIHedSc37q4+Ljf1iKoJvy85hg9/OogHXtmMKbcvxXnXLMD0e5b73PC2KC43wOFk8d3cgoDbZDbP0uXVrbnq0YrWARYhEyA7LRJzlxXjja/2djqAWkwVVfWmAETZhLysKFAUwdXTcmA0O/HPCt8+KcpIEWo17hftiouy8NBNA8EwHB56bQv2F2gQHy2BroOqMnKpmygDSZ0URSAU0NAbvYnSYnXhQKEGy3+YhnW/TsfCr6bg9w8vBCEIiihbjO2BvPWtROV+Uak2RNne6dQi7dI0ASHAY7cNgt3B4PUv9wQ9dqIihfjipbGgaYL1O6o9Jc2iIt33R6u3Bb2vlkiQmHYSZZ3GAo5zE9vG3TX4+OdDuPGJNRC1sa06Xe46lmlJMjzcHMb1xtd7vcKz6jQWpCXJAh6/vNo9HlokyJbx2StDAcDtcGxotCIjRR5Qsv17uQo1DRaUVhg6vNbnP95xXIly7XbvSeK8YQkBz7lea8XBo1pvrZtwf580olSr1YUgONTWjrCmAydNe1f+4aNNnlk3VFTUmLBiYwV++LsAfyxVeVWS7psThYwkOb6ccxhNBjvmfDARbz8+EjUNFjzwyiYcKNQGIEq9R3ULFO6U0eyUKqsKXNTj/hv6AQB++rcQ97y0ocPZOKmZKKvrLAGIshG5mQroDHYM6O22Xf6yoMinJqEiUoDahtZJ6sEb++Omy3vDanPhjuc2wGBywNBBxZgWab9RF5hMhQLaJ4Ro+/469M6M9LLNJcZKMLhPDApLdCgq0XVMlM22R6er45zhFkcNrw05chy87q2HKJu3OWdALM4fkYS126s7dR6q2zjkcrMUmDg6BVabC9ZmSbJ3uptcDhU1hkSUAj7lE2HQYmYZNSQBbz02EnM+mIhn7h7qFYxdVWuGUiEERRFceXE28rIUKK824sd/Ctrsx4a0xMBEqa4ygKIIUhP8b1NWbQLHAVmpEQGkeBZf/3Gk2QQUmCjLqkxYuFrdYS+iA4VaH4k5WFTXW3zGUUdq939bK70EFA7YqVar1SeNKJtH6wIvEXlLZQd2yiQfA+3m3cG3Cy2tNOKDHw9gwCVzcdFtS1BU2oRDRxvx0ie7MOW2pahq8yBGD0mAWMSD3cEgWiHC2HMS8eIDw+BiOPy+yL+poqTcgGnj02GzM/jhb/9SZWZqM1FWGzwS1dxlxWCY1pl++oQM3DrTHae4ZmsVrvnfqoAtAZLipAFVb5blcETViAdf3YQrH1qFL347jKyUCJRVmbBue7Wv6t3gTbYv3HcOLp+cCZ3BjjufXw+niw04mD1E2YHEJOTTMJodXoNw4+4ajBrkW6F+6vluc8Tvi48FJVG6nFwnEqWbsNoSY2GpDtV1rROWuY1E2YKn7nTngr/25Z6A1XCcLtbHDJSeJHM3UGu2/1001u3NXrKuLOjmZLUNFkRF+tYeqK53P+v46FZinDY+3VsQqDV5alPSNMGz97hTNb/8Pd/jva7XdiJR1piQECP2ypFvT6QAfJxEHmlyRTGiIt3OptKKwOaLjbuqYbMzOFrqf1JkWQ4vf7ary6Xd1rTTAgkBxp4TOCzIh4MIFnSX5nqCKBe2/bptXy3yj/mfdVMSZD4PZeOu4O2UmSlyPHrrIERFCEBRBA/cMAAfP3cenrxjMDRNNnz+22Gvm5mWJENFTeuLdOHoFAgFtMd24yNRVhhwx5V9kJkix5zFx/yqoRlJ7vP/bdExnH/9Qgyf9S+e+2iHzyB47r6hePyOwaBpgoISHR5+fUuHRFnhpytlaZURkXIB9i+6Cv/9fCl+//BCvPbIcADAz+3y55WRQtRprD4D6u3HRmLSeSmoqjPDanMFbI4lFfE7lSj5fAoMw3nsa04Xi+UbytHHT9GEKePSPC9bW6dIe1Q2e3bV1caAlbsZhvNs99rnu/HZr4fx2a+H8fDrW5AQ2+o0q2mWqK1tQph6Z0bilpl5qKgx4b3v9/u3JTbZsWGX98Szv0CDC0eneNT7C0YlY0jfGFTWmgJOov+1eUFNFidMFieUEb41EFq0h7g2Tqb29sHyGhPilK3rzx2agMljUmGxuvBOc1hUncaC1AT/pdSMZiea9HYvtduXKN1jLis10u/k8c0fR/DKQ8NBiLfE7UuU7nf4YABNbeFqNQ4VNUIs6Frh3vZqd79eyoBOtfxjjdhxwDvInGLZRSedKIvLy/eCQ0Vb4+9l967ArAdW4pPZB7FsfTm27q3FgUItNu2uQXw7p8bmPTUhGYIJcce82eyMhwRvnZWLWKUIW/fWtpMK5NDqbB4pRCziIStFHrDieHG5HpmpctwyKw8Wqws//Vvos02LYVwhF+Cfzy5C/rKrMfudCX5NCPdc0xffvHo+JGIeNu+p9XmAbieLuPnFMPt15PTJifKSSEYMjEevDAW27atFQRt1RC7l+50AaJrCJ8+PwXlD3bVB9QEk25bwm3xVk3eQbjM27KxGQ6MVETIBPvrpEBauKcVHPx1AbpYCx9QGH4+pWEjj7mv64tZZeViyrgzFfmxc6kojJCIeXn94BC6/MBOL15b5lfpWbCrHXdf0wQv3D8MlEzJgdzAwmBy4eFxrIPbWvbWQSXi45pIcFBbrcKBNaMiTdwzGrTPzsHl3DZ77aIdP3KvN7sL6HdV44aOdWLGpHE+/tx1VdWY8eddgr3H30bPnIjFWgg9/OoBfFxz1IvZ6rRWb20ilLQ5BhZ+CslUeiVLcgWnJ6EMGz983DGIRD4vWqLHviMateidJA9gnjc32ycASZ2lzLn+mnxjTf1eUICc9EkP6xiAmSoSSSv+qt93BYHvzuG5nF/TYQd//8YCX1hIKrDaXz3sTGyXGhp3VOFCoxZa9tVi6vgyf/nIIVz60CjPuW9E+zbZYVV5+pLs81xNZ+hwhWMIB97a3SQSyBXrN5jobCkua0Cc7KugD9s6IxKrNFVCV6z2G6OED47D7YIOP+tRiz8xr07JinB/7hsHkAMu6k+xnTsrExz8fxC8LjuL2K/t42ZgiZAIoI4Wo11o9UsDIQfGwBMhYGT8yCW88OgKPvLEVm3bVeMJPPIQi4iFCJkBVnclT2aetDbdPVpTPRHH9pTl4+bPdeOebvfj5nQlutVhIQ1Wmh8PJ+qhaAj6Fr14Zh5ufWgudn6Dz2gYrKmtM+N/NAyGT8vD38mJMuyDdy4s6tF8sDi25ytuA3kF4oiJCiCfuGNzhc8xIkXtsvh2hvVrqD+cOTcC5Q/0XiqZpgufuG4rnMDTgecz7fApWb6vEtr116JMThefuG+bjRU5JkOHfzy/Cm1/vxetf7cHP8wvRJzsKDgeD3Yc1XrG06kqTZwLzIcpm6VgsbH39GvV21Gmtntz28mqzT3mzpDgJHrihP977fj9e+Xw3bDZXwEm/ZTLoyIZZ2lwntsWc5Jk0GQ5f/5GP954e7dF6VGX+tYJdhxqQm6nAEVUjDvl537+bW+CZNLpSA3bbvjqf+gLrdlR5ojk6Faw4LO4JZ1KPRHvTLPM6gGVd/f2mEOyUbqJ0D6Zjar2X6tg2NxgA0pLlXrOrVmeD3cFihp8UtJIKA9KSZLDaXCitNGJgbjSMZid+WeAbt5iaKIPZ6vLEddE08Xoh2qr7gLt4Q0yUyBNX1x5x0WK3etnudzsP1vsN4J8xKRM0TbB5Ty3e/HofVmwqx86D9eiTFYXPfzvs12guEfPw63sT/fY4SogV477r++PBG/vj1pl5uOaSHJ8XXC7ln9GNzwbmKfHorQPxyv+G4+bLc/0SXMuz+vi587Bt7kw8fddQDO0bg3MGxOPNR0filpnuIPmjpXps3VeLUYPjoWmy4d9VJR4pXVWm9wRCfzHnMFZursDOg/V47fM9SI5r1baOluoglfgSy21X5CEnPRKHjzb6DWRvqx0BQGJc4BjSknIDYqJEPtc6f1UJZFI+hvaN9UwQZqvLb0TLhp3VGD8yCb0zFThapveqBVCnseCPJccwrL97Py1poqGgbTGd0EU4LGRo8nZPjI8eqftUVFFRDWBaTlrmpRzhHgMwDiF0eNy8pwZ3XR18NaHemZE+RHn4WCNmTvFO/Wvx9n3/dyH25Guwfkc1hvWP9TuzqcoNyD/WiKl3LkN6kgwZKRGQSfj4eV4Rbp2V51WVJyVBhgOFWqirjF62pRZprqzaBIvV5SElQtxEkxJgdo9qtmPtL9AiI8Udw7dsQxkKS5qw/UAdRg32Lm1GEYJvXzsfcdFiRCvcpas6Kp7cApGQDrr8WRgdQxkpxKTzUgKOzxfuH+bXqdGot+Otx0aiTmNFRa0ZC/4rRWWNCdFRIkTIBLDaXNh9uAHlNSZPppGXnZhH4ZWHzsENj6/pUK1uMXW02MDbo77R3XO8fe1QF8Phy9/zIRLyMPLKeYiPEcPQHH9bWmHwMQds3FXTHFFixuGjjTiiavIQ4/s/HsDNM/OwY38d+DyqSxPthl0hx1qzhGANCHlfVVq6qqeed48WyFOVly4GsDgjIyODZsk4UNxQcEgDEAkCOThOD0KawCEGwAUtv9tzuAE2e/A1DDNSIsDnUThWpoeL4fDD3wXomx2Fmy7zTntLS5R6bFB9sqJQWqHH3yuKMbRfDK68OLvd7KrHbbPy8HgbdVEspPHd3ALMWXTMi8iTmyvEqCsNGN6m89va7e62GPHRIrz3/X589co40DSFHQfqUKe1YsaFvpLsnsMNkEv5uOKiLFTUmrB2ezWGD4jFoNwY5C+7xm9xA4mY12F4RBinJiiK+C1q4m1aIYiQCfD1q+ejssaE/QUaDO7jTWYjB8Vj+oTMDutrFjfbHxMDEGWLkJGW6K12L1hdCkWEAPO/cLeirmmw4Od5Rfjh7wKUVhi9TEdVdWbUay0YmKtEQUkTgGIcPKrFsP6xOFTUiD2HNXj94RFYu62qS/bJkkoDKr2dnA6Am80BUQRQAFAAlB7g9ByIGmD3Ui7+BlWVqrKnn91xqSTaHLOkBvCLv/VZKVm9CM0ebWsQ3pvfENDG5HPSNEFmqhwlFQbUa62YPCbVbyOlpHgZaJpAKuZjxqQMXHheMi67dzle+HgnkuOlXscrrjBg0nmpXr+/dVaeZ5Bc20YdTW6WVFdvq8Tlk7NgsjiwaHWZp2BEUrwMW/bWYeLNS5AQK0ZDoxXfvX6+XzV6WP9YfPv6eJ/lgVS/MM5siIQ0BuVFd7rds/cOQZmfXlQOJ4tt+2o9RCgLQFAtNsfUxNYxyTAsvpyTj6faOLESYyU4d0i8myjbHW/DrmqMGBQHmqbQP8d9zocK3REvb369B0/eMRhCAQ2z1QlxF9TuTb7S5NbisrK7TsokdzIO6s655FRed2BfXUj76JWugN3BwOZwBew2x6MJYpUilDZ77GQSPj57YSxomsIDr272ClspLjMgo10oRVy0GDMuzIRWZ/OEZAAArzmNbc3WKuRd9AcuvHkJ/llZjN7NjZqkYh52/DMTn784Bm88OhKrf57u48QJI4zuIFoh8hTD8JZIgagIEb54aSyevHMIFq8t80pEANyB+lv2uEmorZ3zz2XFIITDpHO9TQqpzSp+aYW3Q2fjzhqcN8Qdz9i3VxREQhoHi7RYsbECAPFUUjKbnZAIQ5/428e2EoJVJ+t+n8za9MsBPNjyZdveWuD2QUH/OKvZU1eo0nVYQispToa9+Q3QGx2IlAvQNycKbzwyEo+/sxV3PLcBcz+ZDLGIRkWt207UHlPHp2HefyXYtKsGX845jEnnpcDFsvjhzfFISZAiKU7q1+Ypk/DRv7cy/EaHcULB51HN1acCj70te2sxfGA8EmKkKChuwqK1ahjNTrz//X7MnJzlkxqaEi8DRREcPtoEjnOTsdPlllyfuGOQRygZ0Dsauw/X461v9uLLl8d6fm+yupAcIQzpOpwuFjsP1qMdw68864nysKrRQ2ZB2Smbc64LSpo6bDuQFCfB3ny3V7vFcD1jUgZqtRZ88MN+XPHgSpw7NAEM4y7icMvMXK9woJGD4nF46dVexRpacmXDCON0xJhhCRgzzNvMZba6MLRfLIrL9KjXWj1ZQYDbtiqT8FHfaEX+sUb0763Etn11kIh5yE5rDVYf2i8Guw7VY/TgePTr1UrUZkvoqveug/WweKX+chpVWdn+s44o7QyzXkjzLGjuEc4wHHYerA/oSfQhymaJsqC4qcPtWtLZ/lhyDITAYxi/55q+GD0kHqoyPeKjJXjijsFQRvrOeoHSv8II40yCVMxDnyxFa4+itu+qg8Hbj4/EUbUei9eVoaTSgDmLjkHAp71IdWjfWEjFPDzaRjO0Oxg4XaxXwY8uqd2gVgJgzzqirKystGanZ2wEMKVl2dZ9tUETZVqzQ2V/gdZvkHULifbvrcS089ORGC/1ilMDgEG50RiUGx1+S8IIoxMSnTwmFZPHtDo7p0/IgKbJhuo6i4cohw2IwbP3DPMKIWpJA24pk9dVouS4k2efPNmqN8BhOUgbotwTfOD5pj01SIx114f84e8CTDovBTnp3jmrfbKjQsr4CSN4GEwO2BwM7HZ3OqHNzsDmYGA0OWF3MF6Bxxab0+tFcbpYnyZlBqMDXLtIKLGQ5zUBCgW0V5sHoYD2klT4AgqS5mwXoZAHsZByt4mV8CAW8iAR8SCX8v32BAojdLRvP6uQC72qwgOA3ujEzMmZUJXr8dvCo7hiSnanYYANjTYUeRfY4FyE/e9kXutJHTG909KyGEJ5FVfc8ueMoCpSB9u8Kgxf2OwM9EY7dAYH9CYH9EYHdEY79AYHdEYH9AY79GYH9M3r7Q4WNrsLRpMTNocrYBWe0wUCPuVJHRWLaIgFPMikfEglfIiFPIjFNBRyIaIiBIiMECJKLoQiQtD8EUIhF56yLRNOZdgdDHg01em9m7+qFE+8u60tSR1QlakHn7US5dHy8pK23RwBYOveOlw+ObPT34ZJ0kstgVZng7bJhoYmGzSNNmiarKjTWtGos6OhyQpNk9VNjEaHVye7sxEOJwuH0xGw7UUwiJAJEBUpgEIudJNnhABREUJEyoWIUYoQrxQjJkqM+Bi31HUmp38GC2GQdkoftZtg5ck+d94pcP+8vN9b99cGRZRnC4xmJ2obzKiut6C2wYpajRnVdRZodDbUa63QNtmg1dv8VvwJ4/iaHgwmB8pg6lxtI81qqkKE+FgJYhQiJMRKEN38NyZKhPgYCWKVooCtMM4WtHT09CJKll11ss/r5BMlIcvAtSHKvXVnzaBwulhU1ZpRWWdGdZ0ZtRqL52+txorqenO7EIlTSIqleOAIDYbig6NocIQGS/PBEh44igZLeQcYs5TAy9DDERps2+FHmrdp+cqxIKyrzWoWFNem5icHUKwj4HeKcYLiXCAcC4pxgGJdIJwLFHvi7yfHue1uDY02r9J47UFRBDFRIqQkyJAUJ0FSnASJsVIkx0uRFC9FUpzEp1r6mYYjqqb2JfsslECw+awnSrvLtUFI86wAxIC74khJpaHTPsynAxiGRa3GispaEyrrzKisMaGi1oTKWjMqa02o19oCFqs9ri8uIWApAVhaCIZu+csHSwnBUAKwtKB5uQAsxW8mQUEzCVJehHY6gmKdIBwDinWBYhxuMuVcoBgnCOsmWMrlAM3aQTEO0IwDNGMHxdpBu+ygWOdxOS+W5VCvtaJea8XefP/byCR8JMZJkdJMnCmJMqQlyZCWJEd6oqxLOdWnEvw0HFyvUqnsZz1RVlZWWnMyMjZzHCa1LNu+v+60IUqGYVFZa0FZtRFlVUaomz9lVUZU1pqCbhvQXcjlcsTFxUGuiMKOYi1shA+GFsHFE4OhhWCa/7aQ31mt3lF8AHwwNICu3AqOA802kydjB804mv/awWMcmDE8A4zNjLq6WmgaNNBqe64ts8nixDG1DsfU/iXTmCgR0pLkSEuSIi1RjvQkOVITpUhLknt5qE9VtO94cLLDgk4d1RsAC6wl8CbK6y7pdUo9wPpGK46p9aiodkuF5TUmVNSYoCrTH1cvMEdouPhiuGgJXAIJXLQEDF+MkYP64u17ZiAuPh4xMTEQCludWy/+shqvzVl7Stw3Hk3h8SvGYuKQbBxW1+HF2athtHZPQLhgUBaeuup82J0uvP77Ouw6WnliL4oQ9+RD+zoUr58wGN89dZW3icXphFajxfPfzMOf/+0Az2UBzdgghRET049CqyPQNNFoaKK73fZV02SDpsmGvfkNPusEfArpyRHISY9AWqIMvdIVyEmPQHZaRJeK6vY0zFYX9h1paDepnXxHzilDlBwha0mbEbJ9X50np/RESoZVdWaUVZt8JMOKmuMjGRICxCoZaF3R0HEKMDwJXDwJXHwJXDwxXHyp35cRAP4rZ/CmPB7Jyck+6x6dOQafLdwKncnW5XMT8nl489bJeOzbZd26xjdumYzhuSl46MvFWPLazciIj8Llr/zW5f1lJyqx9LWbce1bf2HS0Byseus29L7tAzTozV3eJ01RuO2iYRiSk4TtBeX4dc1+T3/2UCeFl27wLfvO5/PB8CX4Y28dLLLW5/X09HV4fHyrTd7hJKhp4KG6gUKNhofKWh5Kq/hYvkkMhu3+y+Bwsn6lUZomSI6XITNFjuy0SGSlyJGVFoGs1IgTKoVu31fX/j0rV6vVhWGibEZ6aeneivQMPYBIwF0Wf9WWClw0JrVHj+N0saisNXuIsEVdLqs2oqrWfNzVZKmYwyM36ZCV4kRyPIOUOBcEfA7rVDQmfnlxiNofh8e+XYb1793ps04hE+HxK8bi+Z+7FqMrFvIx/8UbcNE5vfDMjyvhcHVdYr5+wmC8/88mHFbX4btlu/DazRciJlIKTReJ7Y6Lh6OoUoOF245g97FK3D99FKaP7oMfVuzu8jl+ePdUjMhNxRt/rMNvT12FlNhIvPnH+pD3c9OFQ9Ar2X+m1/OzV8Fib7VtJsjNuO+8fe0kPg7pSU6kJwGAW+p+9uPo4EmS41wgJOR3mmE4lFcbUV5t9KkoHiETNBNoBLLSIpGZIkdOWgTSkyP81krtDlZva68ZcKeENHnKEOV6wJUFbjEBuaFl2XMf7ASPojBhdHLQkqXTxaJOY0FNgxXVdWbUaCyorjWjvMYIdZUJNQ3m4xVGUwdwxwiIu3wcR6lA2GMcIc+Dw8xW1YLA6SIYO9Rb0rsgpxyzBh7Fvwd7h3TQDQdLsXDbEVw2uq/PukdmjsHXS3aiUqMP+WI+ufeSNqQrRr3O1OUbIxbykRzjtjcfVteBEIKshKguE+WkoTnYX+y2Y1VpDKjXmTAiN6XLRCnk83DX1BG446N5WLKjEPO25OP+S0eFTJRSkQCv3jTJ77r9xTX45T9vUnzpos2Q8Dt2CuWrBPh3jTTo4ZBaXnZhdVpamhN0NqG4bMJx2QDJJkAWBy4bILJQ74/B5PDb/4pHE6QnyZGTHomMFDnSEltsoTIkxkpCjhs9UKTFknVl7XifXhQmyvZqKMt7BxRzHZprZOqMdtz94gbEKkUY0jcWibESyCQ8CAQ8GM12GM1OGExOGE3u7JG6BisamqzdtvGESoa0SKQqKiry28uzd1raEwyhLgHgcRN/MzcCV0wyQSH3zu//cMYaLC/IhMUZmnfhqe9XYOrwXPB53sG8EiEfb942GTe9+3fIF3rPJwtwzfiBuOicXlDKu0eUC7bm49bJw7CzqBKThrrzCqyOrofopMREYs2+1mQurcEChUzc5f3FREogErS+BjVaIxKVclCEgA1hMD1+xVjPhOCz7rtlXvvKi9Pi9lEHOxEOgVe+igIbXBkIjhA8vR5woby8BEAJAB91Iic5J4WlHbkUIbkckMdxJJcQ5AJIQ4hZei6GQ3GFwW93TZomSIqTIi1RhpREKZLiZO6sJrkAkXIhIqQCMCyLRp0d9U1WbN9Xh5WbyttrdGUl5SXLw0TZDsUVxYdzMjKe5zi82XZ5Q6MNqzZXnKjTqAXBMcJB1YYMVbRIdCwQGXaEo+XlJTnpGT+07VCpM1L4dE4kXrzHu+pRqsKAxy/YiVdXnRfSMYoqNfhm2U48MH20X7X30wVbsftoVUj7ZDkO9Tq3xBcdIenWDb3/80UoqtRgZF4qTFYHLHYniioaurw/hUzkRTocAJ3J2uX9VWuNKKxowC2Th2Kvqhq9U2LQZLKFRJLJMRF44sqxftct2VHoRewA8N5l68CjOmbABWul2FcYZPYZwT8qtXp7Z5s1t0ioBLCm7fKkpCSJhM/P5QjpzbHIIwR5AHI5oDcBpKHeU4bhUNHs7OwqOHDPAWDCROnvQarVb+ekpxMO5DUcn+rrHMBVAUQFcCqOIyoKpJhQnEpglqryG/JNPX1AF8GrFIeb2g6435fKcdUUM/IyvFPonpq4HbN39UdZU2RIx3jlt7W4ceIQREq9De8UIfjw7mkY99i3IZ93i3MkJkLareu3OVx4d+5GAMDS127GTyv3dMvmabTYoZC1XmdcpBTl9fquDwiOwyUvzMbTV5+PB6aPwqg+qdh4qDSkfbx+82RIRQI/UheLJ79f4WNmmdanuMP9WawU3p+tCPYKXBxFP9+dZ1RdXW0BsK/540XBWVlZqZyLy6UIcjkgj4DNBZAHkJTjxwTkjZIy9ZxTiZtOtehUTlVW9mZmZuYSiuWeATAdzfUqgxWGANRyQAUFUgmOqwCFcg4o5VxUsQMOVWVlpfVEXpBara7NTs98G+Be88y4LPDKlwr8/k69l/1VzHfh7UvX49pfLgvpGBq9GW/+uR7v3D7FZ93Y/hmYNaY//t18OLR9GtxEGaeQ9sh96JUcjfP6peO+zxZ2az+7j1VhQEaCRw2PiZRi3YHi7mkzNY248+P56Jcej7unjcDH87cE/duhOUm4adIQv+u+XbYTBeX1bSYuDu9OX9fpPr/8KwL12iDrNxLyRUlJydHj9T6WlJSUAyhvr8rn5OREsHY2lyJcHkfYXgQkmwWyCZAJIK5L9AgUguBplbp04SnGSzglw/hLS0sPArg2JSVFLKLpwSwheZS761okWAhZQEco6ADowXF6AHqWoqqUSmX1nj17nKfa9RA+/R7ncN0EAk9w6O58EVZukWDKGIvXtlcPLsTXW4ZgQ3FaSMf4dMFW3HnxcOQk+Xpd37ljCpbsKITdGbxtsMnonk8SlPJuX7+AR+P7R2bitg/+RVm9rlv7+mPdAfz8+BUYmZeKK8cNwD5VNbYeKe+R5/TmrZPx6+r92HAweInyg7ungvLjbWwyWfHyr14aLm4afhjDUjouJVhew8NPC4K+51q+0/naSdH+VCoDgF3NHy8MjI+XmgWyTELYTBZcFkUhkeM4JQhRgOOiAKql9qGNALUgXD4hZM2x0tLNOInFeU87omxBs/S3rfkTDMGektehUqns2RkZT4LD/LbL3/5BgfEjrBAJvO1hn8xcg+Ef3gwnE7z1weZw4cEvFmP5G7f4rMtOVOLBy0bj/X82Bb0/i90JF8MiPU7R7et/7Iqx+GT+Vszbkt/tff26Zj9SYxX48bFZUFVpuxWT2RYvXj8BfB6N+z4PXpiZcW5fjB+Y5Xfdcz+t8ortlPCdePXizu//a98o4XAG51chIE8XVlVpT7XxfrCuzgzUHQZwGGcIaIRxQtCk0xUqFYpRADwl5YxmCjwaGDnQO1MlXm6G1cnH5tLQzECqai0GZMajb5qv5jMiNxU/rtztFcsXCGIhH5/fPx0OpwsUIYhTyLCjsOsOtc2H1SjohgOnPTYdVuPLxdvx5/qD0Jtt3d7fbRcNQ5Rcgvs/Wxi01C3g0Zj/0o1+nV27jlbi3k8Xou3099zkbbi0n6rDfS7ZKME3c4NO3d1bXKa+D0C4bNSJ0ArDt+DEoVd6eh8W5ADaZBiLhRyWf12D5DjvF9Tq5GHQe7dBpQmtQntKTCQKvn8EMrGvc2H2f3txy/v/nNozd3MrYIZlT+nzfP66C/Dazb5xkyzH4dyHv/aaWHJimnDwiR8h4gcmYb2JwsX3JKKhKSjZhWNZcn5pRemm8Ft1YhCuJnoCcaysrIAD+cyLEO0EL3/p21pUzHfh26uXh5zGWanR49U5a/yuu3nSUEwckn1K3yMeTZ3yNRlzkqLx7DXj/a77avEOH+n74xmrOyRJAHjvJ0WwJAkQ/BomyTBRntHgiwQvA/AqkbJ+lwgrtvgGTY/PrsANQ0O36300bwsOlNT4f5EfnOEVYH1KEiV9aluEvnzwMoiFvokBdU0mvDDbO877ikFFmNq3pMP97ToswtyVQSfNGHkM80z4TQoT5RmNoqIiIwiebb/81a+UMJh9H8eHM9YgVmoJ6RguhsUDXyz2W9ihV3I0nr76/JM3UfDoTomS10n6W2f7OJ64YeJgT4ZRezzx3XI0tQl+l/CdeK+TcCCni+DFL6JCyCgjrxZVVFSH36QwUZ7xKFarZwPESz9uaKLx4c8Kn22jpdagYu/aY/NhNX5cucfvuqevPh+5KTEn5dpZlkOEJHDGCU0RCPiBiVAs5IM+SV0UlXIxPrhrqt916w6U4Le1+72WvXzxZqRHdRwM/9XcCKjKg05bPaiIUX4SfoPCRHm2gOMYci8Ar+D3P1bIsOeIL4ncdM5hTMkLPfTp0W+WoqLB90UV8nn49uHLQciJJxyGZREhEXUoLXYkUSrlYtgcJ6c9xju3T0GcwldFNtscuPOjeV4SfL8EDf43tuNCHUfVglC83CwhuPtUjBMOE2UYxw0llSXHAO4Nb2kLePZj3zg6QoDvrl6OKHFooTAGix33fLrA77pxAzJxc4CMku6gxWvdEfx55Nv+XtCBau0vVbAr5xAqxvbPwO1TzvEvof+wEsU1ja0vFeHw1RUrwacDe+4ZBnj646igYyY54JNg8rnDCBPlGYfUsrJ3OMBLXyup4uPbf3yljORIIz6ZuTrkYyzbWYTZ/+31u+69Oy5GfJSsR6+JEHfloo7QEdm5vd5dJ0qRgNfjqrlIwMPX/5vhVwLfeKgUXy725q8Hx+7BmKyOq65//kckDh0LuuVyudgifTH8xoSJ8qzEesDFUeRutKuS8tVfEShU+xLCDcPyccWgopCP87+vlvitSxkTKcXsx6/sURXcxbCdlj2raNCjdwAbKY+mwAsgESrlYtg7UbuVckm3im74w9u3TfEbxG+xO3H7h/O8Kg1lKnV4rZMMnHyVAF8Hr3KDcOSB41GwJYwwUZ42KC0t3QlwX7Vd5nASPPmBEk6XL4F9OWsl4uWhFb3Vm20Bi1FcdE4v3DNtREj768gZA7jznAPVZgSAep3Jb056C1EGcuYM65WMokpNwP3GKWQw2xzdOvf2uHBIDh6aMdrvumd/WglVtdZLmv7mqhWQCQOfg8NJ8ORHSriYoCenP1XlpYvDb0qYKM968ESiZ8HBK0q5oESAL//0JZsYmRVfX7ki5GMs3l6I39bs97vu/bumhuQFn3Fu3w63t9qdSIiSd0n95lGBw4PkYmGHGTvJMREdpjQmRUfgynEDgr5OhUyEHx6d6Vfi3lZQjs8Xeqvc9523Fxf2Lutwnx/MVuCoOrh2vwRoZCnycPgNCRNlGHDHVnJgb0W7vN2v5kbg4FFfCeiy/ircOCz0QPSHvlzs1wsuEfLx61NXBR2fuHZ/CRa/ejNiIwOXYCsor8fQnKSA68UCnt+qO3QHAecd2Sf7pMWhrK4p4Hq5WIilr92M7QXB56x//dAMpPkpCmKyOnDTu397kXaGUo+3pm3ocH+7Dovw88LgqzFxBPeXlpbWhd+QMFGG0YyS8vI1HIiXCs4wbhXc5vAllC+uWIXecY0hHaPJZMX1b//lVyob3jsFL1x3QVD7qdToUa8zYenrNwd03FjsTsRESgNKh8eqtBicneiznB/AmZMUHQGdOXAp0dTYSDQa/a+nKQpznr4aFEWQXxYc79wwcTCuPn+g33UPfrnIR+X++sqOVW6DmcKTHyoRQgr7/GK1+s/wmxEmyjDawea0PwHAqwhrcSUfH/3iK9XIhA78ev0SCOjQHBebDqvxzl8b/a577roLMG5AZlD7+XvTIQzvnYI/n702YDjOxkOlmDzMf3/2vapqjOmf4at6B8j1njA4CzuL/HuSJw7Jxu4Oent/et8luHRUHv5cfzCoa0uJicSn913qd92/mw/j51XeUQT3jN6HybnqDvf54mdKVNYFnTpaDx59T/iNCBNlGH5QXV1tIeBuQTsv+M8L5dh52DdIe3hqDV6ftjHk47z82xq/ZdMoQvDjY7N8Wkr4JcqNh8FyHC4dlYd375jin/gdLoj4PL9xk3any6/qTlP+Ve+sBCXqmnwdv3wejTiFLKA0+cw143HfpaPAcRzmbuicKGmKwm9PXYUoP5778nod7vhonrfKH6/Fe5d1nDn1+3IZlm4KpVA/d09xcXF9+I0IE2UYAaAqK9tGCN5vu4xlgcfeU0Jn8H1cj52/E5f0Da0VgtPF4Pq3/4LRavdZl52oxE+Pzeo0ZKhaa8Dmw24p6tFZY/w2NwPczbUCqbB8HgUhnxeURBnIPnnVuAFYttN/yNS1FwzCG7e4S6HtOlrlFRQeCK/dfCHOH+grVTMsixvemQudqdVZJOQx+O36xR22nT1Wxsfb3wVfKo8D+aG4rGx++E0IE2UYnYHHewmAl/hTq+HhyQ9jfIonEAJ8f80yJEaEFmZXXNOIBz733zb58vP6Bewq6KVyfrrQUwTik/suwYxzffuLO1wM7E4XUmN9G6YdKq3DyLxUH6LktZMoeyVHo7rRty2qQiaCVCTw6+ke2z/DQ/hGqx13f9I591wyMi9gwZA3/1iPTYe91es3p23AkJTANk+7g+DRd6NhtQcdCqSm+PSj4RcgTJRhBCNVqlR2iuBmAF4i37pdIsxZ6ptJEyez4OfrloIioRW7/mX1Pvy+7oDfdW/cMjlgm4MWFJTXY+Yrc2BvroT+21NX4ZzeyT7b/bXhEG66cKjP8u0F5biwXX1MHu2bwjhhcLZfU8EdU4bj93X7fZbnpcZiwcs3QsjnweliMOvVOdhfXNPhtWQnKvHrk1cFDAV6dc5ar2WTc9V4eNyuDvf5xrdRfhMHAoAlBLc296IJI0yUYQSDY2r1fo7DU+2Xv/V9FApKfF++Sb3VeGHylpCPc/cn83Gk3NccxqMp/PnsNR0GjgPA+oMluPm9f8BxHKQiAZa9fotPMLnTxaBSo8eQduFCxTWN6JcR70ei9B6WY/plYJ/Km+hSYiJhdThhsnp7mmMipVj86k1QysXgOA53f7IA/+3tuAWDSMDD3Oev82qD24JGoztSwMW0uqtjZFb8dO3SDosqL1ovwR/LQ0kPJW+p1Or14ZEfJsowQkRJufpTcPBKqXE4CR56Kxpmq++je2Hy1k6LxLaHyerA5a/8BoPF114ZHyXDP89f32GRCrfEeBDPNxesjY2UYtErN/o4Q35bsx93XjzcdwAS4pUt095GSQiBQiby6WXz+BVjfXLYxUI+Fr1yo4eoX52zFj+t2tPpPfjywcv8xnyyHIfr3v4TpbVN3qaOqzo2dRSpBXj+0+jgKZLDTkWM8pXwiA8TZRhdA+d0B6J79WNVV/PxxrdRfkiHwy/XLUGmUhfSQY5WanBnO29uC0b1ScX7AWowtsWbf6zHt8t2AnAHf897yZtgGZbF1iNlPuFCe45VYWybMCF39aBWB8+AjHiUtHPCDOuVjNK6Ri9pkiIEvz99NUb3cbf5/XnVXrzy29pOz/veS0bi1snD/K57YfZ/WLn7mNeyh8buxvT+gSVUg5nC/W+EZJfUuShcHS6fFibKMLqB8vLyJpYlN6BdyNDfq6T45z/f8BqlxIp5t83v0BPrD3M3HsLH8/2r7g9eNhp3B5EPft9ni7Bw2xEAwPiBWZj9hHfBjT/WHcTtU87xirvcUViBCYNb7ZTt61FOHJKN7e3skw9ffh6+XeZtH/zw7mkeZ9L6gyW4+5P5fiu8t8XY/hn4+N5L/K5bvL0Qb/3pnWkzOr0K71waWDvmOOCZj6JRVs0P/sYT3KtWq9XhkR4myjC6idKK0k2E4PX2y1/+Uol8la+9clBSPb6+amXIx3niu+XYeMh/geDP7rsUFwzq2LnDsCyue+svj+PlmvED8epNF3qtX7D1iFcdzJ1FlV77ba96TxySg+0FrQL19NF9sKOwAtY2bXcfvvw8/O/ycwEA+WV1uPyV3zqtIJSZEIV5L/o3K6iqtbjpvbleRBsvN2PuLQs7DPD/4s9IrNomDkFfwNfh7JswUYbRg1Cp1a9xHLyiy+0OgofejoHe5PsYbxiWj7tGHwjpGC6GxVVv/IFqra/jlc+j8c8L1wes+tMCi92Jy1/5DWX1bvX/+esuwL2XjPSs/2v9QVw5boAnLlJvtkHApz11MXltAs55NIXclBiPjZCmKDwwfTR+WNlaOfySkXl4/66LAbhjO6c+P9sr1tEf5GIhFr96E2L8BLxb7U5c9cYfXvvg0yz+umkhkiONAfe5aa8In/0eGYpV5bCddYVDgcJEGUYPg2EpXA3Aq7FUeQ0PT7wf4zeH+LOZq3BBTnlIB6lrMuHat/6C049EppSLseDlGzotVVbTaMTU535ujbG89xKPbZLlOHy/fDcenTXGS6psCUWiaeLJ9R7eOwWFFQ2e7e68eDjmbc73t4JPRAAAFv9JREFUSJMj81Lx13PuFEqDxY6pz89GeTNBBwJNUZj7/LXolx7vd/2dH8/HPpV37653Ll2HcdmBi2mUVPHx8NsxIeRxcybCcVdXVlZaw8M6TJRh9DDUanUtAXcFAK+YmHW7RPjyL19phk+zmHvzAmRHN4V0nI2HSnFfgGD0funx+P2Zazptt3CkOcbS4WLA59H4+/nrMDAzAQAwb0s+Jg/N8ZRi215Q4ek37k5hdO97wuBsT7UfuViIWyYPxY/N0mRWohKLXrkREiEfTheDK1//PWCL3rb44K6pmHJOb7/r3vpzPea0axB29eBCPDwucO8bvYnCPa/E+O2gGYglCUfdqiovPxIe0WGiDON4qeDuFMenfaTH3yOxaa9vHGC01IpFd/yLSJE9pON8v3wXPvx3s99100bk4ssHp3e6D3eM5d/gOHfnxeVv3ILU2EhwHIcP/t2Ml2+cCMDbocOnW505bkeOWyJ+6upx+G75LjhcDJRyMZa9foun0ddDXy7Bqj3HOj2fey8Z6bFltse8Lfl4/mfvnty5sVp8c1Xg2p8MAzz0VixKq4J33hAO76jKS/8Jj+QwUYZxvMlSrf4I4H5tu4xlgUfeifH70vaJ1+KX65eEnLnzxHfLPV7s9rhr6gg8c834Tvfx5/qDeGG2u9dPUnQElr1+CyKlIizYegQDsxLQPyMeh9V1iFfIkBEf5emZIxLwMCI3BbuKKpEcE4Hpo/rgl9X7IGiWTlsKB7/y2xp8vXRHp+cxfXQffHa//4pA+1TVuOndv71aOijENiy4Yz4iOphgXvtGia37Q6qYvjalXP1CeASffqDDt+D0RKpItMrJ418GwNPMxe4g2LJXhMsmWCAUeJNiblwjRHwXVh/NCPoYHNxFLaaNyPVbsXzC4Cyo63SdqrybDqsRp5BieG4K4hQyDMlOwp8bDqJaa8Az14zHnLX7MXlYDowWO8RCPqLkYjicDEbmpeLj+Vvw2X2XYs7a/dhfXIOfH78ClzWHAf2x7gAe+mpJp9cxtn8GFr1yk18Pd02jEROe/AFag8WzjEexmH/7PIxIC3xdc5bJ8NmcEJw3HCqIgDd5b2NjuPdNmCjDOFGoM5udCmXUGsLhJgAesabJSOOISoBLzzejvRnxvMwqaMwS7CpPDPo4DheDRdsLcc35A32cOIQQTBuRix1FlZ1W5lm5+xgGZyciNzUWOUnRSI6OwIfztuDB6aNRVqeDkE9jcHYS6nUmRMnESImJgM5kQ1m9Do/MHIN7P1uIN2+djPsuHeVR6698/Q+v1EJ/6JsWh1Vv3Qa5HweU1e7ElOd+QkEbhxEAfDrzP1wzpDDgPjfsFuGJD6LBcUEHldtZmlxcUlJyLDxyw0QZxgmGTqfTRkcp9gG4tq0ZpbyWB6OZwrhzfMNkLsorxcHqeBTVK4M+jtFqx5YjZbh+wmCf6uM0ReGy0X2xYvdR1DYFFpY4jsOSHYWYck5vJCrlGJqTBIeLwe/rDuDt26fgz3UH8eBlo7GzqBJKuQTn9k3Hkh1FePjy8/DJ/C0YmZeGt2931708VFqLi579qdNGYskxEVj37h1IUPpKwyzH4Zo3/8Safd4l6h45fxeen7Qt4D4PqwS48+VYOBzBW60IyL0l6nCDsNMZYRvlaQ6VWr0SID7OndmL5PjdT1EGmnCYc+MijMqoCuk4OworcNUb/iW4CIkQq966DX38tHRtC5PVgUtemO2JsXz95kmIV8hgstqRkxyN+CgZBmUlQikXY1ivZETJxJ6GYV884HYeVWsNuOTFXzpsIga4i2Oseus2vz1vAOCxb5Zh/hbvvkMX9ynBu9MDF+GtrOPhrpdjYbGG8NoQvKsqK/0+PFLDEmUYJxlNet1WpSIyGSBeScub94gwtI8dqQneMZF8msX0/iosONQbjZbgM0mOVmlQrTXg0lF5PuXIpCIBpo/ug3mb8zskMZPVgf/2qnDdBYMhFvIxdUQufluzH3dPGwmHi0F2ohJZCUrQFIWMeAUWbj2Cd++8GGIBHwaLHRc+/SOOdtCyFgAipSL899ZtGJTl38Twxh/r8Oaf672W9UvQYOldf0PM9983XGegcNOzcais54XyaJYXl6nvQLumcWGEiTKMk4SsnJwVNot1LICMVvWSYM12CcaPsCFG4U2WUoETk3LV+GNvH1idwYe37FNVw8mwmDg42y9BTRuZh783HoapA7W4QW/GzqIKXHvBIAj5PAzMTATAIV4hg0QkgEQk8OR8989IQHSEBE4Xg8tf+Q1bj3TcDlYi5GPZ67dgVHNxjPb4fvkuPPrNMq9liREmrLv/D8TJLH5/Y3cQ3PlyLPKLQ/JwH+FoampTU1M4qDxMlGGcKqipqWHjZdIlLEXPAuAxQDqcBKt3iDF1rBVyibfaHCO1YlxWJf7c1wdOJvihsOmwGgqZyC8ZRUdIcNGwXvhrw0FYHa6A+1DXNUFVrcWsMf0gEfIhE/uSkFjAh7x5+QOfL8ZfnfS8EfBo/Pvi9bhwSI7f9Yu3F+Km9/4Gy7YKeBEiO1be/Tfy4rR+f8OwwKPvxmLjHnEoj0NLWGZicVlZTXhkhokyjFMMGqPRGiVXriMUdz3aeMLNVgqb94lw6XjfsKEUhRGj0qvw1/6+YNjgbW//7VEhLzUW/TN8UwHjo2SYMDgbf286BFsHZHlYXRdQOm2LV+esxfv/bOqUJP967lpcOqqP3/UbD5Vixiu/weFslawFNIN5t83DmCz/HRw5Dnj+02gsWh9KYzDYOY6aWlxRdiA8IsNEGcYpiiZDU310lGI73J5wj0GtUU/jQKEAl5xvQfsmh5nRevRPaMC/B3PBBhnywgFYtK0AI/NSke2nUEZydAQmDumcLDcdViM5JgLDeiX7Xf/L6n14+OulQZGkv549ALC/uAZTnvvJq34lTTjMuWERpvcP3Jjt7R+i/Lbe6Oi2EI7cWlxeuiQ8EsNEGcYpjkadTh0VpSgmwEwAHuarquehup6HSaOtPm0M8uIbka40YOHh3kEfh2E5/Ls5H+f2TUdmQpRfspw8rBf+2XSoQzV82c6jnhjLtlh/sARXv/Fnh7GSfB6NuR2QZFGlBhc+7R1QTgjw1ZUrceM5+QH3+9nvkfh6bkRI952Ae1xVrv4mPALDRBnG6SJZ6nSHlYpIF0AmtF1eWCpwx1gO8/VMD0qqh0zoxH9FmUEfx8Ww+HfzYZw/INNvKE6iUo4LBmXj742HfNo5tKq4HJbuKMI14wd5WkhUaQwY99i3HcZKutMZOybJ8Y9/59MP/PWpGzssdDF7kRzv/aQIkSTxlaqs7PnwyAsTZRinG1nq9ZuUisgYgHiVJ99f5DZfjhzom8d8bkZVyGTpcDH4Z9NhTByS47cZWXJMBC4ckoN5W/K9Cu6238fKPcewcGsBfl29D18t2YGKBn3AY4oEPPzzwvWYHsAmWVzTiAue/A41jd41JO8fsxdvTdsQcL9/r5Li5S+Vod1ogkXFZepbEA4DChNlGKcnBun1/+mjFEMIkNt2+c5DIsgkLIb0cfglSwDYUJwW9HHsTgZ/bzyEC4fkICnalyyToiNw6ag8zN96BEar/0ITGoMFJbWNKKltRIPeHPBYUpEAC1++ERcP928mqGjQY8KT36O83ptobx95EF9esTJg98S//5Pi+c+iwYVEd9xmhpDpOp0u3PMmTJRhnK5QA6xUJlvAo6gxaBNjCQBb9omREOtCv2zfd3x8TgUYlsLGktQQyNKF+VuP4KJhvfwW0YiNlGL6qD5YuK2g08yaQFDIRFj55q04f2BmQJK84InvUFLrXYPz5uGH8d3Vy0EFIMl/V0vx3KfRIRTfBUBwyMlxF5WVlYULXYSJMozTHQaDwRUdGzMPLDcZgFdf1vW7xOiV7kROqq/98IJe5bA6+dhSmhL0sSx2J+ZuPISJg/1LltEREswc0w9Ldxai0RhaLHacQob/3roNw3P9n09JTSMueOJ7r/ayAHD9sCP48dqloAOUmVuwVopnPg6RJMGpGEImlJWVacIjLEyUYZwhaGxstMdK4+ZxNHMpAI97meMIVm2VIC/TiawUX7K8sLcaHEhIarjV4cLcjYcwbkAmUmN9S5EppCJcP2EIth4p77R1QwuyEpVY887tfuM2AbfjZsKT36O8wXt/Vwwqwq/XLwGP8k+Sf6+S4tlPQiVJVDGEXKBWqyvDIytMlGGcYdAatZZYuWwBR1EzAShalrPNZNkny4lMP2Q5PqccIr4La0KoZWl3uvDXhoMYmZeKrERf54hYyMd1FwzCsSoN8svqO9zXiNwUrHnn9oAFLgrK6zHxqR9Q1a4p2swBR/H7jYvAp/2z4J/LZXjxi5AlSQ0FTCgpK1OFR1SYKMM4U8nSYDBGRSuXE467EoAnmpplCVZukaBvjgOZyb5kOSazChJBaIV/nc3e8OG9U/wGpfNoCjPH9IPGYMGuo/6Fs8tG98XiV2+CQuY/hXCvqhoTnvwe9TpvM+GsgUfxx00LA5LknKUyvPylMkTHDfTguMmq8vKD4ZEUJsowznA0NTVpFcqoJYTDFe3J8r+tEgzKdSAt0Zcsz8usQrTUipWFWeAQXAaPk2Exd8Mh9E6J8as2U83Ff5VyMVbtOeYVX3PHxcPxyxNXQsj3X7Fnw8FSXNym22MLbhyWj19uWBKQJL+aG4G3vo8K9bYZKIKLVGVlu8IjKEyUYZwl0Ol02sgoxVIK8JIsXQzBsk0S5GX4t1mOSKtB/6QGLMrvBVeQueEtGTwREhFGB6jqMzIvFf0z4rFoewEYlsPLN07EB3dNBRXATb1w2xFc/uocr7REALj73P349uoVoP3YJDkOePdHBb74MzKke8UBZpoilxxTq7eGR06YKMM4+8hSo1BGrSIcrgIgaSU2gpVbJcgJ4A3vE6/9f3vnHhxVdcfx77nJZpNNYF/ZJIDkRYIGcHgFCsgwIuVRQKJgFVORoYMjUGbqDIMKI2UKToeWsTg+WkqlWLUtEuVNSoCU0IImURAIhDz2cRdIDCHZ3bsku9nN7p7+EUuzuxfcXaMo/D7//uaec/d3znz397vnd87BpJwm7K0ZCo8v8vMZy766KfHhkbmy9mGZaXhoeBZmFQ7FynkTb9nOttJqLN78Ebwhd4+/+EgVthSVy5YAdfsYVr+Wip2HU6J1k0tgmGsUxRM0Y0goiXtXLK/pNeqjAHsSQFLvNLzsVDIGD/DhgZzwOsscnYQ5w0zYfzEfNzwJEfd34rwFrY4OzBo3FIJM5XdOhvaWK9sAsPFv/8KqbaXgIR8XX3qkCpvmVsgWk7vcAla8asDRyqiOSgMHOgWGOSSSBAklAZsktaRqNWUcWAAguXeqWl6pwqB0Hwpyw8UyvZ8LRQ8aUVqbC7s7chH6vKEJVfVX8OiEAiQmRBaRen1+LN2yG1t2nwqewIzjjfnHsObH8vfctDnisPiVNHx+MapDd8GBTgY+z2S1VtAMIUgoiR6xdDha1FrNAaHnxKF+vcXyWKUKnMvvDdepuvDU6DocN2biS2fkaa2p2YaDVXWYPf7+W65o/492pwvzfvU+9n4SfMe4Mt6P9585gCXja2Sfu3otHovWpKHRmhCtOyQBfKbJav0PzQyChJIITcPbtHrdQcYDjwMsaFtNdU0inB0CJo/pCktvU5TdKB5zCV80ZcDYFvlqcqujEx+Un8WEgsHISpd/rrGpHdNe3o7TjcGXoWmTunDwuY8we5hZ9rkLxgQsWpOG5uvx0brBHhDYTLMoVtGMIEgoCXmVsNvbDWr1Ps5YEXoVpQPAuXolrrQoMHW8G3EhC94J8X78dFQdmqUUfNGUHnF/bk83/nH8PDLTNGGXgR053YiZa/+CprbgQvLBGieOrdiJcZktsm2WVyZh2QYDpI6op3drQGDTLBbLGZoJBAklcftUV5Ls/TXqXQxsGgMyetvqRQXOXErE9IluJCiCF1TiBI55I4wY0L8Dh+tyIz4t3R8IYO8ntXB0ujFjbD4YY9hWWo1nflcCV1fwt9HR911D2fO7kG+wy7b11/398PLreni7WbQ/W/xKJGtpBhChMHIBcSuys7M1QgD7GMOUUNuD+R78+ddt0Kv9ss8eqc/GwveK4HAnRtXngskjYFAnY+uh8Mz3qVF12P50KVSK8IUlj5dh3Vs67ClPjuGX8gvMp/iJsclIe7cJEkoievLy8pTc53sPPbWWwSlwhg87Nl5H1kD5oxgbr+tQtH0+6lr132ySMmDdjFNYP+OkbPlPa3scVryainMNyliar+BxwmNms1mi0SYo9SZiwmaz+e0Oxx69RmMAMK63zdkh4J8nVSgc7kVGanhkqU92o3hsLc5cHQBzuyam/lOUXuxctA/LJp2VFclz9Uo8uzYN5quKWJrf42eYb7FYOmmkCRJK4pvCbZLjkFat6WIM03pnIq4uAfuOJ2NQunxhepLCh6fH1MLlVaDSOiiqTofo7Ti2/ENMGSKfEe8qS8EvN6XC2SFE/4PA3jZbxSV0MjlBQkn0KXbJcUqn1VgBPhdgN9XJ7+85pu1Gp4DJo8PLhwTGMeN+ESMHtqKsPgddEWx7nJp3GWXLdiFL5wyzebwM69/W4c2/q+H3R/31iDOGDSar+CLojhuChJL4VsTS4Tir12rPA5gHICjfPVuvRE2jElN/5IZSEa5BD6Tb8MSoBpyyDLptcfqqh6vxbvEhpCjDgz1zkwJLXjHg36eTYnh77uOMPWcSxddpJAkSSuJbxeZw1KdqNaUcmA0g6Cgea3M8Kj5LxJTCLvRPCT/mTKfqwrOFF9HmUuH0lQzZ9o8u/xDK+PBvnvsrVHh+gwEtbVEXkYMBNs55kdlq3U0jSESLQC4gYqFRFM/6wCcAqAy11YsJWPBCOirPy69CJyp8+OMTZTi4tAQD+n/9vVw3XAJWv6bHqs2pcLljmrINfoFNMl++XE4jR1BESXynSJLUoTekfgB/4D4wjOptc3sE7D+eggAHxo3wyK5Y5xvsWFR4EY3X9ahv/f91EWunf3rz0N3TtUr8fF0aqmsSY33NwzxOmGmxWJpoxAgSSuLOpOE2m98uOfZp1RoHY5jeO0vhvGeP+AWjElPGuJGoDP9umZzQjYWjLyFHL6G8IRtefxzWTv8Ufj/Hb7drse4tHaSOGBMfhjdMVnGx3W5300gRJJTEHccuOap0Wk01gEcBBIV/YnM8DpxQYXSBFwNS5XfyjBzYip+NrYXFpsVgQcTKjXoc/ywp1tfxgGGpSRQ3gVa2iT6AduYQfUp+VlZBAKwEwPBQmyKe44VFEpbOd0K4TZA4/LHBsezVvqnLPCA8ab5iprttiD6DFnOIPqXRar3k8fvGAfydUFu3j2HzDg0Wrk6HtVnR530z8IMev28siSRBqTfxvcfpdPrsknRAp9ZawDATIfWWLW3x+PhYMjT9AhiR7w17/g871fAHookouY8xttFotS53Op0uGgGCUm/iB0VeZuYwzoQSAMPk7DMmurF+hQ1pOn+sqXcT58JC82XzSfI2QREl8YPEJknXk5JV7yri4/oBGB/652y6qkBJWQqSEjlG5HshsMgjSgb2cVx3wlzjVWMdeZqgiJK4KxiSnT0LHNsBDJSzF+R6sXGlHcUvpX1dROkEZ6tNly3byKsECSVx96XieXkG3u37E4DHZVMcAQjwnhrMW0zZcsQLS0wm0xXyJkFCSdzV5GZlFTOw3wOI9IIdB2dYaxbFraDaSOI7hr5REncEuyTVqLWadwQGFYBC3K5UjaEkILA5FlGsIM8RFFES9yRDMjPHgrGtACsMtnAjE4RfGC2WI+QlgiJK4l6PLr8cKUk7JLXGxhgeAhBgDL9hCkWx0WxuIA8RBEH0IicnJ2toZmYueYL4PvFfCVGD5bjCh/0AAAAldEVYdGRhdGU6Y3JlYXRlADIwMjYtMDgtMTdUMjM6NTI6NTIrMDA6MDD76tmQAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDI2LTA4LTE3VDIzOjUyOjUyKzAwOjAwirdhLAAAACh0RVh0ZGF0ZTp0aW1lc3RhbXAAMjAyNi0wOC0xN1QyMzo1Mjo1MyswMDowMHvVS0cAAABVdEVYdENvbW1lbnQAcHJvdmVuYW5jZTogRkNELVBBQyBncmFwaGljcyBvZmZpY2U7IG1hcmsgaWQgY3Rme21ldGFkYXRhX291dGxpdmVzX3RoZV9pbWFnZX2bSlFZAAAAAElFTkSuQmCC" alt="Naval Postgraduate School"></div>');
    h.push('<h1>'+LAB+' - Lab Report</h1>');
    if(_em) h.push('<p><strong>Student:</strong> '+esc(_em)+'</p>');
    function tableToHtml(tbl){
      // serialize a data-entry table, replacing inputs with their typed values
      var clone=tbl.cloneNode(true);
      clone.querySelectorAll('input,textarea').forEach(function(inp){
        var span=document.createElement('span'); span.textContent=inp.value||'';
        inp.parentNode.replaceChild(span,inp);
      });
      return clone.outerHTML;
    }
    // a student may have a box open in the focus (Expand) overlay -- return it home so its card owns it again
    try{ if(window.DonWritebox&&window.DonWritebox.collapseZen) window.DonWritebox.collapseZen(); }catch(e){}
    // Per-card try/catch: this is the critical content (the student's own work). One malformed card must
    // NEVER abort the loop and drop every other answer -- each card is isolated, and a failing table/image
    // inside a card still leaves that card's text in.
    document.querySelectorAll('.qcard, .inq, .frms-buy[data-frms-buy-lab]').forEach(function(c){
      try{
        if(c.classList&&c.classList.contains('frms-buy')){
          // the procurement box, in flow: the Lab Report shows the buy + justification AT the procurement
          // step (not only in the bottom FRMS record). Rendered fresh from the refreshed FRMS_REC.
          var _bh=(typeof frmsBuyHtml==='function')?frmsBuyHtml(c.getAttribute('data-frms-buy-lab')):'';
          if(_bh) h.push('<div class="q">'+_bh+'</div>');
          return;
        }
        var i=c.getAttribute('data-q');var q=(c.querySelector('p')||{}).innerText||'';
        // find the card's textarea; if it was moved (focus overlay) fall back to the global data-ans match, so
        // a student's answer is NEVER dropped from the export.
        var ta=c.querySelector('textarea')||(i?document.querySelector('textarea[data-ans="'+(window.CSS&&CSS.escape?CSS.escape(i):i)+'"]'):null);var a=ta?ta.value:'';
        h.push('<div class="q"><div class="p">'+esc(q)+'</div>');
        if(ta||a){ var _ar; try{ _ar=(window.DonWritebox&&window.DonWritebox.md)?window.DonWritebox.md(a):esc(a); }catch(_e){ _ar=esc(a); } h.push('<div class="a">'+_ar+'</div>'); }
        var _rev=i?revGet(i):null;   // commit: lock in the pre-feedback answer; mark anything appended after check/reveal
        if(_rev){
          var _m=_rev.revealed?'You viewed the correct answer after writing the above.'
               :_rev.checked?'You checked your answer after writing the above.'
               :_rev.gated?'This answer was locked when you continued past a checkpoint.'
               :'Your answer was locked after feedback.';
          h.push('<div style="font-size:.85em;color:var(--accent2);margin:.1em 0 .2em">&#10003; '+_m+'</div>');
          var _ap=(_rev.append||'').trim();
          if(_ap){ var _am; try{ _am=(window.DonWritebox&&window.DonWritebox.md)?window.DonWritebox.md(_rev.append):esc(_rev.append); }catch(_e){ _am=esc(_rev.append); }
            h.push('<div class="a" style="border-left:3px solid #e0a458"><em>Added afterward:</em><br>'+_am+'</div>'); }
        }
        c.querySelectorAll('table').forEach(function(t){ try{ h.push(tableToHtml(t)); }catch(_e){} });
        c.querySelectorAll('.shots img').forEach(function(im){ try{ h.push('<img src="'+im.src+'">'); }catch(_e){} });
        h.push('</div>');
      }catch(_e){ try{ h.push('</div>'); }catch(_e2){} }   // close any opened card div; keep going
    });
    try{ var _dl=deliverablesSection(); if(_dl) h.push(_dl); }catch(_e){}   // prose deliverable diffs -- optional, never block the report
    try{ var _fr=frmsSection(); if(_fr) h.push('<div class="frms">'+_fr+'</div>'); }catch(_e){}   // FRMS is optional -- never block the report
    // Standing & CTF (the narrative layer): the rank the student reached + their flags/side quests, at the
    // foot of the report with FRMS and Check Work. Read from the SAME game state the on-screen dashboard
    // uses (window.__donGame / DonNarrative). Guarded: a lab with no narrative pack just omits the section.
    try{
      var _G=window.__donGame, _narr=window.DonNarrative, _pack=window.NARR_PACK||{};
      if(_G&&_narr&&_G.model){
        var _gm=_G.model();
        if(_gm&&_gm.rank){
          h.push('<h2 style="border-bottom:1px solid var(--rule);color:var(--accent2);font-size:1.15em;margin-top:1.8em">Standing &amp; CTF</h2>');
          var _nr='';
          if(_gm.next_rank){ _nr = (_gm.next_rank.requires==='complete')
            ? ' &mdash; '+esc(_gm.next_rank.title)+' requires full course completion ('+esc(String(_gm.next_rank.remaining))+' item(s) left)'
            : ' &mdash; '+esc(String(_gm.next_rank.rep_to_go))+' pts to '+esc(_gm.next_rank.title); }
          var _rh='<div class="rptprog"><strong>Rank:</strong> '+esc(_gm.rank.title)+_nr
            +'<br><strong>Points:</strong> '+esc(String(_gm.points||0));
          if(_gm.completion) _rh+='<br><strong>Course completion:</strong> '+esc(String((_gm.completion.total||0)-(_gm.completion.remaining||0)))+' / '+esc(String(_gm.completion.total||0))+' items';
          if(_gm.quals&&_gm.quals.length) _rh+='<br><strong>Quals:</strong> '+_gm.quals.map(esc).join(', ');
          _rh+='</div>'; h.push(_rh);
          var _board=[]; try{_board=_narr.ctfBoard(_G.state,_pack)||[];}catch(_e){}
          if(_board.length){
            var _ff=_board.filter(function(c){return c.found;}),
                _pg=_ff.reduce(function(a,c){return a+(c.points||0);},0),
                _pt2=_board.reduce(function(a,c){return a+(c.points||0);},0);
            h.push('<p style="margin:.6em 0 .2em"><strong>CTF flags:</strong> '+_ff.length+' / '+_board.length+' found ('+_pg+' / '+_pt2+' pts)</p>');
            h.push('<table><tr><th>Flag</th><th>Status</th><th>Points</th></tr>'+_board.map(function(c){
              // found flags by title; unfound stay masked (hint only) so the report never spoils what is left
              var _fl=c.found?esc(c.title):(c.hint?('??? &mdash; '+esc(c.hint)):'??? (no hint)');
              return '<tr><td>'+_fl+'</td><td>'+(c.found?'&#10003; found':'&#9633; not found')+'</td><td>'+esc(String(c.points||0))+'</td></tr>';
            }).join('')+'</table>');
          }
          var _qs=(_gm.quests||[]);
          if(_qs.length){ var _qd=_qs.filter(function(q){return q.status==='done';}).length;
            h.push('<p style="margin:.4em 0"><strong>Side quests:</strong> '+_qd+' / '+_qs.length+' complete</p>'); }
        }
      }
    }catch(_e){}
    // Per-item checkwork results (the grader's Y/N list) -- shown when a check actually ran. Just the
    // items + Yes/No (the student email / raw header are redundant and left out). This per-item list
    // sits ABOVE the progress/checkwork/duration summary so that summary is the report's final section (#102).
    try{ if(cwState==='ok' && cwGoals && cwGoals.length){
      h.push('<h2 style="border-bottom:1px solid var(--rule);color:var(--accent2);font-size:1.15em;margin-top:1.8em">Automated Checks &mdash; checkwork</h2>');
      h.push('<p style="margin:.2em 0 .5em;color:var(--muted)">Each graded item and whether it passed when you built this report.</p>');
      h.push('<table style="width:100%"><tr><th style="width:4.5em">Result</th><th>Graded item</th></tr>'+cwGoals.map(function(g){
        var mk = g.pass===true ? '<strong style="color:#3fb950">&#10003; Yes</strong>'
               : g.pass===false ? '<strong style="color:#f85149">&#10007; No</strong>' : '&mdash;';
        return '<tr><td>'+mk+'</td><td>'+esc(g.desc||g.name||'')+'</td></tr>';
      }).join('')+'</table>');
    } }catch(_e){}
    // Lab progress (manual checkboxes) + Check Work totals + duration -- the report's FINAL section,
    // immediately above the Revision + fingerprint footer (owner 2026-10-15, #102).
    var _pit=document.querySelectorAll('.progress-item'), _pd=0;
    _pit.forEach(function(cb){if(cb.checked)_pd++;});
    var _pt=_pit.length, _pp=_pt?Math.round(_pd*100/_pt):0;
    h.push('<h2 style="border-bottom:1px solid var(--rule);color:var(--accent2);font-size:1.15em;margin-top:1.8em">Progress &amp; Check Work</h2>');
    var _dur=donDuration();
    // Check Work reads from cwState so a report NEVER shows a misleading "0 / N" when the automated check
    // was simply never run (or the grader/bridge was unavailable). A true 0 only shows after a real run.
    var _cw = cwState==='ok'    ? ('<br><strong>Check Work:</strong> '+cwPassed+' / '+cwTotal+' automated goals passing')
            : cwState==='error' ? '<br><strong>Check Work:</strong> could not run — the grader/bridge was unavailable; this report is graded from your <code>.lab</code> submission'
            : (cwTotal?'<br><strong>Check Work:</strong> not run — use <em>Finish &amp; build report</em> (or the live check) to record it; the authoritative grade is your <code>.lab</code> submission':'');
    h.push('<div class="rptprog"><strong>Manual progress:</strong> '+_pd+' / '+_pt+' items complete ('+_pp+'%)'
      +_cw
      +(_dur?('<br><strong>Time in lab:</strong> '+_dur+' (h:mm)'):'')+'</div>');
    h.push('<div style="margin-top:2em;padding-top:.6em;border-top:1px solid var(--rule);color:var(--muted);font-size:.8em">bootcamp &middot; Revision: v0.0.011 20261112'+(window.__DLVER?(' &middot; donlab '+window.__DLVER):'')+' &middot; exported <span id="__rptdate"></span></div>');
    if(stamp) h.push('<div style="margin-top:.4em;color:var(--muted);font-size:.72em;font-family:monospace;word-break:break-all">'+stamp+'</div>');
    return h.join('\n').replace('id="__rptdate"></span>', 'id="__rptdate">'+new Date().toISOString().slice(0,10)+'</span>');
  }
  try{window.__donBuildReport=buildDoc;}catch(e){}  // test hook (harness calls the exact export fn)
  try{window.__donStamp=donStamp;window.__donCw=function(){return {t:cwTotal,p:cwPassed,s:cwState};};}catch(e){}  // test hooks (fingerprint + checkwork state)
  document.querySelectorAll('[data-ws]').forEach(function(b){b.addEventListener('click',function(){
    var k=b.getAttribute('data-ws');
    if(k==='show')document.querySelectorAll('details.answer').forEach(function(d){d.open=true;});
    else if(k==='hide')document.querySelectorAll('details.answer').forEach(function(d){d.open=false;});
    else if(k==='download'){
      var mail=getStudentEmail();
      donPrep(mail).then(function(stamp){
        var blob=new Blob([buildDoc(mail,stamp)],{type:'text/html'});
        var a2=document.createElement('a');a2.href=URL.createObjectURL(blob);
        var _pfx=(mail||'').split(/[@#]/)[0].replace(/[^A-Za-z0-9._-]/g,'');
        a2.download='report-'+LAB+(_pfx?'-'+_pfx:'')+'.html';document.body.appendChild(a2);a2.click();a2.remove();
      });
    }
    else if(k==='pdf'){
      // Print to PDF via a hidden iframe (a print dialog, not a blocked popup window).
      var mail=getStudentEmail();
      donPrep(mail).then(function(stamp){
        var ifr=document.createElement('iframe'); ifr.setAttribute('aria-hidden','true');
        ifr.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
        document.body.appendChild(ifr);
        var d=ifr.contentWindow.document; d.open(); d.write(buildDoc(mail,stamp)); d.close();
        setTimeout(function(){try{ifr.contentWindow.focus();ifr.contentWindow.print();}catch(e){}
          setTimeout(function(){ifr.remove();},2000);},500);
      });
    }
  });});

  // ---- top-right export menu (Lab Report primary; Lab Manual in dropdown) ----
  function exportReport(){
    // Prep the self-contained report and DOWNLOAD it directly -- no popup window (browsers block
    // those). The student opens/submits the file, or prints it to PDF from there.
    var _mail=getStudentEmail();
    donPrep(_mail).then(function(stamp){
      var blob=new Blob([buildDoc(_mail,stamp)],{type:'text/html'});
      var a=document.createElement('a'); a.href=URL.createObjectURL(blob);
      var _pfx=(_mail||'').split(/[@#]/)[0].replace(/[^A-Za-z0-9._-]/g,'');
      a.download='report-'+LAB+(_pfx?'-'+_pfx:'')+'.html'; document.body.appendChild(a); a.click();
      setTimeout(function(){a.remove(); try{URL.revokeObjectURL(a.href);}catch(e){}},1500);
    });
  }
  // ---- Finish & build report: the Download Lab Report button now runs the real wrap-up
  //      (checkwork -> stoplab -> build the report) with a confirm + stepped progress bar, so the
  //      report carries up-to-date grading and the .lab submission is packaged. Offline (no bridge)
  //      it falls back to a draft. exportReport() stays as that draft path. ----
  function wuEl(id){ return document.getElementById(id); }
  function wuView(which){ ['wuConfirm','wuProgress','wuDone'].forEach(function(s){ var e=wuEl(s); if(e)e.hidden=(s!==which); }); var ov=wuEl('wrapupOverlay'); if(ov)ov.hidden=false; }
  function wuClose(){ var ov=wuEl('wrapupOverlay'); if(ov)ov.hidden=true; }
  function wuStep(id,state){ var li=wuEl('wuStep-'+id); if(li)li.className=state?('wu-'+state):''; }
  function wuFill(p){ var f=wuEl('wuFill'); if(f)f.style.width=p+'%'; }
  function wuSetMode(online){
    var go=wuEl('wuGo'), draft=wuEl('wuDraft'), warn=wuEl('wuWarn'), off=wuEl('wuOffline');
    if(go)go.hidden=!online; if(warn)warn.hidden=!online; if(off)off.hidden=online;
    if(draft){ draft.className = online ? 'wu-secondary' : 'wu-primary'; }
  }
  // True when at least one prose answer box holds non-whitespace text: the gate for baking the report
  // backup into the .lab (never bake an answer-less manual as if it were a submission).
  function reportHasAnswers(){
    try{
      var boxes=document.querySelectorAll('.inq textarea[data-ans], .qcard textarea[data-ans]');
      for(var i=0;i<boxes.length;i++){ if(!boxes[i].hasAttribute('data-check') && (boxes[i].value||'').trim().length) return true; }
    }catch(e){}
    return false;
  }
  try{ window.__donReportHasAnswers=reportHasAnswers; }catch(e){}   // test hook
  // The orchestrated finish. Resolves to {checkwork,stoplab,archive_url,report} (a test hook awaits it).
  function runWrapUp(){
    var detail=wuEl('wuDetail'), status=wuEl('wuStatus');
    function say(m){ if(status)status.textContent=m; }
    function add(html){ if(detail)detail.insertAdjacentHTML('beforeend',html); }
    if(detail)detail.innerHTML=''; wuView('wuProgress'); wuFill(6);
    var result={checkwork:null,stoplab:null,archive_url:null,report:null};
    wuStep('check','run'); say('Running the automated checks against your lab… (about 10–15s)');
    return bridge('/api/checkwork?lab='+encodeURIComponent(LAB)).then(function(d){
      try{__donLastCW=(d&&d.raw)||null;}catch(e){}
      if(d&&d.goals&&d.goals.length){
        var scored=d.goals.filter(function(g){return g.pass===true||g.pass===false;});
        if(scored.length){ cwTotal=scored.length; cwPassed=scored.filter(function(g){return g.pass===true;}).length; cwState='ok';
          cwGoals=scored.map(function(g){return {name:g.name,desc:g.desc||'',pass:g.pass};});
          try{localStorage.setItem(CWKEY,JSON.stringify({t:cwTotal,p:cwPassed,g:cwGoals}));}catch(e){}
          if(window.__donRefresh)window.__donRefresh(); }
        result.checkwork={total:cwTotal,passed:cwPassed};
      }
      wuStep('check','done'); wuFill(40);
      add('<div class="wu-sub">checkwork: <strong>'+cwPassed+' / '+cwTotal+'</strong> automated goals passing</div>');
    }).catch(function(e){
      if(cwState!=='ok')cwState='error';   // grader/bridge failed -> the report says so, and still builds from the student's work
      wuStep('check','fail'); add('<div class="wu-sub wu-warn">checkwork could not run ('+esc2(String(e&&e.message||e))+') — continuing; your answers are still saved and will be in the report.</div>');
    }).then(function(){
      // BUILD + GATHER + STASH -- BEFORE stoplab, while the lab (and FRMS) is still up, so the report
      // carries its FRMS fingerprint AND a backup copy (report + scrubbed debug bundle) can be folded
      // into the .lab. The student still gets the report as a separate download here. Every step is
      // best-effort: a failure anywhere still leaves the student their saved answers and a draft path.
      wuStep('build','run'); say('Building your report and gathering diagnostics…'); wuFill(55);
      var _mail=getStudentEmail();
      return donPrep(_mail).then(function(stamp){ try{return buildDoc(_mail,stamp);}catch(e){return buildDoc(_mail,'');} })
        .catch(function(){ try{return buildDoc(_mail,'');}catch(e){return '';} })
        .then(function(docHtml){
          result.report=docHtml||null;
          // download the report to the student now (so they hold it even if stoplab later fails)
          if(docHtml){ try{ var blob=new Blob([docHtml],{type:'text/html'}); var a=document.createElement('a');
            a.href=URL.createObjectURL(blob);
            var _pfx=(_mail||'').split(/[@#]/)[0].replace(/[^A-Za-z0-9._-]/g,'');
            a.download='report-'+LAB+(_pfx?'-'+_pfx:'')+'.html'; document.body.appendChild(a); a.click();
            setTimeout(function(){a.remove(); try{URL.revokeObjectURL(a.href);}catch(e){}},1500);
          }catch(e){} }
          // gather the scrubbed debug bundle (never rejects), then stash the backup onto the lab VM so
          // stoplab folds it into the .lab. The REPORT is baked only when it carries real answers.
          return buildDebugText().catch(function(){return '';}).then(function(dbg){
            var payload={debug:dbg||''};
            if(docHtml && reportHasAnswers()) payload.report=docHtml;
            result.backup={report:!!payload.report,debug:!!payload.debug};
            return bridgePost('/api/stash?lab='+encodeURIComponent(LAB),payload).then(
              function(s){ try{ add('<div class="wu-sub">a backup copy was saved into your <code>.lab</code>'+((s&&s.stashed&&s.stashed.length)?(' ('+s.stashed.join(' + ')+')'):'')+'</div>'); }catch(e){} },
              function(){ /* best-effort: the student still has the separate downloads */ });
          }).then(function(){ wuStep('build', docHtml?'done':'fail'); wuFill(74); });
        });
    }).then(function(){
      // STOP -- packages the .lab, folding in the backup stashed above.
      wuStep('stop','run'); say('Stopping the lab and packaging your submission… (this can take ~20–40s)'); wuFill(88);
      return bridge('/api/stoplab?lab='+encodeURIComponent(LAB)).then(function(d){
        result.stoplab=d||null;
        if(d&&d.ok){ wuStep('stop','done'); result.archive_url=d.archive_url||null;
          add('<div class="wu-sub">lab stopped; submission packaged'+(d.archive?(' (<code>'+esc2(d.archive)+'</code>)'):'')+'</div>'); }
        else { wuStep('stop','fail'); add('<div class="wu-sub wu-warn">stoplab did not complete — run <code>stoplab '+esc2(LAB)+'</code> in your lab terminal.</div>'); }
      }).catch(function(e){
        wuStep('stop','fail'); add('<div class="wu-sub wu-warn">stoplab could not run ('+esc2(String(e&&e.message||e))+').</div>');
      });
    }).then(function(){
      // DONE
      wuFill(100);
      var cwMsg = cwState==='ok' ? (' with <strong>'+cwPassed+' / '+cwTotal+'</strong> automated goals passing')
                : cwState==='error' ? ' (the automated checks could not run — your answers are in the report; you are graded from your <code>.lab</code> submission)'
                : '';
      var dm=wuEl('wuDoneMsg');
      if(dm){
        if(result.report){
          dm.innerHTML='Your report downloaded'+cwMsg+'. '+
            (result.archive_url?'Your <code>.lab</code> submission is packaged (a backup copy of your report is tucked inside) — download it below and submit both.':'Submit the downloaded report.');
        } else {
          dm.innerHTML='The report could not be built automatically'+cwMsg+'. Your answers are still saved in this browser — use <strong>Download a draft</strong>, or try again.'+
            (result.archive_url?' Your <code>.lab</code> submission is still packaged below.':'');
        }
      }
      var ar=wuEl('wuArchive');
      if(ar){ if(result.archive_url){ ar.setAttribute('href',result.archive_url); ar.hidden=false; } else { ar.hidden=true; } }
      wuView('wuDone');
      return result;
    });
  }
  function openWrapUp(){
    var ov=wuEl('wrapupOverlay'); if(!ov){ exportReport(); return; }   // no modal in DOM -> old behavior
    wuView('wuConfirm'); wuSetMode(true);   // optimistic; the ping flips it offline if unreachable
    bridge('/api/ping').then(function(){ wuSetMode(true); }).catch(function(){ wuSetMode(false); });
  }
  (function(){
    var go=wuEl('wuGo'), draft=wuEl('wuDraft'), cancel=wuEl('wuCancel'), close2=wuEl('wuClose2');
    if(go)go.addEventListener('click',function(){ try{ var p=runWrapUp(); if(p&&p.catch)p.catch(function(){}); }catch(e){} });
    if(draft)draft.addEventListener('click',function(){ wuClose(); exportReport(); donToast('Draft downloaded — the lab was not stopped.'); });
    if(cancel)cancel.addEventListener('click',wuClose);
    if(close2)close2.addEventListener('click',wuClose);
    var ov=wuEl('wrapupOverlay');
    // Click the backdrop to dismiss, but never mid-run (progress view visible).
    if(ov)ov.addEventListener('click',function(e){ var pr=wuEl('wuProgress'); if(e.target===ov && (!pr||pr.hidden)) wuClose(); });
    // Escape closes only from the confirm or done view (never mid-run)
    document.addEventListener('keydown',function(e){ if((e.key==='Escape'||e.keyCode===27) && ov && !ov.hidden){ var pr=wuEl('wuProgress'); if(!pr||pr.hidden) wuClose(); } });
  })();
  try{ window.__donRunWrapUp=runWrapUp; window.__donOpenWrapUp=openWrapUp; }catch(e){}   // test hooks
  var _er=document.getElementById('btnExportReport'); if(_er) _er.addEventListener('click',openWrapUp);

  // ============================================================================
  // PRINT HIJACK: the student's browser "Print to PDF" (Ctrl+P / File>Print, and our
  // "Save as PDF" menu item) emits our CUSTOM Lab Report -- answers, FRMS record, progress,
  // screenshots, fingerprint, clean layout -- instead of the raw manual (nav/banners/FAQ,
  // and clipped textareas). The <textarea> stays the single source of truth; nothing here
  // changes saved/exported data. (owner decision 2026-10-07; student-reported truncation.)
  // ============================================================================
  // Pre-warm the tamper-evidence stamp so a hijacked print can include it (beforeprint can't await).
  try{ donPrep(storedEmail()).then(function(s){window.__donLastStamp=s;},function(){}); }catch(e){}

  // Full-answer mirrors: used by the READING-COPY print so a long answer typed into the manual
  // (a live <textarea> prints only its visible area) is not clipped. Hidden on screen; never saved.
  function syncPrintAnswers(){
    var esc=function(x){return (x||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');};
    try{ if(window.DonWritebox&&window.DonWritebox.collapseZen) window.DonWritebox.collapseZen(); }catch(e){}
    document.querySelectorAll('textarea[data-ans]').forEach(function(ta){
      var id=ta.getAttribute('data-ans'); if(!ta.parentNode) return;
      var sel='.print-answer[data-ans-print="'+(window.CSS&&CSS.escape?CSS.escape(id):id)+'"]';
      var m=ta.parentNode.querySelector(sel);
      if(!m){ m=document.createElement('div'); m.className='print-answer'; m.setAttribute('data-ans-print',id);
              m.setAttribute('aria-hidden','true'); ta.parentNode.insertBefore(m, ta.nextSibling); }
      var v=ta.value||'';
      m.innerHTML = v ? ((window.DonWritebox&&window.DonWritebox.md)?window.DonWritebox.md(v):esc(v).replace(/\n/g,'<br>'))
                      : '<span class="print-empty">(left blank)</span>';
    });
  }

  var __donPrintMode='report';   // 'report' (hijack -> custom report) | 'manual' (raw reading copy)
  function clearPrintSwap(){
    try{ document.documentElement.classList.remove('printing-report'); }catch(e){}
    var st=document.getElementById('__donPrintCss'); if(st) st.textContent='';
  }
  // Build the in-page custom report for printing by REUSING buildDoc (the exact download report): split
  // off its <style> and body, inject the style as a print-only sheet, and show the body in a print-only
  // container while every other body child is hidden. No screen/raw-manual leak: the sheet is emptied and
  // the class removed on afterprint, and the container is display:none on screen.
  function buildPrintSwap(){
    var full=buildDoc(storedEmail(), window.__donLastStamp||'');
    var css=(full.match(/<style>([\s\S]*?)<\/style>/)||['',''])[1];
    var body=full.slice(full.indexOf('<\/style>')+8);
    var host=document.getElementById('__donPrintReport');
    if(!host){ host=document.createElement('div'); host.id='__donPrintReport'; host.setAttribute('aria-hidden','true'); document.body.appendChild(host); }
    host.innerHTML=body;
    var st=document.getElementById('__donPrintCss');
    if(!st){ st=document.createElement('style'); st.id='__donPrintCss'; st.setAttribute('media','print'); document.head.appendChild(st); }
    st.textContent='@media print{html.printing-report body>*:not(#__donPrintReport){display:none!important}'
      +'#__donPrintReport{display:block!important}}\n'+css;
    try{ document.documentElement.classList.add('printing-report'); }catch(e){}
  }
  function onBeforePrint(){
    syncPrintAnswers();                                  // keep the reading copy's answers full
    if(__donPrintMode==='manual'){ clearPrintSwap(); return; }   // reading copy: print the raw manual
    try{ buildPrintSwap(); }catch(e){ clearPrintSwap(); }         // default: emit the custom report
  }
  function onAfterPrint(){ clearPrintSwap(); __donPrintMode='report'; }
  try{ window.addEventListener('beforeprint', onBeforePrint); window.addEventListener('afterprint', onAfterPrint); }catch(e){}

  // test hooks (jsdom has no print events): drive the same code paths the browser would
  try{ window.__donSyncPrintAnswers=syncPrintAnswers; window.__donBuildPrintSwap=buildPrintSwap;
       window.__donSetPrintMode=function(m){__donPrintMode=m;};
       window.__donOnBeforePrint=onBeforePrint; window.__donOnAfterPrint=onAfterPrint; }catch(e){}

  // ---- Debug Log export: a troubleshooting bundle (bridge status, lab state, recent errors),
  //      downloaded directly (no popup). Student email/name are SCRUBBED before the file is built;
  //      only a non-reversible short hash of the email is kept as an identifier. ----
  function sha256hex(s){
    if(!(window.crypto&&crypto.subtle&&window.TextEncoder)) return Promise.resolve('');
    return crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)).then(function(buf){
      return Array.prototype.map.call(new Uint8Array(buf),function(b){return ('0'+b.toString(16)).slice(-2);}).join('');
    }).catch(function(){return '';});
  }
  function scrubPII(text, mail){
    var out=String(text||'');
    if(mail){
      var local=mail.split(/[@#]/)[0], pats=[mail, local];
      local.split(/[._\-+]/).forEach(function(p){ if(p.length>=3) pats.push(p); });   // name fragments
      pats.forEach(function(p){ if(p){ try{ out=out.replace(new RegExp(p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi'),'[student]'); }catch(e){} } });
    }
    // belt-and-suspenders: redact any remaining email-looking token
    return out.replace(/[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/g,'[email]');
  }
  // Build the scrubbed debug bundle text (Promise<string>); reused by the Debug Log download AND by the
  // wrap-up, which bakes it into the .lab. Never rejects -- off the bridge it still returns a valid bundle.
  function buildDebugText(){
    var mail=storedEmail();                         // do NOT prompt; scrub whatever is already set
    var its=document.querySelectorAll('.progress-item'), md=0; its.forEach(function(c){if(c.checked)md++;});
    var extra=['== metadata ==','lab: '+LAB,'revision: '+(DON_REVISION||'0'),'donlab: '+(window.__DLVER||'unknown'),
      'generated: '+new Date().toISOString(),'origin: '+location.origin+location.pathname,
      'scheme: '+location.protocol,'user_agent: '+navigator.userAgent,
      '','== progress ==','manual items checked: '+md+'/'+its.length+'    checkwork passing: '+cwPassed+'/'+cwTotal,
      '','== recent page errors / warnings =='].concat(__donErr.length?__donErr:['(none captured this session)']);
    extra.push(''); extra.push('== last checkwork output (this session) ==');
    extra.push(__donLastCW?__donLastCW:'(checkwork not run via the bridge this session)');
    extra.push(''); extra.push('== bridge / lab state ==');
    function compose(){
      var body=extra.join('\n');
      return sha256hex(mail||'').then(function(hx){
        var hdr=(mail?('student_id (sha256 of email, truncated): '+(hx?hx.slice(0,16):'n/a')):'student_id: (no email set)');
        return 'DoN Range debug log -- student identifiers scrubbed\n'+hdr+'\n\n'+scrubPII(body, mail)+'\n';
      });
    }
    return bridge('/api/ping').then(function(p){
      extra.push('bridge reachable: yes ('+((p&&p.bridge)||'?')+')');
      return bridge('/api/debug?lab='+encodeURIComponent(LAB)).then(function(d){
        extra.push('lab state: '+JSON.stringify(d));
      },function(){ extra.push('lab state: (/api/debug not available on this bridge)'); });
    },function(){
      extra.push('bridge reachable: NO -- manual opened off the lab VM / no bridge running. Live buttons and lab state are unavailable; the rest of this bundle is still valid.');
    }).then(compose, compose);
  }
  function exportDebug(){
    buildDebugText().then(function(out){
      var blob=new Blob([out],{type:'text/plain'});
      var a=document.createElement('a'); a.href=URL.createObjectURL(blob);
      a.download='debug-'+LAB+'-'+new Date().toISOString().replace(/[:T]/g,'-').slice(0,16)+'.txt';
      document.body.appendChild(a); a.click();
      setTimeout(function(){a.remove();try{URL.revokeObjectURL(a.href);}catch(e){}},1500);
      donToast('Debug log downloaded (student identifiers scrubbed).');
    });
  }
  try{ window.__donBuildDebugText=buildDebugText; }catch(e){}   // test hook (wrap-up bakes this into the .lab)
  var _ed=document.getElementById('btnExportDebug'); if(_ed) _ed.addEventListener('click',exportDebug);
  var _mo=document.getElementById('btnExportMore'), _dd=document.getElementById('exportMore');
  if(_mo&&_dd){
    _mo.addEventListener('click',function(e){e.stopPropagation();var open=!_dd.hidden;_dd.hidden=open;_mo.setAttribute('aria-expanded',String(!open));});
    document.addEventListener('click',function(){_dd.hidden=true;_mo.setAttribute('aria-expanded','false');});
  }

  // ---- Actions menu (Check Work / Stop Lab / Reset Lab) ----
  var _act=document.getElementById('btnActions'), _actm=document.getElementById('actionsMenu');
  if(_act&&_actm){
    _act.addEventListener('click',function(e){e.stopPropagation();var open=!_actm.hidden;_actm.hidden=open;_act.setAttribute('aria-expanded',String(!open));});
    _actm.addEventListener('click',function(e){e.stopPropagation();_actm.hidden=true;_act.setAttribute('aria-expanded','false');});
    document.addEventListener('click',function(){_actm.hidden=true;_act.setAttribute('aria-expanded','false');});
  }

  // ---- toast + clipboard helpers (Stop Lab / Check Work) ----
  function donToast(msg){var t=document.createElement('div');t.className='don-toast';t.textContent=msg;
    document.body.appendChild(t);setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t);},4600);}
  function donCopy(s){if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(s).catch(function(){});return;}
    try{var ta=document.createElement('textarea');ta.value=s;ta.style.position='fixed';ta.style.opacity='0';
      document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();}catch(e){}}

  // ---- optional local bridge: when this page is served by donlab / the lab-bridge, the
  //      Check Work / Stop Lab buttons drive the REAL checkwork / stoplab commands. Opened
  //      as a plain file (no bridge) every call falls back to copying the command. ----
  function bridge(pathq){
    return fetch(location.origin+pathq,{cache:'no-store'}).then(function(r){
      if(!r.ok) throw new Error('http '+r.status); return r.json(); });
  }
  function bridgePost(pathq,obj){
    return fetch(location.origin+pathq,{method:'POST',cache:'no-store',
      headers:{'Content-Type':'application/json'},body:JSON.stringify(obj||{})}).then(function(r){
      if(!r.ok) throw new Error('http '+r.status); return r.json(); });
  }
  // The e-mail the student gave the framework at the terminal is the identity the lab is graded under, so
  // the report export uses it without asking again: the host bridge (127.0.0.1 only) serves it from
  // Labtainers' own record, and it lands where getStudentEmail() reads it. Fails silently off the bridge.
  try{bridge('/api/email').then(function(d){var e=((d&&d.email)||'').trim();
    if(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)){try{localStorage.setItem('donmail',e);}catch(_){}}}).catch(function(){});}catch(e){}
  // ---- "hire a contractor": apply an intentional break's fix for budget + a reputation hit -----------
  // A planted break is never a hard blocker. The button POSTs to the bridge, which applies the fix in the
  // container; on success we record the reputation hit (narrative, same-origin) and show the dollar cost.
  (function(){
    var boxes=[].slice.call(document.querySelectorAll('.contractor'));
    boxes.forEach(function(box){
      var btn=box.querySelector('.contractor-btn'), out=box.querySelector('.contractor-result');
      if(!btn) return;
      btn.addEventListener('click',function(){
        var lab=box.getAttribute('data-lab'), id=box.getAttribute('data-break');
        var cost=parseInt(box.getAttribute('data-cost')||'0',10), rep=parseInt(box.getAttribute('data-rep')||'0',10);
        if(!window.confirm('Hire a contractor to fix this? It costs $'+cost.toLocaleString()+' from your FRMS budget and '+rep+' reputation. Troubleshooting it yourself is free.')) return;
        btn.disabled=true; if(out){out.hidden=false; out.className='contractor-result'; out.textContent='Dispatching the contractor...';}
        fetch(location.origin+'/api/contractor?lab='+encodeURIComponent(lab)+'&id='+encodeURIComponent(id),
              {method:'POST',cache:'no-store'})
          .then(function(r){return r.json().then(function(j){return {code:r.status,j:j};});})
          .then(function(x){
            if(x.j&&x.j.applied){
              try{ if(window.DonGameOverlay&&window.DonGameOverlay.contractorCharge){window.DonGameOverlay.contractorCharge({lab:lab,id:id,cost:cost,rep:rep});} }catch(e){}
              if(out){out.className='contractor-result ok'; out.textContent='Fixed by the contractor. Charged $'+cost.toLocaleString()+' and '+rep+' reputation.';}
            } else {
              btn.disabled=false;
              if(out){out.className='contractor-result bad'; out.textContent=(x.j&&x.j.error)?('Could not apply: '+x.j.error):'Open this manual on the lab VM to use this.';}
            }
          })
          .catch(function(){ btn.disabled=false; if(out){out.className='contractor-result bad'; out.textContent='Open this manual on the lab VM (the live bridge) to hire a contractor.';} });
      });
    });
  })();
  var esc2=function(x){return (x||'').replace(/&/g,'&amp;').replace(/</g,'&lt;');};
  function showModal(titleHtml, bodyHtml){
    var ov=document.createElement('div'); ov.className='cw-overlay no-print';
    ov.innerHTML='<div class="cw-modal" role="dialog" aria-modal="true">'+
      '<button class="cw-close" type="button" aria-label="Close">&#215;</button>'+
      '<h2>'+titleHtml+'</h2>'+bodyHtml+'</div>';
    function close(){ if(ov.parentNode)ov.parentNode.removeChild(ov); }
    ov.addEventListener('click',function(e){if(e.target===ov)close();});
    ov.querySelector('.cw-close').addEventListener('click',close);
    document.body.appendChild(ov); return ov;
  }
  function slResult(d){
    var b='';
    if(d&&d.ok){
      b+='<p>The lab has been stopped and your work collected.</p>';
      if(d.archive_url) b+='<p><strong>1. Download your submission archive</strong> (the file you hand in):<br>'+
        '<a class="cw-dl" href="'+d.archive_url+'" download>&#11015; '+esc2(d.archive||'lab archive')+'</a></p>';
      else b+='<p><strong>1.</strong> Your submission archive is under <code>~/labtainer_xfer/'+LAB+'/</code>.</p>';
      b+='<p><strong>2. Export your Lab Report</strong> (answers + screenshots): '+
        '<button type="button" class="cw-inline" id="slExport">&#11015; Export Lab Report</button></p>';
      b+='<p><strong>3.</strong> Submit both per your course instructions.</p>';
      if(d.raw) b+='<details><summary>stoplab output</summary><div class="cw-raw">'+esc2(d.raw)+'</div></details>';
    } else b+='<p>Could not stop the lab automatically. Run <code>stoplab '+LAB+'</code> in your lab terminal.</p>';
    var ov=showModal('&#9632; Lab stopped', b);
    var ex=ov.querySelector('#slExport'); if(ex)ex.addEventListener('click',exportReport);
    donToast('Lab '+LAB+' stopped.');
  }

  // ---- Stop Lab: stop the lab for real (bridge), else hand over the command ----
  var _sl=document.getElementById('btnStopLab');
  if(_sl) _sl.addEventListener('click',function(){
    if(!confirm('Stop this lab?\n\nSave your work first; the containers will be shut down. You re-launch with donlab to continue.')) return;
    donToast('Stopping '+LAB+' …');
    bridge('/api/stoplab?lab='+encodeURIComponent(LAB)).then(slResult).catch(function(){
      donCopy('stoplab '+LAB);
      donToast('No live bridge — copied “stoplab '+LAB+'”. Paste it in your lab terminal.');
    });
  });

  // ---- Reset Lab: start.py -r = a fresh instance; the student's current work is DISCARDED,
  //      so this is guarded by an explicit confirmation before we ever call the bridge. ----
  var _rst=document.getElementById('btnResetLab');
  if(_rst) _rst.addEventListener('click',function(){
    if(!confirm('Reset '+LAB+' to a fresh start?\n\nThis DISCARDS the running containers and everything in them and starts a fresh instance. There is no undo.\n\nExport your Lab Report first if you want to keep your answers and screenshots.')) return;
    if(!confirm('Confirm reset. Work inside the running containers is discarded; exported reports and the answers saved in this browser are kept.')) return;
    donToast('Resetting '+LAB+' … this can take a minute.');
    bridge('/api/resetlab?lab='+encodeURIComponent(LAB)).then(function(d){
      if(d&&d.ok) donToast('Lab '+LAB+' has been reset to a fresh instance.');
      else{
        var b='<p>Could not reset the lab automatically. In your lab terminal run:</p>'+
          '<div class="cw-cmd"><code>stoplab '+LAB+'</code> &nbsp;then&nbsp; <code>start.py '+LAB+' -r</code></div>';
        if(d&&d.raw) b+='<details><summary>reset output</summary><div class="cw-raw">'+esc2(d.raw)+'</div></details>';
        showModal('&#8635; Reset Lab', b);
      }
    }).catch(function(){
      donCopy('start.py '+LAB+' -r');
      donToast('No live bridge — copied “start.py '+LAB+' -r”. Run it in your lab terminal (stoplab first).');
    });
  });

  // ---- Bearings: credentials / network / people reference (opens on Credentials) ----
  // FRMS link: same host as this page when served over http (works through a forwarded port too)
  // In-text FRMS links (<a class="frms-go" data-frms="risk">) open the named FRMS tab in the same window.
  (function(){var f=document.getElementById('btnFrms'), inlab=false,
    seat="your workstation";
    // FRMS in the lab (hi-web01): the links name the FRMS tab to open on the student's workstation; there is no
    // host FRMS window to open, and the manual carries no FRMS button (FRMS is reached from the workstation's
    // Firefox: the FRMS bookmark, or the address typed in).
    if(inlab){document.querySelectorAll('a.frms-go').forEach(function(a){var t=(a.getAttribute('data-frms')||'').replace(/[^a-z]/g,'');
      var sp=document.createElement('strong'); sp.className='frms-inlab'; sp.textContent=a.textContent;
      sp.title='In FRMS on '+seat+' (Firefox, FRMS bookmark): https://frms.fcdpac.navy.mil/'+(t?'#'+t:''); a.parentNode.replaceChild(sp,a);}); return;}
    if(f&&/^https?:$/.test(location.protocol)&&location.hostname){f.href=location.protocol+'//'+location.hostname+':5174/';}
    document.querySelectorAll('a.frms-go').forEach(function(a){var t=(a.getAttribute('data-frms')||'').replace(/[^a-z]/g,'');
      a.href=(f?f.href:'http://127.0.0.1:5174/')+(t?'#'+t:'');
      a.target='frms'; a.rel='noopener';});})();
  var _brg=document.getElementById('btnBearings'), _brgOv=document.getElementById('bearingsOverlay');
  function bearingsTab(name){ if(!_brgOv)return;
    var _m=_brgOv.querySelector('.sa-modal'); if(_m&&name!=='net')_m.classList.remove('sa-wide');
    _brgOv.querySelectorAll('.sa-tab').forEach(function(b){b.classList.toggle('active',b.getAttribute('data-sa')===name);});
    _brgOv.querySelectorAll('.sa-panel').forEach(function(p){p.hidden=(p.getAttribute('data-sa-panel')!==name);});
  }
  function bearingsOpen(){ if(_brgOv){_brgOv.hidden=false; bearingsTab('creds');} }
  function bearingsClose(){ if(_brgOv)_brgOv.hidden=true; }
  function saCopy(btn){
    var v=btn.getAttribute('data-copy')||'';
    function ok(){var o=btn.innerHTML; btn.innerHTML='&#10003;'; btn.classList.add('copied');
      setTimeout(function(){btn.innerHTML=o; btn.classList.remove('copied');},1100);}
    function legacy(){try{var ta=document.createElement('textarea');ta.value=v;ta.style.position='fixed';
      ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();
      document.execCommand('copy');document.body.removeChild(ta);ok();}catch(e){}}
    if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(v).then(ok,legacy);}
    else legacy();
  }
  if(_brg)_brg.addEventListener('click',bearingsOpen);
  var _brgX=document.getElementById('bearingsClose'); if(_brgX)_brgX.addEventListener('click',bearingsClose);
  if(_brgOv){
    _brgOv.addEventListener('click',function(e){if(e.target===_brgOv)bearingsClose();});
    _brgOv.querySelectorAll('.sa-tab').forEach(function(b){b.addEventListener('click',function(){bearingsTab(b.getAttribute('data-sa'));});});
    // Bound document-wide so inline copy buttons in the manual body (e.g. next to a sudo password) work too.
    document.querySelectorAll('.sa-copy').forEach(function(b){b.addEventListener('click',function(e){e.stopPropagation();saCopy(b);});});
    // Network tab: toggle between the Tables view and the Diagram view.
    _brgOv.querySelectorAll('.sa-vt').forEach(function(b){b.addEventListener('click',function(){
      var v=b.getAttribute('data-net-view');
      _brgOv.querySelectorAll('.sa-vt').forEach(function(x){x.classList.toggle('active',x===b);});
      _brgOv.querySelectorAll('[data-net-body]').forEach(function(x){x.hidden=(x.getAttribute('data-net-body')!==v);});
      var _mo=_brgOv.querySelector('.sa-modal'); if(_mo)_mo.classList.toggle('sa-wide', v==='global');
      if(v==='global')ntRender();
    });});
    function ntRender(){
      var s=document.getElementById('nt-bearings-svg'); if(!s||!window.DONTerrain)return;
      var L={graticule:true}; _brgOv.querySelectorAll('.nt-tog').forEach(function(c){L[c.getAttribute('data-nt')]=c.checked;});
      var pal={land:'#16324a',landStroke:'#24516f',grat:'#123247',cable:'#4f9fd6',cableGuam:'#ff922b',cloud:'#51cf66',gov:'#f06595',dod:'#ff6b6b',rir:{arin:'#4c6ef5',ripe:'#12b886',apnic:'#f0a000',lacnic:'#b06bd6',afrinic:'#e8615a'},text:'#8aa0ad'};
      s.innerHTML='<rect width="1000" height="500" fill="#0b1a26"/>'+DONTerrain.svg({proj:function(a,o){return [(o+180)/360*1000,(90-a)/180*500];},W:1000,H:500,layers:L,palette:pal});
      if(DONTerrain.applyZoom){ _brgOv.__ntz=DONTerrain.applyZoom(s,{W:1000,H:500}); }
    }
    var _zi=document.getElementById('nt-zin'),_zo=document.getElementById('nt-zout'),_zr=document.getElementById('nt-zreset');
    if(_zi)_zi.addEventListener('click',function(){_brgOv.__ntz&&_brgOv.__ntz.zoomBy(1.5);});
    if(_zo)_zo.addEventListener('click',function(){_brgOv.__ntz&&_brgOv.__ntz.zoomBy(1/1.5);});
    if(_zr)_zr.addEventListener('click',function(){_brgOv.__ntz&&_brgOv.__ntz.reset();});
    _brgOv.querySelectorAll('.nt-tog').forEach(function(c){c.addEventListener('change',ntRender);});
  }
  document.addEventListener('keydown',function(e){if((e.key==='Escape'||e.keyCode===27)&&_brgOv&&!_brgOv.hidden)bearingsClose();});

  // ---- Completion gate: reveal every .gated-after (and hide every .gated-lock) once EVERY
  // progress item is checked. Drives BOTH the Debrief section and the Bearings before/after
  // content (the fuller network, roster, and credentials unlock together). ----
  function labGate(){
    var items=document.querySelectorAll('.progress-item');
    var itemsDone=(items.length>0)&&Array.prototype.every.call(items,function(cb){return cb.checked;});
    // The debrief (Key Takeaways -- it can carry spoilers) stays locked until EVERY section is complete
    // AND every progress gate has been passed. Scroll gates transitively require the gated sections be
    // reached, but AND-ing them in makes the guarantee explicit regardless of where progress items sit.
    var gatesDone=(typeof window.__donGatesAllPassed==='function')?!!window.__donGatesAllPassed():true;
    var done=itemsDone&&gatesDone;
    document.querySelectorAll('.gated-after').forEach(function(el){el.hidden=!done;});
    document.querySelectorAll('.gated-lock').forEach(function(el){el.hidden=done;});
    // grey/ungrey the sidebar links for sections inside the locked debrief (e.g. Key Takeaways)
    try{ if(window.__donGateApply) window.__donGateApply(); }catch(e){}
  }
  try{ window.__donLabGate=labGate; }catch(e){}   // so the gate engine can re-evaluate the debrief on commit
  // Delegated (progress checkboxes are injected dynamically); init + a tick for restored state.
  document.addEventListener('change',function(e){
    if(e.target&&e.target.classList&&e.target.classList.contains('progress-item')) labGate();});
  labGate(); setTimeout(labGate,400);

  // ---- Progressive disclosure gates (#131): collapse content after the first UNSATISFIED gate
  // until its named answer box(es) hold text (an ATTEMPT, not a correct answer). Opt-in (inert with
  // no .scroll-gate markers), fail-open (ANY error reveals everything), sticky once passed (never
  // re-locks after the student has done the work), and it never touches the Lab Report, print, or
  // grading. The exempt boundary (#debriefLock/#debriefContent/#faqlist/#cwProgress) and everything
  // after it -- Help/FAQ, Bearings, the debrief (its own gate) -- is never hidden. ----
  (function(){
    function gls(k){try{return localStorage.getItem(k);}catch(e){return null;}}
    function gss(k,v){try{localStorage.setItem(k,v);}catch(e){}}
    var LABK='gate:bootcamp:';
    var gates=[], applying=false, mo=null;
    // The exempt boundary: the earliest DIRECT body child that begins the Debrief/Support region.
    // Everything from here on (the gated Key Takeaways with its own lock, Grading, Deliverables, the
    // Help/FAQ) is NEVER touched by the scroll gate, so those stay reachable at all times. (Must be a
    // real body child -- #cwProgress is nested UI and would never match the body-children loop.)
    function stopEl(){
      var sel='#debriefLock,#debriefContent,#faqlist', kids=document.body.children, i;
      for(i=0;i<kids.length;i++){ if(kids[i].matches && kids[i].matches(sel)) return kids[i]; }
      var a=document.querySelector(sel); while(a && a.parentNode!==document.body) a=a.parentNode;
      return a;
    }
    function revealAll(){ try{
      if(mo){mo.disconnect();mo=null;}
      document.querySelectorAll('.gate-hidden').forEach(function(el){el.classList.remove('gate-hidden');});
      document.querySelectorAll('#TOC a.gate-locked').forEach(function(a){a.classList.remove('gate-locked');});
      document.querySelectorAll('.gate-banner').forEach(function(b){b.classList.add('gate-hidden');});
    }catch(e){} }
    function taOf(id){
      var sel='textarea[data-ans="'+((window.CSS&&CSS.escape)?CSS.escape(id):id)+'"]';
      try{ return document.querySelector(sel); }catch(e){ return null; }
    }
    function boxFilled(id){ var ta=taOf(id); if(!ta) return true; return (ta.value||'').trim().length>0; }
    var committed={};                               // in-memory, survives a no-localStorage session
    function allFilled(g){ return !g.ids.length || g.ids.every(boxFilled); }
    // Passed = the student deliberately COMMITTED (clicked Continue; persisted sticky + in memory), OR
    // there is nothing real to require. NOT merely non-empty -- the commit is what hard-locks the answers,
    // so a student cannot go back and change a gating answer after reading past it.
    function passed(g){
      if(committed[g.key]===true || gls(LABK+g.key)==='1') return true;
      if(!g.ids.length) return true;
      return g.ids.every(function(id){ return !taOf(id); });   // all required boxes absent -> fail-open
    }
    // Continue: hard-lock each required answer (reuses setupReveal's lock -> read-only + append-only box
    // + revSet, which the Lab Report renders), then record the pass and reveal.
    function commit(g){
      try{ g.ids.forEach(function(id){ var fn=window.__gateCommit&&window.__gateCommit[id]; if(fn){ try{fn();}catch(e){} } }); }catch(e){}
      committed[g.key]=true; gss(LABK+g.key,'1');
      apply();
      try{ if(window.__donLabGate) window.__donLabGate(); }catch(e){}   // re-evaluate the debrief lock (Key Takeaways)
    }
    // Exposed so the debrief lock (labGate) can keep Key Takeaways hidden until EVERY gate is passed,
    // and so tests can assert it. Fail-open: any error -> treat as passed (never trap the student).
    try{ window.__donGatesAllPassed=function(){ try{ return gates.every(passed); }catch(e){ return true; } }; }catch(e){}
    function build(){
      if(!document.querySelector('.scroll-gate')) return false;   // no gates -> inert
      var stop=stopEl(), kids=[].slice.call(document.body.children);
      for(var i=0;i<kids.length;i++){
        var el=kids[i];
        if(stop && el===stop) break;               // exempt region begins; never a gate past here
        if(el.classList && el.classList.contains('scroll-gate')){
          var ids=(el.getAttribute('data-requires')||'').split(/\s+/).filter(Boolean);
          var b=document.createElement('div'); b.className='gate-banner no-print';
          el.parentNode.insertBefore(b, el.nextSibling);
          gates.push({el:el, ids:ids, msg:el.getAttribute('data-gate-msg')||'',
                      key:'g'+gates.length+'_'+ids.join('-').slice(0,48), banner:b});
        }
      }
      return gates.length>0;
    }
    function esc(s){ return String(s).replace(/[<>&]/g,function(c){return {'<':'&lt;','>':'&gt;','&':'&amp;'}[c];}); }
    function renderBanner(g){
      g.banner.innerHTML='<span class="gate-lock" aria-hidden="true">&#128274;</span>'+
        '<span class="gate-title">More of this lab is below</span>'+
        '<span class="gate-msg">'+esc(g.msg||'Record your answer above to continue.')+'</span>'+
        '<button type="button" class="gate-continue">Continue &#8595;</button>'+
        '<span class="gate-sub"></span>';
      var btn=g.banner.querySelector('.gate-continue');
      if(btn) btn.addEventListener('click', function(){ if(allFilled(g)) commit(g); });
      reflectBanner(g);
    }
    function reflectBanner(g){
      var btn=g.banner.querySelector('.gate-continue'), sub=g.banner.querySelector('.gate-sub');
      var ready=allFilled(g);
      if(btn){ btn.disabled=!ready; btn.title=ready?'Continue (locks your answer above)':'Record your answer above first'; }
      if(sub) sub.textContent = ready
        ? 'Continuing locks your answer(s) above — you can still add notes afterward. Help/FAQ, Grading and Deliverables stay open.'
        : 'Record your answer above, then Continue. Continuing locks your answer(s) above (you can still add notes afterward).';
    }
    // Position-based: hide every body child AFTER the active gate's banner, up to the exempt boundary.
    // Recomputed live each call, so anything injected later (e.g. "Mark complete" labels) is caught too.
    function apply(){
      if(applying) return; applying=true;
      try{
        var active=-1, i;
        for(i=0;i<gates.length;i++){ if(!passed(gates[i])){ active=i; break; } }
        var stop=stopEl(), kids=[].slice.call(document.body.children);
        var bannerEls=gates.map(function(g){return g.banner;});
        var activeBanner=(active>=0)?gates[active].banner:null;
        var hiding=false;
        for(i=0;i<kids.length;i++){
          var el=kids[i];
          if(stop && el===stop) break;
          if(el===activeBanner){ hiding=true; el.classList.remove('gate-hidden'); continue; } // active banner stays
          if(bannerEls.indexOf(el)>=0){ el.classList.add('gate-hidden'); continue; }           // other banners off
          el.classList.toggle('gate-hidden', hiding);
        }
        for(i=0;i<gates.length;i++){ if(i===active){
          if(!gates[i].banner.querySelector('.gate-continue')) renderBanner(gates[i]); else reflectBanner(gates[i]);
        } }
        try{var dc=document.querySelector('#debriefContent');
          [].slice.call(document.querySelectorAll('#TOC a[href^="#"]')).forEach(function(a){
          var t=document.getElementById(decodeURIComponent(a.getAttribute('href').slice(1)));
          // grey a TOC link whose target is hidden -- by the scroll gate OR inside the locked debrief
          // (Key Takeaways lives in #debriefContent[hidden] until every section + gate is complete).
          var inLockedDebrief=!!(t && dc && dc.hasAttribute('hidden') && dc.contains(t));
          a.classList.toggle('gate-locked', (!!(t && t.classList.contains('gate-hidden'))) || inLockedDebrief);
        });}catch(e){}
      }catch(e){ revealAll(); }
      applying=false;
    }
    try{ window.__donGateApply=apply; }catch(e){}   // labGate re-runs this so the TOC re-greys when the debrief (un)locks
    // apply() is O(sections + TOC links); running it on EVERY keystroke stalled typing in a large lab on
    // older Firefox / a modest VM (student-reported, cs3670-lab2). Debounce the input/change/DOM-mutation
    // triggers so the gate + TOC recompute fires ~180 ms after activity settles; explicit calls stay immediate.
    var _applyT=null;
    function applyD(){ if(_applyT) clearTimeout(_applyT); _applyT=setTimeout(function(){ _applyT=null; apply(); }, 180); }
    // The Continue button's READY state is cheap (allFilled) and must track typing with no delay, so a
    // student -- or the smoke drive -- who has just recorded an answer can Continue at once; only the
    // O(sections+TOC) layout pass in apply() is debounced. Reflect just the active gate's banner
    // synchronously on every input, then schedule the heavy recompute.
    function reflectActive(){
      try{ for(var i=0;i<gates.length;i++){ if(!passed(gates[i])){
        if(gates[i].banner.querySelector('.gate-continue')) reflectBanner(gates[i]); return; } }
      }catch(e){}
    }
    try{
      if(build()){
        apply();
        document.addEventListener('input',function(e){ if(e.target&&e.target.matches&&e.target.matches('textarea[data-ans]')){ reflectActive(); applyD(); } }, true);
        document.addEventListener('change',function(e){ if(e.target&&e.target.matches&&e.target.matches('textarea[data-ans]')){ reflectActive(); applyD(); } }, true);
        // re-hide after late DOM injections (answer-restore, the "Mark complete" labels, scroll-spy, etc.)
        try{ mo=new MutationObserver(function(){ if(!applying) applyD(); });
             mo.observe(document.body,{childList:true}); }catch(e){}
        setTimeout(apply,300); setTimeout(apply,1200);
      }
    }catch(e){ revealAll(); }
  })();

  // ---- Copy button on inline COMMAND snippets in the body (same white icon as Bearings) ----
  (function(){
    var CMD=/^(sudo|systemctl|service|tail|cat|less|head|grep|egrep|awk|sed|cp|mv|rm|mkdir|touch|chmod|chown|chgrp|ls|ln|ssh|ssh-keygen|scp|logger|rsyslogd|vim|vi|nano|dig|nslookup|getent|host|ping|ip|ss|hydra|nmap|tcpdump|apt|apt-get|yum|dnf|echo|printf|curl|wget|make|python3?|bash|sh|usermod|useradd|passwd|groupadd|firewall-cmd|iptables|nft|wazuh-control|journalctl|gradelab|checkwork|stoplab)\b/;
    var ICON='<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>';
    Array.prototype.forEach.call(document.querySelectorAll('code'), function(code){
      if(code.closest('pre,.cw-overlay,.sa-modal,h1,h2,h3,h4,.netdiag-controls,.export-menu')) return;
      var t=(code.textContent||'').trim();
      if(!(/^\.\//.test(t) || (CMD.test(t) && /\s/.test(t)))) return;         // command-looking only
      if(code.nextSibling && code.nextSibling.className && (''+code.nextSibling.className).indexOf('cmd-copy')>=0) return;
      var b=document.createElement('button'); b.type='button'; b.className='sa-copy cmd-copy no-print';
      b.title='Copy command'; b.setAttribute('aria-label','Copy command'); b.setAttribute('data-copy',t);
      b.innerHTML=ICON;
      b.addEventListener('click',function(e){e.stopPropagation(); saCopy(b);});
      code.parentNode.insertBefore(b, code.nextSibling);
    });
  })();

  // ---- Check Work: centered overlay = your progress + what the grader checks ----
  var _cw=document.getElementById('btnCheckWork'), _ov=document.getElementById('cwOverlay');
  function cwLabel(cb){
    var card=cb.closest('.qcard'); if(card){var p=card.querySelector('p'); if(p) return p.textContent.replace(/\s+/g,' ').trim().slice(0,96);}
    var secId=cb.getAttribute('data-sec');
    if(secId){var hh=document.getElementById(secId); if(hh) return hh.textContent.replace(/\s+/g,' ').trim();}
    var h=cb.closest('h1,h2,h3,h4'); if(h) return h.textContent.replace(/\s+/g,' ').trim();
    var lb=cb.closest('label'); return ((lb?lb.textContent:cb.getAttribute('data-done'))||'item').replace(/\s+/g,' ').trim();
  }
  // The element a progress item belongs to (question card, section heading, checklist line, or the
  // closing box), given an id if it has none, so the overlay's list can link straight to it.
  function cwTarget(cb){
    var t=cb.closest('.qcard');
    if(!t){var secId=cb.getAttribute('data-sec'); if(secId) t=document.getElementById(secId);}
    if(!t) t=cb.closest('h1,h2,h3,h4');
    if(!t) t=cb.closest('label');
    if(!t) return null;
    if(!t.id) t.id='pi-'+(cb.getAttribute('data-done')||Math.random().toString(36).slice(2));
    return t;
  }
  function cwFill(){
    var box=document.getElementById('cwProgress'); if(!box) return;
    var items=Array.prototype.slice.call(document.querySelectorAll('.progress-item'));
    var done=0,rows=[];
    items.forEach(function(cb){var on=cb.checked; if(on)done++;
      var t=cwTarget(cb), txt=cwLabel(cb).replace(/&/g,'&amp;').replace(/</g,'&lt;');
      rows.push('<li class="cw-row '+(on?'is-done':'is-todo')+'"><span class="mk'+(on?' on':'')+'">'+(on?'✓':'○')+'</span> '+
        (t?'<a href="#'+t.id+'" class="cw-jump" title="Go to this item in the manual">'+txt+'</a>':txt)+'</li>');});
    var total=items.length, pct=total?Math.round(done/total*100):0, remaining=total-done;
    // remembered filter: show all tasks, or restrict to the ones NOT yet done (so you can jump straight
    // to what's left). The done/todo rows are always built; the toggle just hides the done ones via a class.
    var mode='all'; try{ if(localStorage.getItem('cwfilter:'+LAB)==='todo') mode='todo'; }catch(e){}
    box.innerHTML='<div class="cw-meter">'+done+' / '+total+' items complete ('+pct+'%)</div>'+
      '<div class="cw-bar"><span style="width:'+pct+'%"></span></div>'+
      (total?'<div class="cw-filter" role="group" aria-label="Filter tasks">'+
        '<button type="button" class="cw-fbtn'+(mode==='all'?' on':'')+'" data-f="all">All ('+total+')</button>'+
        '<button type="button" class="cw-fbtn'+(mode==='todo'?' on':'')+'" data-f="todo">Not done ('+remaining+')</button>'+
       '</div>':'')+
      (rows.length?'<ul class="cw-list'+(mode==='todo'?' filter-todo':'')+'">'+rows.join('')+'</ul>':'')+
      '<p class="cw-alldone" hidden>&#10003; Everything is checked off &mdash; nice work.</p>';
    var ul=box.querySelector('.cw-list'), note=box.querySelector('.cw-alldone');
    function applyMode(m){
      if(ul) ul.classList.toggle('filter-todo', m==='todo');
      if(note) note.hidden = !(m==='todo' && remaining===0);
      box.querySelectorAll('.cw-fbtn').forEach(function(x){x.classList.toggle('on', x.getAttribute('data-f')===m);});
    }
    applyMode(mode);
    box.querySelectorAll('.cw-fbtn').forEach(function(b){b.addEventListener('click',function(){
      var f=b.getAttribute('data-f'); try{localStorage.setItem('cwfilter:'+LAB,f);}catch(e){} applyMode(f);
    });});
    // click = close the overlay and jump to the item (scroll-margin-top keeps it clear of the banner)
    box.querySelectorAll('a.cw-jump').forEach(function(a){a.addEventListener('click',function(e){
      e.preventDefault(); var el=document.getElementById(a.getAttribute('href').slice(1)); cwClose();
      if(el){ el.scrollIntoView({behavior:'smooth',block:'start'}); try{history.replaceState(null,'','#'+el.id);}catch(x){} }
    });});
  }
  function cwOpen(){cwFill(); if(_ov)_ov.hidden=false;}
  function cwClose(){if(_ov)_ov.hidden=true;}
  if(_cw) _cw.addEventListener('click',cwOpen);
  // the bottom-left progress meter is also a shortcut into the Check Work overlay
  var _pw=document.getElementById('progwrap');
  if(_pw){ _pw.style.cursor='pointer'; _pw.setAttribute('title','Click to check your work (progress + automated grading)');
    _pw.setAttribute('role','button'); _pw.setAttribute('tabindex','0');
    _pw.addEventListener('click',cwOpen);
    _pw.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();cwOpen();}}); }
  var _cwc=document.getElementById('cwClose'); if(_cwc)_cwc.addEventListener('click',cwClose);
  if(_ov) _ov.addEventListener('click',function(e){if(e.target===_ov)cwClose();});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'||e.keyCode===27)cwClose();});
  var _cwcp=document.getElementById('cwCopyCmd');
  if(_cwcp)_cwcp.addEventListener('click',function(){donCopy('checkwork '+LAB);donToast('Copied “checkwork '+LAB+'”');});
  var _rl=document.getElementById('cwRunLive'), _live=document.getElementById('cwLive');
  if(_rl) _rl.addEventListener('click',function(){
    if(_live){_live.hidden=false;_live.innerHTML='<p>Running <code>checkwork</code> against your live lab… (about 10–15s; the lab keeps running).</p>';}
    bridge('/api/checkwork?lab='+encodeURIComponent(LAB)).then(function(d){
      try{__donLastCW=(d&&d.raw)||null;}catch(e){}   // keep for the debug bundle
      var h='';
      if(d.goals&&d.goals.length){
        var scored=d.goals.filter(function(g){return g.pass===true||g.pass===false;});
        if(!scored.length) h+='<p class="cw-note" style="border:0;margin:0 0 .4em">Goals assessed for this lab (run inside the lab VM for pass/fail):</p>';
        h+='<ul class="cw-goals live">'+d.goals.map(function(g){
          var cls=g.pass===true?'pass':(g.pass===false?'fail':'na');
          var mk=g.pass===true?'✓':(g.pass===false?'✗':'○');
          return '<li class="'+cls+'" title="'+esc2(g.desc||'')+'">'+mk+' '+esc2(g.name)+(g.desc?(' — '+esc2(g.desc)):'')+'</li>';
        }).join('')+'</ul>';
        // fold the checkwork result into the bottom-left progress meter
        if(scored.length){cwTotal=scored.length;cwPassed=scored.filter(function(g){return g.pass===true;}).length;cwState='ok';
          cwGoals=scored.map(function(g){return {name:g.name,desc:g.desc||'',pass:g.pass};});
          try{localStorage.setItem(CWKEY,JSON.stringify({t:cwTotal,p:cwPassed,g:cwGoals}));}catch(e){}
          if(window.__donRefresh)window.__donRefresh();}
      }
      if(d.raw) h+='<details><summary>full checkwork output</summary><div class="cw-raw">'+esc2(d.raw)+'</div></details>';
      if(!h) h='<p>checkwork produced no parseable goals — see the terminal output.</p>';
      if(_live)_live.innerHTML=h;
    }).catch(function(){
      donCopy('checkwork '+LAB);
      if(_live)_live.innerHTML='<p>No live bridge running. Copied “checkwork '+LAB+'” — run it in your lab terminal for results.</p>';
    });
  });

  // ---- connection banner: is the lab bridge reachable (i.e. are we on the lab VM)? ----
  (function(){
    var cb=document.getElementById('connBanner'); if(!cb) return;
    var cx=document.getElementById('connX');
    var dismissed=false; try{dismissed=sessionStorage.getItem('donconn:'+LAB)==='x';}catch(e){}
    if(cx) cx.addEventListener('click',function(){cb.hidden=true;try{sessionStorage.setItem('donconn:'+LAB,'x');}catch(e){}});
    bridge('/api/ping').then(function(){document.body.classList.add('lab-attached');cb.hidden=true;})
      .catch(function(){document.body.classList.remove('lab-attached'); if(!dismissed) cb.hidden=false;});
  })();
  // ---- collapse/expand the contents sidebar (persists per lab in this browser) ----
  var _tt=document.getElementById('tocToggle');
  if(_tt){
    try{ if(localStorage.getItem('dontoc:'+LAB)==='1') document.body.classList.add('toc-collapsed'); }catch(e){}
    var _setIcon=function(){ _tt.innerHTML = document.body.classList.contains('toc-collapsed') ? '&#10095;' : '&#10094;'; };
    _setIcon();
    _tt.addEventListener('click',function(){
      var c=document.body.classList.toggle('toc-collapsed');
      try{localStorage.setItem('dontoc:'+LAB, c?'1':'0');}catch(e){}
      _setIcon();
    });
  }

  // ---- inline self-check: rough regex check of a pasted/typed answer (all the
  //      semicolon-separated patterns in data-check must match), plus a reveal. ----
  // data-check-src="N": the box checks an exact, per-start source IP (Task 4 activities). When the lab
  // bridge is reachable it is authoritative; off-VM or on an older bridge the static data-check regex
  // (format/segment) stands in. Fetched once and cached for all three boxes.
  var _scenSrc=null;
  function scenarioSrc(){
    if(_scenSrc) return _scenSrc;
    _scenSrc=fetch(location.origin+'/api/scenario-src?lab='+encodeURIComponent(LAB),{cache:'no-store'})
      .then(function(r){return r.json();})
      .then(function(d){return (d&&d.ok&&d.sources)?d.sources:null;})
      .catch(function(){return null;});
    return _scenSrc;
  }
  function ipTokens(s){ return (String(s).match(/\b\d{1,3}(?:\.\d{1,3}){3}\b/g))||[]; }
  function inqCheck(box, explicit){
    var ta=box.querySelector('textarea[data-check]'), res=box.querySelector('.inq-result');
    if(!ta||!res) return;
    var reqs=(ta.getAttribute('data-check')||'').split(';').map(function(s){return s.trim();}).filter(Boolean);
    var val=ta.value||'';
    var _ap=box.querySelector('textarea.inq-append'); if(_ap) val=val+'\n'+(_ap.value||'');   // check pre + post-reveal append
    var ok=reqs.length>0 && reqs.every(function(r){try{return new RegExp(r,'i').test(val);}catch(e){return false;}});
    function paint(good){
      if(good){res.textContent='✓ Looks right';res.className='inq-result good';}
      else if(explicit){var hint=ta.getAttribute('data-hint')||'re-check your answer';
        res.textContent=val.trim()?'✗ Not quite — '+hint:'— paste your answer first';res.className='inq-result bad';}
      else{res.textContent='';res.className='inq-result';}
    }
    paint(ok);
    var sn=ta.getAttribute('data-check-src');
    if(sn && explicit){
      scenarioSrc().then(function(src){
        if(!src||!src[sn]||!src[sn].length) return;        // no bridge data -> keep the fallback verdict
        var typed=ipTokens(val), want=src[sn];
        paint(typed.some(function(t){return want.indexOf(t)>=0;}));   // authoritative: must contain THIS activity's real source
      });
    }
  }
  // ---- Answer commit: Check / Show-answer effort-gate (>= REVMIN chars) + hard-lock + append-only ----
  // (owner 2026-10-14) A graded .inq answer HARD-LOCKS on the first feedback action -- clicking "Check my
  // answer" OR opening "Show the correct answer" -- freezing the student's OWN work; an append-only box then
  // opens for anything they add AFTER the feedback. Both controls are disabled until >= REVMIN non-space chars
  // are written (there is no passive live check: feedback comes only from the deliberate, locking click).
  // State persists (donreveal:<lab>:<id> = {at, pre, append, checked, revealed}); the Lab Report locks in the
  // pre-feedback answer and marks whether they checked and/or viewed the answer, plus any post-feedback addition.
  var REVMIN=3;
  function revkey(i){ return "donreveal:"+LAB+":"+i; }
  function revGet(i){ try{ return JSON.parse(localStorage.getItem(revkey(i))||'null'); }catch(e){ return null; } }
  function revSet(i,o){ try{ localStorage.setItem(revkey(i), JSON.stringify(o)); }catch(e){} }
  function setupReveal(box){
    var i=box.getAttribute('data-q');
    var ta=box.querySelector('textarea[data-ans]'); if(!i||!ta) return;
    var det=box.querySelector('details.inq-answer, details.answer');
    var sum=det?det.querySelector('summary'):null;
    var btn=box.querySelector('.inq-check');
    // No early return when there is no feedback control: a progress gate can still COMMIT (hard-lock)
    // this box when the student continues past it, so every answer box registers a lock + append box.
    var locked=false, appendTa=null;
    function gateOk(){ return (ta.value||'').trim().length>=REVMIN; }
    function nag(){ var res=box.querySelector('.inq-result'); if(res){ res.textContent='— write at least '+REVMIN+' characters first'; res.className='inq-result bad'; } }
    function reflectGate(){
      if(locked) return;
      var ok=gateOk();
      if(sum){ sum.style.opacity=ok?'':'.45'; sum.style.cursor=ok?'pointer':'not-allowed';
        if(ok){ sum.removeAttribute('aria-disabled'); sum.title='Show the correct answer (this locks your answer)'; }
        else { sum.setAttribute('aria-disabled','true'); sum.title='Write at least '+REVMIN+' characters first'; } }
      if(btn){ btn.disabled=!ok; btn.title=ok?'Check your answer (this locks your answer)':'Write at least '+REVMIN+' characters first'; }
    }
    function makeAppend(val){
      if(appendTa) return appendTa;
      var wrap=document.createElement('div'); wrap.className='inq-append-wrap no-print'; wrap.style.margin='.45em 0 0';
      var lb=document.createElement('div'); lb.textContent='Add anything after the feedback (your original is locked above):';
      lb.style.cssText='font-size:.85em;color:#6b7a86;margin:.2em 0';
      appendTa=document.createElement('textarea'); appendTa.className='inq-append'; appendTa.setAttribute('data-append', i);
      appendTa.style.cssText='width:100%;min-height:3em;border:1px solid #d7dee2;border-left:3px solid #e0a458;background:#fff;padding:.4em;font:inherit';
      appendTa.value=val||'';
      appendTa.addEventListener('input',function(){ var o=revGet(i)||{at:Date.now(),pre:ta.value||''}; o.append=appendTa.value; revSet(i,o); });
      wrap.appendChild(lb); wrap.appendChild(appendTa);
      var anchor=(det&&det.parentNode)||(btn&&btn.parentNode)||ta.parentNode;
      (anchor.parentNode||anchor).insertBefore(wrap, anchor.nextSibling);
      return appendTa;
    }
    function lock(flag){
      var o=revGet(i)||{at:Date.now(), pre:(ta.value||''), append:''};
      if(flag) o[flag]=true;
      if(!locked){
        locked=true;
        ta.readOnly=true; ta.classList.add('inq-ta-locked');
        ta.style.background='#f0f2f4'; ta.title='Locked — add more in the box below.';
        if(sum){ sum.style.opacity=''; sum.style.cursor='pointer'; sum.removeAttribute('aria-disabled'); }
        if(btn){ btn.disabled=false; }
      }
      revSet(i,o);
      makeAppend(o.append||'');
    }
    // Registry so a progress gate can hard-lock this answer when the student continues past it
    // (reuses the SAME lock -> read-only + append-only box + revSet state the Lab Report renders).
    try{ (window.__gateCommit||(window.__gateCommit={}))[i]=function(){ lock('gated'); }; }catch(e){}
    var ex=revGet(i);
    if(ex){ if(det&&ex.revealed){ try{ det.open=true; }catch(e){} } locked=true;
      ta.readOnly=true; ta.classList.add('inq-ta-locked'); ta.style.background='#f0f2f4';
      makeAppend(ex.append||''); if(btn) btn.addEventListener('click',function(){ try{inqCheck(box,true);}catch(e){} });
      return; }   // restore a prior commit (locked)
    reflectGate();
    ta.addEventListener('input', reflectGate);
    if(sum){
      sum.addEventListener('click', function(e){ if(locked) return; if(!gateOk()){ e.preventDefault(); nag(); } });
      det.addEventListener('toggle', function(){ if(det.open && gateOk()) lock('revealed'); });
    }
    if(btn){
      btn.addEventListener('click', function(){ if(!gateOk()){ nag(); return; } try{ inqCheck(box,true); }catch(e){} lock('checked'); });
    }
  }
  document.querySelectorAll('.inq, .qcard').forEach(function(box){ try{ setupReveal(box); }catch(e){} });
  try{ window.__donRevGet=revGet; window.__donSetupReveal=setupReveal; }catch(e){}   // test hooks

  // ---- copy-to-clipboard button on every code / config / command block ----
  document.querySelectorAll('pre').forEach(function(pre){
    if(pre.querySelector('.copy-btn')) return;
    var code=pre.querySelector('code')||pre;
    var btn=document.createElement('button');
    btn.type='button'; btn.className='copy-btn no-print';
    // inline SVG clipboard/check (not emoji -- the clipboard emoji renders as a blank tofu box in a
    // Firefox without a colour-emoji font); matches the password "copy" buttons.
    var _cpIco='<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>';
    var _okIco='<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>';
    btn.innerHTML=_cpIco+'<span>Copy</span>';
    var reset=function(){btn.classList.remove('copied');btn.innerHTML=_cpIco+'<span>Copy</span>';};
    var done=function(){btn.classList.add('copied');btn.innerHTML=_okIco+'<span>Copied</span>';setTimeout(reset,1200);};
    var fallback=function(text){try{var ta=document.createElement('textarea');ta.value=text;
      ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();
      document.execCommand('copy');ta.remove();done();}catch(e){btn.textContent='Ctrl+C';}};
    btn.addEventListener('click',function(){
      var text=code.innerText;
      if(navigator.clipboard&&navigator.clipboard.writeText){
        navigator.clipboard.writeText(text).then(done,function(){fallback(text);});
      }else{fallback(text);}
    });
    pre.appendChild(btn);
  });

  // ---- host "prompt" chip on command blocks (pre[data-host]): EVERY command block carries its
  //      user@host chip in the DOM so a student can always confirm WHICH host/user a command runs on.
  //      To stay visually quiet, the chip is PERMANENT only at a transition -- the first block of a
  //      run on a given user@host (a new task, or the host/user changed from the previous block) --
  //      and HIDDEN BY DEFAULT on the subsequent same-user@host blocks, where it REVEALS ON HOVER.
  //      The next transition is permanent again. Net: transitions mark the page without clutter, and
  //      any block answers "where am I?" on hover (#183). Suppressed entirely on a single-host lab
  //      (nothing to disambiguate -> no clutter). The chip sits OUTSIDE <code>, so the copy button
  //      (which copies only code.innerText) never carries it to the clipboard; user-select:none keeps
  //      it out of a manual selection too. Print shows every chip (see @media print in the theme),
  //      since hover does not exist on paper. ----
  (function(){
    var pres=document.querySelectorAll('pre[data-host]'); if(!pres.length) return;
    var seen={}; Array.prototype.forEach.call(pres,function(p){ seen[p.getAttribute('data-host')]=1; });
    if(Object.keys(seen).length<2) return;   // single-host lab: stay out of the way
    var seq=document.querySelectorAll('h2[id^="task-"], pre[data-host]');
    var curTask=null, lastLabel=null, lastTask=null;
    Array.prototype.forEach.call(seq,function(el){
      if(el.tagName==='H2'){ curTask=el.id; return; }
      var host=el.getAttribute('data-host');
      var label=el.getAttribute('data-cmdlabel')||host;
      var transition=(label!==lastLabel || curTask!==lastTask);
      var chip=document.createElement('span');
      chip.className='cmd-host'+(transition?'':' cmd-host-hover');
      chip.title='Run this on '+(el.getAttribute('data-cmdlabel')||host);
      chip.textContent=label;
      el.classList.add('has-host');
      if(!transition) el.classList.add('has-host-hover');
      el.insertBefore(chip, el.firstChild);
      lastLabel=label; lastTask=curTask;
    });
  })();

  // ---- Task.step numbering: every top-level ordered-list item inside a "Task N" section is
  //      labelled N.k (a running count across the section, so each sub-task has one id in the
  //      whole manual). Nested lists and lists inside callouts / answer boxes are left alone. ----
  document.querySelectorAll('h2[id^="task-"]').forEach(function(h){
    var m=/^\s*Task\s+(\d+[a-z]?)/i.exec(h.textContent||''); if(!m) return;   // 3b -> 3b.1, 3b.2 ...
    var n=m[1], k=0;
    for(var el=h.nextElementSibling; el && el.tagName!=='H2'; el=el.nextElementSibling){
      if(el.tagName!=='OL') continue;
      el.classList.add('tsteps');
      Array.prototype.forEach.call(el.children,function(li){
        if(li.tagName!=='LI') return; k++;
        var sp=document.createElement('span'); sp.className='stepno'; sp.textContent=n+'.'+k;
        li.insertBefore(sp,li.firstChild); if(!li.id) li.id='step-'+n+'-'+k;
      });
    }
  });

  // ---- non-clickable group labels in the sidebar: 'Situational Awareness' over the
  //      front-matter sections, 'Tasks' over the numbered Task steps ----
  function tocGroup(text, before){
    if(!before) return; var li=before.closest('li'); if(!li) return;
    var lbl=document.createElement('li'); lbl.className='toc-group'; lbl.textContent=text;
    li.parentNode.insertBefore(lbl, li);
  }
  tocGroup('Situational Awareness', document.querySelector('#TOC a[href="#scenario-brief"]') || document.querySelectorAll('#TOC a')[1] || document.querySelector('#TOC a'));
  tocGroup('Tasks', document.querySelector('#TOC a[href^="#task-"]'));
  var _parts=document.querySelectorAll('#TOC a[href^="#task-"]');
  // Sidebar only: "Task 3 - Title" reads as "3 - Title" under the Tasks group (body headings keep "Task").
  _parts.forEach(function(a){ var t=a.firstChild; while(t&&t.nodeType!==3) t=t.nextSibling;
    if(t) t.nodeValue=t.nodeValue.replace(/^\s*Task\s+(\d+)\s*/i,'$1 '); });
  if(_parts.length){ var _lastLi=_parts[_parts.length-1].closest('li');
    var _nx=_lastLi&&_lastLi.nextElementSibling;
    if(_nx&&_nx.querySelector('a')) tocGroup('Debrief', _nx.querySelector('a')); }
  var _faq=[].slice.call(document.querySelectorAll('#TOC a')).filter(function(a){return /help|faq/i.test(a.textContent||'');})[0];
  // 'Support & References' starts at the MITRE ATT&CK / D3FEND lists (then FAQ), not inside the Debrief
  tocGroup('Support & References', document.querySelector('#TOC a[href^="#mitre-"]') || _faq);

  // ---- Progress tracking: check off sections + questions; a live meter that
  // persists per lab in this browser (in addition to the answers above). ----
  var SKIP=/^(scenario|objectives|the network|credentials|grading|references|deliverables|questions|independent experiment|verification checklist|debrief.*|mitre.*)$/i;
  document.querySelectorAll('h2').forEach(function(h){
    if(h.closest('.cw-overlay,.cw-modal,.export-menu,.conn-banner')) return;  // skip UI/overlay headings
    var t=(h.textContent||'').trim();
    if(SKIP.test(t)) return;
    // Cap the slug so the narrative flag prog:<lab>:<id> stays within the engine's 80-char id limit
    // (long task headings otherwise overflow it -> setFlag throws "bad flag id"). 48 chars keeps a
    // lab's sections distinct (they differ in their first words) while leaving room for the prefix.
    var id='sec:'+t.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,48).replace(/-+$/,'');
    var lbl=document.createElement('label'); lbl.className='sec-done no-print';
    var cb=document.createElement('input'); cb.type='checkbox'; cb.className='progress-item';
    cb.setAttribute('data-done',id); cb.setAttribute('data-sec', h.id||'');
    lbl.appendChild(cb); lbl.appendChild(document.createTextNode(' Mark this section complete'));
    // place at the BOTTOM of the section: after the last node before the next h1/h2
    var last=h, n=h.nextElementSibling;
    while(n && !/^H[12]$/.test(n.tagName)){ last=n; n=n.nextElementSibling; }
    last.parentNode.insertBefore(lbl, last.nextSibling);
  });
  var items=[].slice.call(document.querySelectorAll('.progress-item'));
  // ---- sidebar TOC: current-section dot (scroll-spy) + per-section completion ticks ----
  var tocMap=[].slice.call(document.querySelectorAll('#TOC a[href^="#"]')).map(function(a){
    var sec=document.getElementById(decodeURIComponent(a.getAttribute('href').slice(1)));
    return sec?{a:a,sec:sec}:null;
  }).filter(Boolean);
  function tocTick(){ tocMap.forEach(function(x){
    var cb=x.sec.id?document.querySelector('input.progress-item[data-sec="'+x.sec.id+'"]'):null;
    x.a.classList.toggle('done', !!(cb&&cb.checked)); }); }
  function tocSpy(){ var best=null,by=-1e9;
    tocMap.forEach(function(x){ var top=x.sec.getBoundingClientRect().top-90;
      if(top<=0 && top>by){by=top;best=x;} });
    if(!best && tocMap.length) best=tocMap[0];
    tocMap.forEach(function(x){ x.a.classList.toggle('here', x===best); }); }
  window.addEventListener('scroll',tocSpy,{passive:true});
  window.addEventListener('resize',tocSpy);
  function refresh(){
    var done=0; items.forEach(function(c){ if(c.checked) done++; });
    done+=cwPassed;                              // fold in checkwork goals that pass
    var total=items.length+cwTotal, pct=total?Math.round(done*100/total):0;
    var f=document.getElementById('progfill'); if(f) f.style.width=pct+'%';
    var l=document.getElementById('proglabel');
    if(l) l.textContent='Complete '+done+'/'+total+' ('+pct+'%)';
    tocTick();
  }
  window.__donRefresh=function(){try{refresh();}catch(e){}};   // let the live check update the meter
  items.forEach(function(c){
    var id=c.getAttribute('data-done');
    function apply(){
      var on=c.checked, box=c.closest('.qcard'), h=c.closest('h2');
      if(box) box.classList.toggle('done',on); else if(h) h.classList.toggle('done',on);
      try{localStorage.setItem('donprog:'+LAB+':'+id, on?'1':'0');}catch(e){}
      refresh();
    }
    try{ if(localStorage.getItem('donprog:'+LAB+':'+id)==='1') c.checked=true; }catch(e){}
    c.addEventListener('change',apply); apply();
  });

  // ---- Auto-complete a Task section once every inline answer box in it has content.
  //      Pure decision rule (unit-tested by ci/test_manual_autocomplete.py in node):
  //        clearedOne && checked           -> false (uncheck: the student emptied an answer)
  //        allNow && !prevAll && !checked  -> true  (check: the section JUST became fully answered)
  //        otherwise                       -> null  (leave it: a manual un/check sticks) ----
  // DON-AUTORULE-BEGIN
  function donAutoRule(prevAll, allNow, checked, clearedOne){
    if(clearedOne && checked) return false;
    if(allNow && !prevAll && !checked) return true;
    return null;
  }
  // DON-AUTORULE-END
  window.__donAutoRule=donAutoRule;
  document.querySelectorAll('h2[id^="task-"]').forEach(function(h){
    var cb=h.id?document.querySelector('input.progress-item[data-sec="'+h.id+'"]'):null; if(!cb) return;
    var tas=[];
    for(var el=h.nextElementSibling; el && el.tagName!=='H2'; el=el.nextElementSibling){
      if(el.matches && el.matches('.inq')) tas=tas.concat([].slice.call(el.querySelectorAll('textarea[data-ans]')));
      else if(el.querySelectorAll) tas=tas.concat([].slice.call(el.querySelectorAll('.inq textarea[data-ans]')));
    }
    if(!tas.length) return;                       // sections without inline questions stay manual
    function filled(t){return !!(t.value||'').trim();}   // whitespace-only counts as empty
    function allNow(){return tas.every(filled);}
    var prevAll=allNow(), was={};                 // restored answers set the baseline; no auto-check on load
    tas.forEach(function(t){
      var k=t.getAttribute('data-ans'); was[k]=filled(t);
      t.addEventListener('input',function(){
        var now=filled(t), cleared=!!(was[k]&&!now); was[k]=now;
        var all=allNow(), act=donAutoRule(prevAll, all, cb.checked, cleared); prevAll=all;
        if(act!==null && cb.checked!==act){ cb.checked=act; cb.dispatchEvent(new Event('change',{bubbles:true})); }
      });
    });
  });
  refresh(); tocSpy();
})();</script>

## Debrief

<div id="debriefLock" class="sa-locked no-print gated-lock">&#128274; <strong>The debrief is locked.</strong> Work through the lab and check off every item; the progress bar sits at the bottom left of the page (under the contents sidebar) and is repeated in <strong>Actions &#9662; checkwork</strong>. Once they are all complete, the after-action account of the campaign unlocks here.</div>

<div id="debriefContent" class="gated-after" hidden>

### Key Takeaways

Nothing you did today was about a single command. It was about the shape of working at a shell: knowing where you are and moving without thinking (`pwd`, `ls`, `cd`, `cd -`), recalling and fixing a command instead of retyping it (`Up`, `Ctrl+R`, `Ctrl+A`/`Ctrl+E`, `Alt+.`, `!!`, `!$`, `sudo !!`, `^old^new`), editing a file at speed in `vim` (text objects like `ciw`/`ci'`, `:%s///g`, macros, `ZZ`), building several things at once (brace expansion, `&&`), and pulling the one line you need out of a long file (`grep`, `cut`, `sort | uniq -c | sort -rn`, `wc`, `sed`). These are the moves you will reach for in the labs that follow, where the command line is the tool and the security problem is the work. The faster these feel automatic, the more attention you have left for the problem in front of you.


**The enclave at a glance (systems-level view):**

<div class="netdiagram">
<div class="netdiag-controls no-print">Show: <button type="button" data-diag="all">All</button> <button type="button" data-diag="none">None</button> <button type="button" data-diag="net" data-net="userlan">USERLAN</button></div>
<svg class="topo" viewBox="0 0 356 164" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg" role="img">
<g class="net-group" data-net="userlan">
<line class="bus" x1="152" y1="57" x2="330" y2="57"/>
<text class="netlabel" x="8" y="54">USERLAN</text>
<text class="netcidr" x="8" y="70">10.10.10.0/24</text>
<g class="host">
<rect class="hostbox" x="178" y="34" width="128" height="46" rx="6" fill="#3a6ea5"/>
<text class="hostname" x="242" y="53">hi-ws-it</text>
<text class="hostip" x="242" y="69">10.10.10.42</text>
</g>
</g>
</svg>
<script>(function(){var r=document.currentScript.closest('.netdiagram');function g(n){return r.querySelectorAll('.net-group[data-net="'+n+'"]');}function show(el,s){el.forEach(function(e){e.style.display=s?'':'none';});}r.querySelectorAll('[data-diag]').forEach(function(b){b.addEventListener('click',function(){var k=b.getAttribute('data-diag');if(k==='all'){r.querySelectorAll('.net-group').forEach(function(e){e.style.display='';});}else if(k==='none'){r.querySelectorAll('.net-group').forEach(function(e){e.style.display='none';});}else{var gs=g(b.getAttribute('data-net'));var hidden=gs[0]&&gs[0].style.display==='none';show(gs,hidden);}});});})();</script>
</div>


</div>

### Independent Research / Experiment

Every lab closes with a piece of your own. Take the busiest-source pipeline you wrote for Task 6 and extend it one stage further. Instead of the top source IP by count, produce a list of the source IPs that failed authentication more than once, and save it to `~/range/repeat-offenders.txt`. Then explain, in a sentence, how you would turn that one-off pipeline into an alias or a short script you could run again next watch without rebuilding it.


<p class="ctf-nudge no-print" id="ctfNudge" hidden>If you want to push further, see whether this range holds a flag worth recovering. Your <a href="#" data-open-ctf>standing and CTF board</a> shows what you have found so far.</p>

<div class="qcard exp" data-q="exp">
<p><span class="qnum">EXP.</span> Your independent research and/or experimentation:</p>
<textarea data-ans="exp" placeholder="What you researched (a tool, technique, or concept) and/or what you tried inside the range; what you observed or learned; and any question it raised."></textarea>
<div class="attach no-print">Attach screenshot(s): <input type="file" accept="image/*" data-shot="exp" multiple></div>
<div class="shots" data-shots="exp"></div>
<label class="complete no-print"><input type="checkbox" class="progress-item" data-done="exp"> Mark complete</label>
</div>

### What You Learned

<div class="qcard" data-q="learn">
<p><span class="qnum">Q.</span> What did this lab make clearer to you? Which concepts, tools, or judgement calls do you understand now that you did not before?</p>
<textarea data-ans="learn" placeholder="A few sentences: the ideas that clicked, and anything you understand now that you did not before."></textarea>
</div>

### Your Feedback

<p class="no-print">Optional and not graded &mdash; your candid feedback helps improve the lab. It is saved with your answers and included in your exported Lab Report.</p>

<div class="qcard" data-q="feedback">
<p><span class="qnum">FB.</span> Feedback on this lab: pacing, difficulty, anything confusing, anything that should change?</p>
<textarea data-ans="feedback" placeholder="Your candid feedback on this lab (optional)."></textarea>
</div>

### Grading

Your work is assessed on these goals:

- Built the ~/range practice workspace and the checklist files (navigation, brace expansion)
- Edited a file in vim with text objects and search-and-replace
- Logged a triage action with redirection and command chaining
- Sliced the busiest source IP out of the auth log with a pipeline
- Tuned the shell with an alias and a ~/.vimrc setting
- Wrote a small runnable status script
- (Unguided challenge) Found the credential-spray source that succeeded and the account it reached

### Deliverables

Answer the **Questions** above. Your answers auto-save in this browser as you type,
and you can attach screenshots to each. Capture them with **Flameshot** on your desktop
(press <kbd>Print</kbd> or <kbd>Super</kbd>+<kbd>p</kbd>, drag a region, annotate, click save;
the file lands in `~/labtainer_xfer/screenshots/`), then use the per-question *Attach
screenshot(s)* control. Inside a container, `shot` still works as a fallback.

**On screenshots.** A screenshot is welcome, and an annotated one (an arrow or a box on the
line that matters) is often clearer than the raw capture. It supports your answer; it
does not replace it. Write out what the screenshot shows and what you conclude from it. Do not
assume the instructor will find the right value in the image, or will know that you saw it.
A screenshot standing alone as an answer is rarely enough.

Also complete the closing **Independent Research / Experiment**, **What You Learned**,
and **Your Feedback** boxes above. Check off each section and question as you finish; the
**progress bar** at the bottom left of the page (under the contents sidebar), also shown under
**Actions &#9662; checkwork**, tracks them. Your progress and answers are saved in this browser.

**Submit — two files.** Every lab is turned in as *both* of these:

1. **Your Lab Report (PDF).** Click **Export answers to PDF** below (or **Download Lab
   Report**, top right): a self-contained PDF of your questions, answers, the closing boxes,
   and screenshots.

   <div class="worksheet-controls no-print"><button type="button" data-ws="pdf">⭳ Export answers to PDF</button> <button type="button" data-ws="download">Download (HTML)</button> <span class="attach">— the export is only your questions, answers, and screenshots (for submission).</span></div>

   <p class="no-print" style="font-size:.92em;color:#6b7a86;margin:.3em 0 0">Saving as PDF from your browser&#8217;s Print command (<strong>Ctrl&#8288;+&#8288;P</strong>, or <strong>&#8984;P</strong> on macOS) produces this same report, not the raw manual, so either way your full answers are captured.</p>
2. **Your lab archive (`.lab`).** Run **`stoplab bootcamp`** (or the **stoplab**
   button). It collects the work you did *inside the containers* — the files you
   created and edited, and your command history from every host — into one file at:

   ```
   ~/labtainer_xfer/bootcamp/*.lab
   ```

   This is the file the instructor runs through automated grading, so it is required.

**Upload BOTH to the LMS** (the PDF and the `.lab`), unless your instructor says otherwise.

> **If the LMS rejects the `.lab` for size:** some course sites cap upload size, and a
> multi-container lab's archive can exceed it. In that case upload the **Lab Report PDF**
> to the LMS and get the **`.lab`** to your instructor another way per your course
> instructions (e.g. a shared drive or email). Do not skip the `.lab` — it is what is graded.

## FAQ

<p class="no-print">Type to filter the questions below (matches question <em>and</em> answer text),
or press <kbd>Ctrl</kbd>+<kbd>F</kbd> for your browser's find. This lab runs its hosts as
containers; by default <code>donlab</code> lays them out in one <strong>tmux</strong> session
(one window per host you use) and opens this manual in Firefox.</p>

<input type="search" id="faqsearch" class="no-print" placeholder="Search help&hellip;  e.g. terminal, files, stop, sudo, scroll" style="width:100%;box-sizing:border-box;padding:.55em .7em;font-size:1em;border-radius:6px;margin:.2em 0 1em;" />
<p class="no-print" id="faqnone" hidden style="color:#6b7a86;font-style:italic">No matching help topics.</p>

<div id="faqlist">

<details class="faq"><summary>How do I use tmux?</summary>
<p><strong>tmux</strong> is a terminal multiplexer: it runs many shells inside one terminal window,
each in its own <em>window</em> or <em>pane</em>, and keeps them all alive even if you detach or
close the terminal. <code>donlab</code> starts your lab in one tmux session with a window per host,
so a handful of keys covers the movement this lab requires.</p>
<p>tmux key bindings start with the <strong>prefix</strong> <kbd>Ctrl</kbd>+<kbd>b</kbd>: press
and release it, <em>then</em> press the next key. Quick reference:</p>
<table class="tmux-ref">
<tr><th colspan="2">Windows (one per host)</th></tr>
<tr><td><kbd>Ctrl</kbd>+<kbd>b</kbd> <kbd>n</kbd> / <kbd>p</kbd></td><td>next / previous window (host)</td></tr>
<tr><td><kbd>Ctrl</kbd>+<kbd>b</kbd> <kbd>0</kbd>&hellip;<kbd>9</kbd></td><td>jump to window by number</td></tr>
<tr><td><kbd>Ctrl</kbd>+<kbd>b</kbd> <kbd>w</kbd></td><td>pick a window from a list</td></tr>
<tr><td><kbd>Ctrl</kbd>+<kbd>b</kbd> <kbd>c</kbd></td><td>create a new window</td></tr>
<tr><th colspan="2">Panes (splits within one host)</th></tr>
<tr><td><kbd>Ctrl</kbd>+<kbd>b</kbd> <kbd>&quot;</kbd> / <kbd>%</kbd></td><td>split top/bottom&nbsp;/&nbsp;left/right</td></tr>
<tr><td><kbd>Ctrl</kbd>+<kbd>b</kbd> <kbd>&larr;&uarr;&darr;&rarr;</kbd></td><td>move between panes</td></tr>
<tr><td><kbd>Ctrl</kbd>+<kbd>b</kbd> <kbd>z</kbd></td><td>zoom a pane full-screen (toggle)</td></tr>
<tr><td><kbd>Ctrl</kbd>+<kbd>b</kbd> <kbd>x</kbd></td><td>close the current pane</td></tr>
<tr><th colspan="2">Scroll &amp; session</th></tr>
<tr><td><kbd>Ctrl</kbd>+<kbd>b</kbd> <kbd>[</kbd></td><td>scroll/copy mode (arrows, <kbd>PgUp</kbd>; <kbd>q</kbd> to exit)</td></tr>
<tr><td><kbd>Ctrl</kbd>+<kbd>b</kbd> <kbd>d</kbd></td><td>detach (the lab keeps running)</td></tr>
<tr><td><code>tmux attach -t lab-bootcamp</code></td><td>re-attach after detaching</td></tr>
</table>
<p>Go deeper: run <code>man tmux</code> in any shell for the full reference; the official
<a href="https://github.com/tmux/tmux/wiki/Getting-Started" target="_blank" rel="noopener">tmux Getting Started wiki</a>
is a well-written walkthrough; and NetworkChuck's
<a href="https://www.youtube.com/watch?v=Yl7NFenTgIo" target="_blank" rel="noopener">&ldquo;you need to learn tmux RIGHT NOW&rdquo;</a>
video is a concise 15-minute visual introduction.</p></details>

<details class="faq"><summary>How do I open another terminal or shell on a host?</summary>
<p>In the tmux layout, each host is a window. To get a second shell <em>on the same host</em>,
split the pane: <kbd>Ctrl</kbd>+<kbd>b</kbd> then <kbd>&quot;</kbd> (split top/bottom) or
<kbd>Ctrl</kbd>+<kbd>b</kbd> then <kbd>%</kbd> (split left/right). <kbd>Ctrl</kbd>+<kbd>b</kbd>
then <kbd>c</kbd> opens a brand-new window. From <em>any</em> shell on the Labtainer host you can
also attach directly: <code>docker exec -it bootcamp.&lt;host&gt;.student bash -l</code>.</p></details>

<details class="faq"><summary>How do I switch between hosts / windows?</summary>
<p>Each host is its own tmux window. <kbd>Ctrl</kbd>+<kbd>b</kbd> then <kbd>n</kbd> / <kbd>p</kbd>
= next / previous host; <kbd>Ctrl</kbd>+<kbd>b</kbd> then <kbd>w</kbd> = pick from a list;
<kbd>Ctrl</kbd>+<kbd>b</kbd> then a <kbd>number</kbd> jumps straight to that window. The window
name and pane border show which host you are on (or run <code>hostname</code>).</p></details>

<details class="faq"><summary>The window list along the bottom is too long with many hosts &mdash; how do I see them all vertically?</summary>
<p>On a lab with several hosts the horizontal status line runs off the edge. Press
<kbd>Ctrl</kbd>+<kbd>b</kbd> then <kbd>w</kbd> to open tmux's <em>window tree</em>: a
<strong>vertical, scrollable list of every window</strong> (one per host) with a live preview of
the highlighted one. Move with the arrow keys or <kbd>j</kbd>/<kbd>k</kbd>, press <kbd>Enter</kbd>
to jump to a host, or just start typing to filter the list by name; <kbd>q</kbd> or <kbd>Esc</kbd>
backs out. <kbd>Ctrl</kbd>+<kbd>b</kbd> then a <kbd>number</kbd> still jumps straight to a window by
its index if you know it.</p></details>

<details class="faq"><summary>How do I scroll back through output, or select and copy text?</summary>
<p>Enter copy/scroll mode with <kbd>Ctrl</kbd>+<kbd>b</kbd> then <kbd>[</kbd>, scroll with
<kbd>PgUp</kbd>/<kbd>PgDn</kbd> and the arrows, and press <kbd>q</kbd> to exit. The mouse is
enabled too, so you can scroll the wheel and drag-select to copy.</p></details>

<details class="faq"><summary>How do I make one pane full-screen?</summary>
<p><kbd>Ctrl</kbd>+<kbd>b</kbd> then <kbd>z</kbd> zooms the current pane to fill the window;
press it again to un-zoom.</p></details>

<details class="faq"><summary>How do I step away without losing my work?</summary>
<p>Detach with <kbd>Ctrl</kbd>+<kbd>b</kbd> then <kbd>d</kbd> &mdash; the containers keep running.
Come back with <code>tmux attach -t lab-bootcamp</code> (or just re-run <code>donlab bootcamp</code>).
Detaching leaves everything running; closing a pane ends only that shell and whatever was running in it.</p></details>

<details class="faq"><summary>How do I move files between the Labtainer host and a container?</summary>
<p>Two ways. <strong>1) MyStuff:</strong> on a host that has a MyStuff folder, anything you put in
<code>~/mystuff</code> inside the container is shared with the Labtainer host's
<code>mystuff</code> directory (and with the other MyStuff containers) &mdash; drop a file there and
it appears on the other side. <strong>2) docker cp</strong>, run from the Labtainer host (not from
inside a container): container&rarr;host is
<code>docker cp bootcamp.&lt;host&gt;.student:/home/&lt;user&gt;/file .</code>; host&rarr;container is
<code>docker cp ./file bootcamp.&lt;host&gt;.student:/home/&lt;user&gt;/</code>.</p></details>

<details class="faq"><summary>How do I run a command in a container from the host?</summary>
<p><code>docker exec -it bootcamp.&lt;host&gt;.student &lt;command&gt;</code>. Leave off
<code>-it</code> for a one-shot non-interactive command. Use <code>docker ps</code> to list the
exact container names.</p></details>

<details class="faq"><summary>Where is the lab manual, and how do I submit?</summary>
<p><code>donlab</code> opens this manual in Firefox automatically; you can also open
<code>docs/bootcamp.html</code> in the lab folder. Answer the <strong>Questions</strong> (they
auto-save in this browser) and attach screenshots taken with <strong>Flameshot</strong>
(<kbd>Print</kbd> or <kbd>Super</kbd>+<kbd>p</kbd>; see <em>How do I take a screenshot</em>
below). You turn in
<strong>two files</strong>: (1) your <strong>Lab Report PDF</strong> (click
<strong>Export answers to PDF</strong>); and (2) your <strong>lab archive</strong> — run
<code>stoplab bootcamp</code>, which writes a <code>.lab</code> file under
<code>~/labtainer_xfer/bootcamp/</code>. Upload <strong>both</strong> to the LMS. If the LMS
rejects the <code>.lab</code> as too large, upload the PDF and send the <code>.lab</code> to your
instructor another way (per your course instructions) — it is the file that is graded.</p></details>

<details class="faq"><summary>How do I take a screenshot, and how should I use it in an answer?</summary>
<p>Use <strong>Flameshot</strong> on your desktop (donlab installs it): press <kbd>Print</kbd> or
<kbd>Super</kbd>+<kbd>p</kbd>, drag a region (or click a window), add an arrow, box, highlight or
blur from the toolbar, then click the save icon. The image is written to
<code>~/labtainer_xfer/screenshots/</code>; pick it with the question's <em>Attach screenshot(s)</em>
control. Because the lab's Firefox and terminals draw on your desktop, Flameshot captures them
too. Inside a container the <code>shot</code> command (<code>shot -s</code> for a region) is a
plain fallback with no annotation.</p>
<p>A screenshot supports an answer; it does not replace one. Write what the image shows and what
you conclude from it, and mark the line that matters. Do not assume the instructor will find the
right value in the image or will know that you saw it. A screenshot standing alone as an answer is
rarely enough.</p></details>

<details class="faq"><summary>How do I edit a file, and what is the sudo password?</summary>
<p>Use <code>vim</code>; tab-completion and command history are enabled on
every host. Your <code>sudo</code> password is your own account password &mdash; open the
<strong>Bearings</strong> panel (compass button, top right) and copy it from the Credentials tab.</p></details>

<details class="faq"><summary>How do I stop the lab, check my progress, or start over?</summary>
<p>Stop and save with <code>stoplab bootcamp</code>. See how the graded goals are scoring with
<code>checkwork bootcamp</code>. To start from a fresh instance (this <em>discards</em> your current
work): <code>donlab bootcamp -r</code>.</p></details>

<details class="faq"><summary>Can I use normal pop-up terminal windows instead of tmux?</summary>
<p>Yes &mdash; run <code>donlab bootcamp --no-tmux</code> and Labtainers opens a separate
terminal window per host, the classic way.</p></details>

<details class="faq"><summary>How do I put the manual and the terminal side by side (i3 tiling session)?</summary>
<p>Lab work happens in <strong>i3</strong>, a tiling window manager: tiled windows do not overlap, so the
Firefox manual and your terminal sit side by side with a single <em>draggable divider</em> between
them, and the layout is keyboard-driven. <code>donlab</code> is opinionated about this: the first
time you run it from another desktop (the appliance boots into XFCE) it installs i3 if needed,
makes i3 your login session, and <strong>reboots once</strong>; the first i3 login opens a
quick-start window with the keys below, already in the Labtainers student directory. The modifier
key (<code>$mod</code>) is <kbd>Super</kbd> (the &#8984;/Windows key), chosen so it never collides
with tmux's <kbd>Ctrl</kbd>+<kbd>b</kbd>.</p>
<table class="tmux-ref">
<tr><td><kbd>$mod</kbd>+<kbd>Return</kbd></td><td>open a terminal (run <code>donlab</code> here)</td></tr>
<tr><td><kbd>$mod</kbd>+<kbd>w</kbd></td><td>open Firefox &mdash; i3 tiles it beside the terminal</td></tr>
<tr><td>lab layout</td><td>when a lab starts, donlab arranges the screen: terminal on the left half, this manual top right, and Firefox or Wireshark launched <em>inside a container</em> bottom right</td></tr>
<tr><td><kbd>$mod</kbd>+<kbd>d</kbd></td><td>run a program by name</td></tr>
<tr><td>drag the border between two tiles</td><td>resize both with the mouse</td></tr>
<tr><td><kbd>$mod</kbd>+<kbd>r</kbd>, then arrows, <kbd>Enter</kbd></td><td>resize with the keyboard</td></tr>
<tr><td><kbd>$mod</kbd>+arrow keys</td><td>move focus between panes</td></tr>
<tr><td><kbd>$mod</kbd>+<kbd>f</kbd></td><td><strong>swap an app to full screen and back</strong>: press once to make the focused window fill the screen (e.g. the manual, or Wireshark), press again to drop it back into its tile</td></tr>
<tr><td><kbd>$mod</kbd>+<kbd>1</kbd> &hellip; <kbd>4</kbd></td><td>switch workspace (the numbers at the bottom left); <kbd>$mod</kbd>+<kbd>Shift</kbd>+number sends the focused window there</td></tr>
<tr><td><kbd>$mod</kbd>+<kbd>Shift</kbd>+<kbd>q</kbd></td><td>close the focused window</td></tr>
<tr><td><kbd>$mod</kbd>+<kbd>Shift</kbd>+<kbd>e</kbd></td><td>exit i3 back to the login screen</td></tr>
<tr><td><code>cdlab</code></td><td>in any shell: cd to the Labtainers student directory</td></tr>
</table>
<p>tmux still runs <em>inside</em> the terminal pane exactly as before, so the two layer cleanly:
i3 tiles the windows, tmux multiplexes shells within the terminal. The status bar at the bottom
shows disk and memory use (yellow from 70&nbsp;%, red from 80&nbsp;%) and the clock with its
time zone.</p>
<p><strong>Prefer XFCE?</strong> <kbd>$mod</kbd>+<kbd>Shift</kbd>+<kbd>e</kbd>, then pick
<em>Xfce Session</em> from the session menu at the login screen (on the appliance the login screen asks no password), and run
<code>donlab --no-i3</code> (or <code>export DONLAB_NO_I3=1</code>) so it stops switching you
back.</p></details>

</div>

<script>(function(){
  var box=document.getElementById('faqsearch'); if(!box) return;
  var items=[].slice.call(document.querySelectorAll('#faqlist .faq'));
  var none=document.getElementById('faqnone');
  box.addEventListener('input',function(){
    var q=box.value.trim().toLowerCase(), shown=0;
    items.forEach(function(d){
      var hit = q==='' || d.textContent.toLowerCase().indexOf(q)>=0;
      d.hidden=!hit; if(hit){shown++; d.open = q!=='';}
      if(q==='') d.open=false;
    });
    if(none) none.hidden = (shown>0);
  });
})();</script>

<style>
/* ---- report-box writing experience (Tier 1): auto-grow, prose type, word count,
       saved cue, smart lists, markdown preview, and a full-screen "focus" pane. The
       <textarea data-ans> stays the single source of truth (save + report export read
       its .value), so this is pure UX chrome -- all of it no-print / never exported. --- */
.inq textarea[data-ans], .qcard textarea[data-ans]{
  font-family:"Iowan Old Style","Palatino Linotype",Palatino,Georgia,serif;
  font-size:1.03em; line-height:1.6; padding:.6em .75em; letter-spacing:.1px;
  transition:min-height .12s ease, box-shadow .12s ease;
}
.inq textarea[data-ans]:focus, .qcard textarea[data-ans]:focus{
  min-height:8.5em; box-shadow:0 0 0 2px var(--accent2) inset; outline:none;
}
.don-ed-bar .don-fmt{display:inline-flex;gap:.28em;margin-right:.15em;}
.don-ed-bar .don-fmt button{min-width:1.9em;padding:.1em .4em;}
.don-ed-bar .don-fmt-b{font-weight:800;}
.don-ed-bar .don-fmt-i{font-style:italic;font-family:Georgia,serif;}
.don-ed-bar .don-fmt-u{text-decoration:underline;}
.don-ed-bar{display:flex;align-items:center;gap:.85em;margin:.22em 0 .1em;font-size:.82em;
  color:var(--muted);flex-wrap:wrap;}
.don-ed-bar .don-wc{opacity:.85;font-variant-numeric:tabular-nums;}
.don-ed-bar .don-saved{opacity:0;transition:opacity .25s;color:var(--accent2);}
.don-ed-bar .don-saved.on{opacity:.95;}
.don-ed-bar .don-saved.err{color:#e88;opacity:1;font-weight:600;}
.don-ed-bar .don-tgt{opacity:.7;}
.don-ed-bar .don-tgt.met{color:var(--accent2);opacity:.95;}
.don-ed-bar .don-sp{margin-left:auto;}
.don-ed-bar button{background:transparent;border:1px solid var(--rule);color:var(--muted);
  border-radius:5px;padding:.12em .55em;cursor:pointer;font-size:1em;line-height:1.4;}
.don-ed-bar button:hover{border-color:var(--accent2);color:var(--accent2);}
/* the toolbar shows only while the box (or one of its buttons) has focus */
.don-box{position:relative;}
.don-ed-bar{max-height:0;opacity:0;overflow:hidden;margin:0;pointer-events:none;
  transition:max-height .12s ease,opacity .12s ease,margin .12s ease;}
.don-box:focus-within .don-ed-bar{max-height:3em;opacity:1;margin:.22em 0 .1em;pointer-events:auto;}
/* Preview OVERLAY (GFM render), reusing the checkwork modal look */
.don-pv-modal{max-width:min(820px,92vw);}
.don-pv-modal .don-pv-h{margin:.1em 0 .5em;}
.don-preview{font-size:1em;line-height:1.6;color:var(--ink);}
.don-preview h2,.don-preview h3,.don-preview h4,.don-preview h5,.don-preview h6{color:var(--accent2);margin:.5em 0 .3em;}
.don-preview ul,.don-preview ol{margin:.3em 0 .3em 1.3em;}
.don-preview blockquote{border-left:3px solid var(--accent);margin:.4em 0;padding:.2em .8em;color:var(--muted);background:var(--panel);}
.don-preview pre{background:var(--code);padding:.6em .8em;border-radius:6px;overflow-x:auto;}
.don-preview code{background:var(--code);padding:.08em .3em;border-radius:3px;}
.don-preview pre code{background:none;padding:0;}
.don-preview del{opacity:.7;}
.don-preview a{color:var(--accent);}
.don-preview hr{border:none;border-top:1px solid var(--rule);margin:.6em 0;}
.don-preview input[type=checkbox]{margin-right:.4em;}
/* Focus writing OVERLAY: wide checkwork-style modal, textarea fills it */
.don-zen-modal{display:flex;flex-direction:column;max-height:90vh;}
.don-zen-modal .don-zen-q{color:var(--accent2);font-weight:600;line-height:1.45;margin:.1em 2em .6em 0;}
.don-zen-modal .don-zen-host{flex:1 1 auto;display:flex;min-height:50vh;}
.don-zen-modal textarea{flex:1 1 auto;width:100%;min-height:50vh!important;font-size:1.1em;line-height:1.75;
  resize:none;box-shadow:none!important;background:var(--code);color:var(--ink);border:1px solid var(--rule);border-radius:8px;padding:.9em 1em;}
.don-zen-modal .don-zen-foot{display:flex;justify-content:space-between;align-items:center;color:var(--muted);font-size:.85em;margin-top:.5em;gap:1em;}
@media print{.don-ed-bar,.don-preview,.don-zen,.don-pv-ov{display:none!important;}}
/* ---- printing the MANUAL to PDF: a live <textarea> prints only its visible (scrolled) area, so a long
   answer clips. Hide the box in print and show a full-content, page-breakable mirror (built on beforeprint
   from the textarea's .value, rendered with the SAME markdown as the Lab Report). The textarea stays the
   single source of truth; the mirror is print-only and never saved/exported. ---- */
.print-answer{display:none;}
#__donPrintReport{display:none;}   /* the in-page Lab Report used by the print hijack; shown only while printing */
@media print{
  .inq textarea[data-ans], .qcard textarea[data-ans]{display:none!important;}
  .print-answer{display:block!important;white-space:normal;overflow-wrap:break-word;word-break:break-word;
    break-inside:auto;border-left:3px solid #1f4e5f;background:#f4f6f7;color:#12232e;
    padding:.5em .75em;margin:.35em 0;line-height:1.6;font-family:Georgia,"Times New Roman",serif;}
  .print-answer ul,.print-answer ol{margin:.2em 0 .2em 1.2em;}
  .print-answer pre{white-space:pre-wrap;overflow-wrap:break-word;}
  .print-answer .print-empty{color:#889;font-style:italic;}
  .inq, .qcard{break-inside:auto;}
}

/* ---- Progressive disclosure (anti-read-ahead) gates (#131) ---------------------------------
   An author drops a gate marker (gate: ans1 ans2 | msg) where read-ahead should stop; the generator renders a
   .scroll-gate marker and the engine (gateInit, below) collapses everything after the first
   UNSATISFIED gate behind this banner until its answer box(es) hold text. Opt-in, fail-open:
   nothing here hides content unless the engine added .gate-hidden, and print always shows all. */
.scroll-gate{display:none;}                     /* the raw marker never shows; the banner is injected */
/* A clear, full-width boundary box where read-ahead stops: the student sees there IS more below. */
.gate-banner{display:block;margin:2em 0;padding:1.2em 1.4em;border:2px dashed var(--accent);
  border-radius:12px;background:var(--panel);color:var(--ink);font-size:1.02em;line-height:1.55;
  text-align:center;box-shadow:0 0 0 1px rgba(90,169,214,.08) inset;}
.gate-banner .gate-lock{display:block;font-size:1.7em;line-height:1;margin-bottom:.35em;}
.gate-banner .gate-title{font-weight:bold;color:var(--accent);font-size:1.05em;}
.gate-banner .gate-msg{display:block;margin-top:.45em;}
.gate-banner .gate-sub{display:block;color:var(--muted);font-size:.88em;margin-top:.55em;}
.gate-banner .gate-continue{display:inline-block;margin-top:.7em;padding:.5em 1.4em;font-size:1em;font-weight:bold;
  cursor:pointer;border-radius:8px;border:1px solid var(--accent);background:var(--accent);color:#06242f;}
.gate-banner .gate-continue:disabled{opacity:.45;cursor:not-allowed;background:transparent;color:var(--muted);border-color:var(--rule);}
.gate-hidden{display:none!important;}
.ctf-nudge{font-size:.93em;border-left:3px solid var(--accent2);padding:.35em .8em;margin:.8em 0;opacity:.92;}
.ctf-nudge a{cursor:pointer;}
#TOC a.gate-locked{opacity:.4;pointer-events:none;}
#TOC a.gate-locked::after{content:" \1F512";font-size:.85em;opacity:.8;}
@media print{                                    /* the report/print is never gated: reveal everything */
  .gate-hidden{display:revert!important;}
  .gate-banner{display:none!important;}
  #TOC a.gate-locked{opacity:1;pointer-events:auto;}
  #TOC a.gate-locked::after{content:"";}
}
</style>

<script>/* DoN Range -- report-box writing experience (Tier 1). Enhances every <textarea data-ans> in a lab
 * manual (the graded free-text answers) IN PLACE: the textarea stays the single source of truth, so
 * the existing autosave (localStorage) and the Lab Report export read its .value unchanged. All of
 * this is pure UX chrome -- inserted as siblings, marked no-print, never exported:
 *   - auto-grow height + comfortable prose typography (styled in the manual's theme)
 *   - live word count + a "saved" cue + an optional soft target (data-target="N")
 *   - smart markdown lists (Enter continues "- "/"1. "; empty item ends it; Tab / Shift-Tab indent)
 *   - a read-only markdown Preview (escape-first; no author HTML ever runs)
 *   - a full-screen "focus" writing pane (Expand): the real textarea moves in and back out, so its
 *     value + listeners are untouched.
 * Pure DOM, dependency-free, runs in the browser and under jsdom. Auto-runs on ready; also exports
 * DonWritebox.enhance(document) for tests. Idempotent per box (data-don-ed guard).
 */
(function (root) {
  'use strict';

  function words(v) { var m = (v || '').trim().match(/\S+/g); return m ? m.length : 0; }

  // Escape the five HTML metacharacters. Quotes MUST be escaped too: link hrefs are built from this
  // escaped text, so an unescaped " or ' would let a student break out of the href attribute and plant
  // an event handler that runs when the INSTRUCTOR opens the exported report.
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  // Escape-first GitHub-style markdown SUBSET -> safe HTML (author text can NEVER inject HTML).
  // Covers: headings, bold (** __), italic (* _), strikethrough (~~), inline code + fenced blocks,
  // ordered/unordered/task lists, blockquotes, horizontal rules, safe links, and line breaks.
  function inl(x) {
    return x
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/__([^_]+)__/g, '<strong>$1</strong>')
      .replace(/~~([^~]+)~~/g, '<del>$1</del>')
      .replace(/\+\+([^+]+)\+\+/g, '<u>$1</u>')
      .replace(/(^|[^*])\*([^*\s][^*]*?)\*/g, '$1<em>$2</em>')
      .replace(/(^|[^_\w])_([^_\s][^_]*?)_(?![\w])/g, '$1<em>$2</em>')
      // safe schemes only (http/https, site-relative, fragment); the URL may not carry quotes, angle
      // brackets or backticks even in escaped form, so it can never close the href attribute.
      .replace(/\[([^\]]+)\]\(((?:https?:\/\/|\/|#)(?:(?!&quot;|&#39;|&lt;|&gt;)[^\s)"'<>`])*)\)/g,
               '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  }
  function task(x) {
    var m = x.match(/^\[([ xX])\]\s+([\s\S]*)$/);
    if (m) return '<input type="checkbox" disabled' + (/[xX]/.test(m[1]) ? ' checked' : '') + '> ' + inl(m[2]);
    return inl(x);
  }
  function md(src) {
    var s = esc(src), fences = [], codes = [];
    s = s.replace(/```[^\n]*\n([\s\S]*?)```/g, function (_m, c) { fences.push(c); return '\u0000F' + (fences.length - 1) + '\u0000'; });
    s = s.replace(/`([^`\n]+)`/g, function (_m, c) { codes.push(c); return '\u0000C' + (codes.length - 1) + '\u0000'; });
    var lines = s.split(/\n/), out = [], listType = null, inBq = false;
    function closeList() { if (listType) { out.push('</' + listType + '>'); listType = null; } }
    function closeBq() { if (inBq) { out.push('</blockquote>'); inBq = false; } }
    lines.forEach(function (ln) {
      var m;
      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(ln)) { closeList(); closeBq(); out.push('<hr>'); return; }
      if ((m = ln.match(/^\s*(#{1,6})\s+(.+?)\s*#*\s*$/))) { closeList(); closeBq(); var n = Math.min(m[1].length + 1, 6); out.push('<h' + n + '>' + inl(m[2]) + '</h' + n + '>'); return; }
      if ((m = ln.match(/^\s*&gt;\s?(.*)$/))) { closeList(); if (!inBq) { out.push('<blockquote>'); inBq = true; } out.push(inl(m[1]) + '<br>'); return; }
      if ((m = ln.match(/^\s*\d+\.\s+(.+)$/))) { closeBq(); if (listType !== 'ol') { closeList(); out.push('<ol>'); listType = 'ol'; } out.push('<li>' + task(m[1]) + '</li>'); return; }
      if ((m = ln.match(/^\s*[-*]\s+(.+)$/))) { closeBq(); if (listType !== 'ul') { closeList(); out.push('<ul>'); listType = 'ul'; } out.push('<li>' + task(m[1]) + '</li>'); return; }
      closeList(); closeBq(); out.push(ln.trim() === '' ? '' : inl(ln));
    });
    closeList(); closeBq();
    // block-tag newline cleanup + line breaks FIRST, then restore code/fences so their internal
    // newlines are preserved (not converted to <br>).
    var html = out.join('\n')
      .replace(/\n?(<\/?(?:ul|ol|li|h[1-6]|blockquote|hr|pre)[^>]*>|\u0000F\d+\u0000)\n?/g, '$1')
      .replace(/\n{2,}/g, '<br><br>').replace(/\n/g, '<br>')
      .replace(/\u0000C(\d+)\u0000/g, function (m, i) { return (i in codes) ? '<code>' + codes[+i] + '</code>' : m; })
      .replace(/\u0000F(\d+)\u0000/g, function (m, i) { return (i in fences) ? '<pre><code>' + fences[+i] + '</code></' + 'pre>' : m; });
    return html;
  }
  function autoGrow(doc, t) {
    var win = (doc.defaultView || root);
    t.style.height = 'auto';
    var max = Math.round((win.innerHeight || 800) * 0.55);
    var sh = t.scrollHeight || 0;
    t.style.height = Math.min(sh + 2, max) + 'px';
    t.style.overflowY = (sh > max) ? 'auto' : 'hidden';
  }

  // Enter continues a markdown list; an empty item ends it. Tab / Shift-Tab indent by two spaces.
  function keys(t, e) {
    var v = t.value, a = t.selectionStart, b = t.selectionEnd;
    if ((e.ctrlKey || e.metaKey) && !e.altKey) {
      var k = (e.key || '').toLowerCase();
      if (MARKS[k]) { e.preventDefault(); wrapSel(t, MARKS[k][0], MARKS[k][1]); return; }
    }
    if (e.key === 'Enter' && !e.shiftKey && a === b) {
      var ls = v.lastIndexOf('\n', a - 1) + 1, line = v.slice(ls, a);
      var m = line.match(/^(\s*)([-*]\s+|\d+\.\s+)(.*)$/);
      if (m) {
        e.preventDefault();
        if (!m[3]) { t.value = v.slice(0, ls) + v.slice(a); t.selectionStart = t.selectionEnd = ls; }
        else {
          var mk = /\d+\./.test(m[2]) ? (parseInt(m[2], 10) + 1) + '. ' : m[2];
          var ins = '\n' + m[1] + mk; t.value = v.slice(0, a) + ins + v.slice(b);
          t.selectionStart = t.selectionEnd = a + ins.length;
        }
        fire(t);
      }
    } else if (e.key === 'Tab') {
      e.preventDefault();
      if (e.shiftKey) {
        var ls2 = v.lastIndexOf('\n', a - 1) + 1;
        if (v.slice(ls2, ls2 + 2) === '  ') { t.value = v.slice(0, ls2) + v.slice(ls2 + 2); t.selectionStart = t.selectionEnd = Math.max(ls2, a - 2); }
      } else { t.value = v.slice(0, a) + '  ' + v.slice(b); t.selectionStart = t.selectionEnd = a + 2; }
      fire(t);
    }
  }

  // wrap the current selection (or insert an empty pair and place the caret inside) with pre/post markers
  function wrapSel(t, pre, post) {
    var v = t.value, a = t.selectionStart, b = t.selectionEnd, sel = v.slice(a, b);
    t.value = v.slice(0, a) + pre + sel + post + v.slice(b);
    if (sel) { t.selectionStart = a + pre.length; t.selectionEnd = b + pre.length; }
    else { t.selectionStart = t.selectionEnd = a + pre.length; }
    t.focus(); fire(t);
  }
  var MARKS = { b: ['**', '**'], i: ['*', '*'], u: ['++', '++'] };

  function fire(t) {
    var ev; try { ev = new (t.ownerDocument.defaultView || root).Event('input', { bubbles: true }); }
    catch (e) { ev = t.ownerDocument.createEvent('Event'); ev.initEvent('input', true, false); }
    t.dispatchEvent(ev);
  }

  function enhance(doc) {
    doc = doc || (root.document);
    if (!doc) return { count: 0 };
    var boxes = Array.prototype.slice.call(doc.querySelectorAll('textarea[data-ans]'))
      .filter(function (t) { return !t.hasAttribute('data-check') && !t.getAttribute('data-don-ed'); });
    if (!boxes.length) return { count: 0 };

    // one full-screen focus pane, reused; moves the real textarea in and back out
    var zen = null, zenHome = null, zenBox = null, zenWc = null;
    function buildZen() {
      // reuse the manual's checkwork overlay look (.cw-overlay backdrop + .cw-modal card), widened for writing
      zen = doc.createElement('div'); zen.className = 'cw-overlay don-zen no-print'; zen.hidden = true;
      zen.innerHTML = '<div class="cw-modal cw-wide don-zen-modal" role="dialog" aria-modal="true" aria-label="Focus writing">' +
        '<button class="cw-close don-zen-x" type="button" aria-label="Close">\u00D7</button>' +
        '<div class="don-zen-q"></div><div class="don-zen-host"></div>' +
        '<div class="don-zen-foot"><span class="don-zen-wc"></span><span class="don-zen-hint">Esc or \u00D7 to close \u2014 your text is saved</span></div>' +
        '</div>';
      doc.body.appendChild(zen);
      zen.querySelector('.don-zen-x').addEventListener('click', closeZen);
      zen.addEventListener('click', function (e) { if (e.target === zen) closeZen(); });   // click backdrop to close
      doc.addEventListener('keydown', function (e) { if (zen && !zen.hidden && e.key === 'Escape') closeZen(); });
      zenWc = zen.querySelector('.don-zen-wc');
    }
    function openZen(t, qtext, refresh) {
      if (!zen) buildZen();
      zen.querySelector('.don-zen-q').textContent = qtext || ''; zenBox = t;
      zenHome = doc.createComment('don-zen-home'); t.parentNode.insertBefore(zenHome, t);
      zen.querySelector('.don-zen-host').appendChild(t);
      zen.hidden = false; try { doc.body.style.overflow = 'hidden'; } catch (e) {}
      var oh = t.style.height; t.dataset.donOh = oh; t.style.height = '';
      if (zenWc) zenWc.textContent = words(t.value) + ' words';
      t.focus();
    }
    function closeZen() {
      if (!zen || zen.hidden || !zenBox) return; var t = zenBox;
      if (zenHome && zenHome.parentNode) { zenHome.parentNode.insertBefore(t, zenHome); zenHome.parentNode.removeChild(zenHome); }
      zen.hidden = true; try { doc.body.style.overflow = ''; } catch (e) {}
      if (t.dataset.donOh != null) { t.style.height = t.dataset.donOh; delete t.dataset.donOh; }
      autoGrow(doc, t); zenBox = null; t.focus();
    }

    // one Preview overlay, reused: renders the box's markdown read-only in a modal (never a copy on the page)
    var pvOv = null, pvBody = null, pvBox = null;
    function buildPreview() {
      pvOv = doc.createElement('div'); pvOv.className = 'cw-overlay don-pv-ov no-print'; pvOv.hidden = true;
      pvOv.innerHTML = '<div class="cw-modal don-pv-modal" role="dialog" aria-modal="true" aria-label="Preview">' +
        '<button class="cw-close" type="button" aria-label="Close">\u00D7</button>' +
        '<h2 class="don-pv-h">Preview</h2><div class="don-preview don-pv-body"></div></div>';
      doc.body.appendChild(pvOv);
      pvOv.querySelector('.cw-close').addEventListener('click', closePreview);
      pvOv.addEventListener('click', function (e) { if (e.target === pvOv) closePreview(); });
      doc.addEventListener('keydown', function (e) { if (pvOv && !pvOv.hidden && e.key === 'Escape') closePreview(); });
      pvBody = pvOv.querySelector('.don-pv-body');
    }
    function openPreview(t) { if (!pvOv) buildPreview(); pvBox = t; pvBody.innerHTML = md(t.value); pvOv.hidden = false; }
    function closePreview() { if (pvOv) pvOv.hidden = true; pvBox = null; }

    boxes.forEach(function (t) {
      t.setAttribute('data-don-ed', '1');
      if (!t.hasAttribute('spellcheck')) t.spellcheck = true;

      var bar = doc.createElement('div'); bar.className = 'don-ed-bar no-print';
      // B / I / U format buttons (also Ctrl/Cmd+B/I/U) -- wrap the selection in markdown markers
      var fmt = doc.createElement('span'); fmt.className = 'don-fmt';
      [['b', 'B', 'Bold (Ctrl+B)'], ['i', 'I', 'Italic (Ctrl+I)'], ['u', 'U', 'Underline (Ctrl+U)']].forEach(function (f) {
        var btn = doc.createElement('button'); btn.type = 'button'; btn.className = 'don-fmt-' + f[0];
        btn.textContent = f[1]; btn.title = f[2];
        btn.addEventListener('click', function () { wrapSel(t, MARKS[f[0]][0], MARKS[f[0]][1]); });
        fmt.appendChild(btn);
      });
      bar.appendChild(fmt);
      var wcEl = doc.createElement('span'); wcEl.className = 'don-wc';
      var saved = doc.createElement('span'); saved.className = 'don-saved'; saved.textContent = 'saved';
      var tgtN = parseInt(t.getAttribute('data-target') || '0', 10);
      var tgt = doc.createElement('span'); tgt.className = 'don-tgt'; if (tgtN > 0) tgt.textContent = 'aim ~' + tgtN + ' words';
      var sp = doc.createElement('span'); sp.className = 'don-sp';
      var pvBtn = doc.createElement('button'); pvBtn.type = 'button'; pvBtn.textContent = 'Preview';
      var exBtn = doc.createElement('button'); exBtn.type = 'button'; exBtn.textContent = '⇱ Expand';
      exBtn.title = 'Full-screen focus writing (Esc to exit)';
      bar.appendChild(wcEl); bar.appendChild(saved); if (tgtN > 0) bar.appendChild(tgt);
      bar.appendChild(sp); bar.appendChild(pvBtn); bar.appendChild(exBtn);
      // wrap the textarea + its bar so the bar shows only while the box (or a toolbar button) has focus
      var boxWrap = doc.createElement('div'); boxWrap.className = 'don-box';
      t.parentNode.insertBefore(boxWrap, t); boxWrap.appendChild(t); boxWrap.appendChild(bar);

      function refresh() {
        var n = words(t.value); wcEl.textContent = n + (n === 1 ? ' word' : ' words');
        if (tgtN > 0) tgt.className = 'don-tgt' + (n >= tgtN ? ' met' : '');
        if (pvOv && !pvOv.hidden && pvBox === t) pvBody.innerHTML = md(t.value);
        if (zen && !zen.hidden && zenBox === t && zenWc) zenWc.textContent = n + ' words';
      }
      var savedT;
      t.addEventListener('input', function () {
        autoGrow(doc, t); refresh();
        // read the canonical autosave's result AFTER it runs (both input handlers fire synchronously),
        // so the cue tells the truth: "saved" on success, a loud warning if the write failed (quota).
        setTimeout(function () {
          if (t.getAttribute('data-save-err')) {
            saved.textContent = '\u26A0 not saved \u2014 storage full; copy your text';
            saved.className = 'don-saved err on';
          } else if (!t.getAttribute('data-don-saved')) {
            // no verified write happened at all (no autosave wired to this box): say so, never "saved"
            saved.textContent = '\u26A0 not saved \u2014 copy your text';
            saved.className = 'don-saved err on';
          } else {
            saved.textContent = 'saved'; saved.className = 'don-saved on';
            clearTimeout(savedT); savedT = setTimeout(function () { saved.className = 'don-saved'; }, 1100);
          }
        }, 0);
      });
      t.addEventListener('keydown', function (e) { keys(t, e); });
      pvBtn.addEventListener('click', function () { openPreview(t); });
      exBtn.addEventListener('click', function () {
        var card = t.closest ? t.closest('.inq,.qcard') : null;
        var qEl = card && card.querySelector('p'); openZen(t, qEl ? qEl.textContent : '', refresh);
      });
      autoGrow(doc, t); refresh();
    });

    var win = doc.defaultView || root;
    if (win && win.addEventListener) win.addEventListener('resize', function () {
      boxes.forEach(function (t) { if (!t.dataset || !t.dataset.donOh) autoGrow(doc, t); });
    });
    api.collapseZen = closeZen;   // let the report export return an expanded textarea home before it reads values
    return { count: boxes.length, enhanceZenClose: closeZen };
  }

  var api = { enhance: enhance, words: words, md: md };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.DonWritebox = api;

  // auto-run in the browser
  if (root.document) {
    var d = root.document;
    if (d.readyState !== 'loading') enhance(d);
    else d.addEventListener('DOMContentLoaded', function () { enhance(d); });
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
</script>

<script>(function(){
  if(!window.DonOverlay||!window.DonNarrative) return;
  var LAB="bootcamp", course=LAB.split('-')[0];
  var storage=null; try{storage=window.localStorage;}catch(e){}
  var ctl;
  try{
    ctl=window.DonOverlay.mount(document,{
      course:course, lab:LAB, pack:(window.NARR_PACK||{}), storage:storage, seed:(course+':'+LAB),
      getBalanceCents:function(){ return (typeof window.__donBalanceCents==='number')?window.__donBalanceCents:null; },
      getEcon:function(){ return window.__donEcon||null; }
    });
    window.__donGame=ctl;   // exposed for the console + future FRMS balance wiring
  }catch(e){ return; }
  // Preview-only demo seed (never for a real student): show the HUD populated + one checkpoint pop-up.
  if(/[?&](demo|preview)=1\b/.test(location.search)){
    try{
      window.__donBalanceCents=249500000;            // e.g. $2,495,000 left after a $5k contractor
      ctl.reachCheckpoint('arrival');
      var qs=(window.NARR_PACK&&window.NARR_PACK.quests)||[];
      if(qs[0]&&qs[0].id) ctl.startQuest(qs[0].id);
      ctl.render();
      var ov=document.getElementById('cwOverlay'); if(ov) ov.hidden=false;   // open so the dashboard is visible
    }catch(e){}
  }
})();</script>

<script>(function(){
  // #135: optional CTF nudge in the Independent Research / Experiment box. Self-gating -- shown ONLY
  // when this lab actually has CTF flags (labs with no narrative pack leave it hidden). The link opens
  // the progress overlay (checkwork), where the Standing & CTF board lives, by reusing the real open
  // path (btnCheckWork) so the game dashboard refreshes. Fail-open: no game -> still opens the overlay.
  function hasCtf(){ try{ var G=window.__donGame,N=window.DonNarrative; if(!G||!N||!G.state) return false;
    var b=N.ctfBoard(G.state, window.NARR_PACK||{})||[]; return b.length>0; }catch(e){ return false; } }
  function reveal(){ try{ var n=document.getElementById('ctfNudge'); if(n && hasCtf()) n.hidden=false; }catch(e){} }
  document.addEventListener('click', function(e){
    var a=e.target && e.target.closest && e.target.closest('[data-open-ctf]'); if(!a) return;
    e.preventDefault();
    var btn=document.getElementById('btnCheckWork');
    if(btn){ try{ btn.click(); return; }catch(e2){} }
    var ov=document.getElementById('cwOverlay'); if(ov) ov.hidden=false;
  });
  if(document.readyState!=='loading') setTimeout(reveal,1400);
  else document.addEventListener('DOMContentLoaded', function(){ setTimeout(reveal,1400); });
})();</script>
