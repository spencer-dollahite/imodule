#!/bin/bash
# file-system-permissions :: attacker (Kali). rockyou.txt ships with Kali at
# /usr/share/wordlists/rockyou.txt.gz -- unpack it for convenience.
PERMLOCKDIR=/var/labtainer/did_param
echo "$1" | sudo -S mkdir -p "$PERMLOCKDIR"
if [ -f /usr/share/wordlists/rockyou.txt.gz ] && [ ! -f /usr/share/wordlists/rockyou.txt ]; then
  echo "$1" | sudo -S gunzip -k /usr/share/wordlists/rockyou.txt.gz 2>/dev/null
fi
