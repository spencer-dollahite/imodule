#!/bin/bash
# fixlocal.sh -- GENERATED for tap (tap) in lab don-ids-201.
# Runs once, as student, after parameterization, before the terminal opens.
# $1 = user password, $2 = user id.
PERMLOCKDIR=/var/labtainer/did_param
