# Lab Report — Cutlass Bay: Something is scanning the server VLAN

<!--
  NAVSTA Cutlass Bay Training Enclave · Lab don-ids-201
  Edit this file in vim. Capture screenshots with `shot`, and preview with
  `preview ~/report-don-ids-201.md`. It is collected automatically when you stop the lab.
  Fill in every field below. Delete the italic prompts as you go.
-->

| Field | Value |
|-------|-------|
| Name | _your name_ |
| Date | _YYYY-MM-DD_ |
| Lab | `don-ids-201` |
| Workstation | _hostname you worked from_ |

## Summary

_One paragraph: what you did and what you found._

## 1. Snort flagged the reconnaissance scan

**What I did:**

_Steps you took._

**Evidence:**

_Paste output and screenshots. Use `shot` to capture, e.g._ `![login prompt](shots/shot-001.png)`

**Result / answer:**

_Your finding for this objective._

## 2. Zeek recorded the scan in its notice log

**What I did:**

_Steps you took._

**Evidence:**

_Paste output and screenshots. Use `shot` to capture, e.g._ `![login prompt](shots/shot-001.png)`

**Result / answer:**

_Your finding for this objective._


## Reflection

_What was the security lesson? What would you do differently, or recommend to the command?_
