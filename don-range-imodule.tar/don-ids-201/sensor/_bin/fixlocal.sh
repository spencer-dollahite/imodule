#!/bin/bash
# fixlocal.sh -- GENERATED for sensor (sensor) in lab don-ids-201.
# Runs once, as kobrien, after parameterization, before the terminal opens.
# $1 = user password, $2 = user id.
PERMLOCKDIR=/var/labtainer/did_param
echo $1 | sudo -S mkdir -p "$PERMLOCKDIR"
