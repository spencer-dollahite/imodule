---
title: "Cutlass Bay: Something is scanning the server VLAN"
subtitle: "NAVSTA Cutlass Bay Training Enclave"
lab: "don-ids-201"
---

# Cutlass Bay: Something is scanning the server VLAN

<p class="meta">NAVSTA Cutlass Bay Training Enclave &bull; Lab <code>don-ids-201</code> &bull; Operation TIDE BREAKER</p>

## Scenario

Endpoint alerts hint that a workstation on the user VLAN is probing the server VLAN. A passive sensor mirrors both segments. Use Zeek and Snort on the sensor to confirm the reconnaissance, identify the source, and describe what was targeted.


**Your role:** SOC analyst triaging sensor telemetry.

## Objectives

By the end of this lab you will be able to:

- Snort flagged the reconnaissance scan
- Zeek recorded the scan in its notice log

## The network

You are working inside the NAVSTA Cutlass Bay Training Enclave. The systems in play for this exercise:

| Host | Address | Role | Your access |
|------|---------|------|-------------|
| `cb-ws-it` (ws_it) | 10.3.10.42 | workstation | `dcho` |
| `cb-fs01` (fileserver) | 10.7.10.20 | fileserver | `dcho` |
| `cb-dc01` (dc) | 10.7.10.10 | domain controller | `dcho` |
| `cb-redteam` (redteam) | 10.3.10.66 | redteam | `student` |
| `cb-sensor01` (sensor) | 10.13.99.4 | sensor | `kobrien` |
| `cb-gw01` (gateway) | 10.3.10.254 | gateway | `dcho` |

Network segments:

| Segment | Subnet | Purpose |
|---------|--------|---------|
| cb_user | `10.3.10.0/24` | Cutlass Bay general user / workstation VLAN |
| cb_srv_core | `10.7.10.0/24` | Core infrastructure servers (AD, DNS, file, mail) |
| tap_lan | `10.13.99.0/24` | Out-of-band span/monitor network for the netmon collector |
| wan | `170.180.190.0/26` | Public/internet-facing edge; enclave public NAT IP is 170.180.190.2. Adversary C2 lives here. |

## Credentials

Your workstation has a **KeePassXC vault** in your home directory
(`<user>-vault.kdbx`) holding your accounts and service URLs. Open it in
KeePassXC with your own account password.

## Tasks

> Replace this section with the specific, numbered steps for this lab. Keep each
> task an observable action a student performs, so the automated assessment can
> see it.

1. _First task…_
2. _Second task…_

## Deliverables

Complete the lab report at `~/report-don-ids-201.md` on your workstation:

- Edit it in **vim**.
- Capture evidence with **`shot`**. Your workstation shares the host display, so
  `shot` captures whatever is on screen (including the browser and terminals this
  lab opens); use `shot -s` to grab just one region or window. Images save under
  `./shots/` and it prints a ready-to-paste `![](…)` line.
- Render and check it with **`preview ~/report-don-ids-201.md`** (opens in Firefox as HTML + PDF).
- **Hand in:** run **`submit ~/report-don-ids-201.md`**. It builds a single
  self-contained `report-don-ids-201.pdf` (all screenshots embedded) and copies it
  to the host dropbox at `labtainer-student/mystuff/`. Upload that one PDF to the LMS.
- When you stop the lab, the full report and its `shots/` images are also collected
  in the `.lab` archive for your instructor.

## Grading

Your work is assessed on these goals:

- Snort flagged the reconnaissance scan
- Zeek recorded the scan in its notice log

## References

- NAVSTA Cutlass Bay Training Enclave enclave conventions
- don-range
- intrusion-detection
- zeek
- snort
- network-monitoring
