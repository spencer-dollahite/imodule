#!/bin/bash
# fixlocal.sh -- GENERATED for gateway (gateway) in lab don-ids-201.
# Runs once, as dcho, after parameterization, before the terminal opens.
# $1 = user password, $2 = user id.
PERMLOCKDIR=/var/labtainer/did_param
