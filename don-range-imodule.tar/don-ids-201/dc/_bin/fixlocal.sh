#!/bin/bash
# fixlocal.sh -- GENERATED for dc (domain_controller) in lab don-ids-201.
# Runs once, as dcho, after parameterization, before the terminal opens.
# $1 = user password, $2 = user id.
PERMLOCKDIR=/var/labtainer/did_param
echo $1 | sudo -S mkdir -p "$PERMLOCKDIR"
echo $1 | sudo -S systemctl enable --now dnsmasq 2>/dev/null
echo $1 | sudo -S systemctl restart dnsmasq 2>/dev/null
