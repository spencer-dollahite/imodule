---
title: "Central Logging and Attack Triage"
subtitle: "CS3670 Logging Range"
lab: "cs3670-syslog"
---

<img src="nps-logo.png" alt="NPS" class="lab-logo" />

# Central Logging and Attack Triage

<p class="meta">CS3670 Logging Range &bull; Lab <code>cs3670-syslog</code></p>

## Scenario

You administer a Linux server. Configure its logging, forward events to a central loghost that feeds the Wazuh SIEM, then run three SSH scenarios and determine which are attacks and which is a real user — from the logs and the SIEM.


**Your role:** Data-center administrator.
**Estimated completion time:** 45–60 min.

## Learning Objectives

This lab gives students hands-on experience with:

- Reading and configuring Linux logging with rsyslog (facilities, priorities, rules).
- Generating and testing log records with `logger`, and enabling periodic `-- MARK --`.
- Restricting who may write log records.
- Forwarding logs from a host to a central **loghost**, and feeding a **SIEM (Wazuh)**.
- Telling apart normal and malicious SSH activity in the logs and in the SIEM.

The point of view is that of a data-center administrator.

## The network

| Host | Role |
|------|------|
| `syslog` | The server you administer and investigate (SSH + rsyslog). |
| `loghost` | Central rsyslog relay that feeds the Wazuh SIEM. You configure it. |
| `attacker` | A Kali box that runs the SSH attack scenarios. |
| `workstation` | A normal user's machine that runs the legitimate-login scenario. |

## Part 1 — Explore logging on `syslog`

1. On `syslog`, list `/var/log` and note the rotated files (`.old`, `-YYYYMMDD`, `.0`).
2. Look at the permissions of `/var/log/syslog`. What can non-root users do with it?
3. Follow authentication events: `sudo tail -f /var/log/auth.log`. Leave this running.

## Part 2 — Reconfigure rsyslog

1. Back up the config: `sudo cp /etc/rsyslog.conf /etc/rsyslog.conf.orig`.
2. **Enable MARK.** In the MODULES section, uncomment `module(load="immark")` and set a
   60-second interval: `module(load="immark" interval="60")`.
3. Validate and restart: `rsyslogd -f /etc/rsyslog.conf -N 1` then
   `sudo systemctl restart rsyslog`. Watch `tail -f /var/log/syslog` for `-- MARK --`.
4. **Use logger.** Send a record: `logger -p user.info "Hello World"`, then find which
   active rule filed it and confirm it landed there.
5. **Add a rule.** Route all `debug` messages to `/var/log/mydebug`, restart rsyslog, and
   test with `logger`.
6. **Restrict logger.** Change `/usr/bin/logger` so only root (user and group) may execute it.

## Part 3 — Forward to the loghost and into Wazuh

1. **On `syslog`**, configure rsyslog to forward everything to the loghost over TCP by adding
   `*.*  @@10.0.0.5:514` to `/etc/rsyslog.conf` (or a file in `/etc/rsyslog.d/`), then restart rsyslog.
2. **On `loghost`**, enable reception: load `imtcp` and open port 514, and file remote
   messages under `/var/log/remote/`. Restart rsyslog.
3. **Feed Wazuh.** Point the Wazuh manager at the received logs (add a `localfile` entry for
   `/var/log/remote/*.log` in `/var/ossec/etc/ossec.conf`) and restart it
   (`sudo systemctl restart wazuh-manager`).
4. Open the **Wazuh dashboard** and confirm the forwarded events arrive there too.

> Memory note: the full Wazuh indexer + dashboard is heavy. This lab ships the Wazuh
> **manager** on the loghost; if the dashboard is not provisioned on your VM, inspect
> alerts at `/var/ossec/logs/alerts/alerts.log` instead.

## Part 4 — Run and investigate the scenarios

Watch `auth.log` on `syslog` (and the Wazuh view) while you run each scenario.

- **Scenario 1 (attacker):** on `attacker`, run `./scenario1` — a fast SSH dictionary brute
  force. Note the burst of failures.
- **Scenario 2 (workstation):** on `workstation`, run `./scenario2` — a real user mistypes
  twice, then logs in. Contrast this with the brute force.
- **Scenario 3 (attacker):** on `attacker`, run `./scenario3` — a low-and-slow brute force
  with pauses to evade detection. It **eventually succeeds after a minute or two**, so be
  patient and watch the logs and the SIEM the whole time.

For each scenario, describe in your report how it appears in the logs and in Wazuh, and how a
defender could distinguish an attack from normal activity.

## Part 5 — journalctl

Read `man journalctl`. Use `journalctl -f` to follow events and compare the journal to
classic syslog. Look at `/etc/systemd/journald.conf`.


## The network

The systems in play for this exercise:

| Host | Address | Role | Login |
|------|---------|------|-------|
| `syslog` (syslog) | 10.0.0.7 | server | `student` |
| `loghost` (loghost) | 10.0.0.5 | wazuh manager | `student` |
| `kali-attacker` (attacker) | 10.0.0.66 | redteam | `attacker` |
| `workstation` (workstation) | 10.0.0.20 | workstation | `alice` |

Network segments:

| Segment | Subnet | Purpose |
|---------|--------|---------|
| scorp | `10.0.0.0/24` | Range LAN |

## Deliverables

Complete the lab report at `~/report-cs3670-syslog.md` (on `syslog`):

- Edit it in **vim**.
- Capture evidence with **`shot`**. Your workstation shares the host display, so
  `shot` captures whatever is on screen (including the browser and terminals this
  lab opens); use `shot -s` to grab just one region or window. Images save under
  `./shots/` and it prints a ready-to-paste `![](…)` line.
- Render and check it with **`preview ~/report-cs3670-syslog.md`** (opens in Firefox as HTML + PDF).
- **Hand in:** run **`submit ~/report-cs3670-syslog.md`**. It builds a single
  self-contained `report-cs3670-syslog.pdf` (all screenshots embedded) and copies it
  to the host dropbox at `labtainer-student/mystuff/`. Upload that one PDF to the LMS.
- When you stop the lab, the full report and its `shots/` images are also collected
  in the `.lab` archive for your instructor.

## Grading

Your work is assessed on these goals:

- Enabled the periodic MARK feature in rsyslog
- Added a rule routing debug messages to /var/log/mydebug
- Restricted execution of logger to root only
- Forwarded logs from the syslog host to the loghost
- Configured the loghost to receive remote logs
- Fed the received logs into the Wazuh SIEM

## References

- CS3670 Logging Range
- don-range
- syslog
- logging
- siem
- intrusion detection
