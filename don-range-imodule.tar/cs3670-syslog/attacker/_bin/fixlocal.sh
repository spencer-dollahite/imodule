#!/bin/bash
echo "$1" | sudo -S mkdir -p /var/labtainer/did_param
