# Lab Report — Central Logging and Attack Triage

<!--
  CS3670 Logging Range · Lab cs3670-syslog
  Edit this file in vim. Capture screenshots with `shot`, and preview with
  `preview ~/report-cs3670-syslog.md`. It is collected automatically when you stop the lab.
  Fill in every field below. Delete the italic prompts as you go.
-->

| Field | Value |
|-------|-------|
| Name | _your name_ |
| Date | _YYYY-MM-DD_ |
| Lab | `cs3670-syslog` |
| Workstation | _hostname you worked from_ |

## Summary

_One paragraph: what you did and what you found._

## 1. Enabled the periodic MARK feature in rsyslog

**What I did:**

_Steps you took._

**Evidence:**

_Paste output and screenshots. Use `shot` to capture, e.g._ `![login prompt](shots/shot-001.png)`

**Result / answer:**

_Your finding for this objective._

## 2. Added a rule routing debug messages to /var/log/mydebug

**What I did:**

_Steps you took._

**Evidence:**

_Paste output and screenshots. Use `shot` to capture, e.g._ `![login prompt](shots/shot-001.png)`

**Result / answer:**

_Your finding for this objective._

## 3. Restricted execution of logger to root only

**What I did:**

_Steps you took._

**Evidence:**

_Paste output and screenshots. Use `shot` to capture, e.g._ `![login prompt](shots/shot-001.png)`

**Result / answer:**

_Your finding for this objective._

## 4. Forwarded logs from the syslog host to the loghost

**What I did:**

_Steps you took._

**Evidence:**

_Paste output and screenshots. Use `shot` to capture, e.g._ `![login prompt](shots/shot-001.png)`

**Result / answer:**

_Your finding for this objective._

## 5. Configured the loghost to receive remote logs

**What I did:**

_Steps you took._

**Evidence:**

_Paste output and screenshots. Use `shot` to capture, e.g._ `![login prompt](shots/shot-001.png)`

**Result / answer:**

_Your finding for this objective._

## 6. Fed the received logs into the Wazuh SIEM

**What I did:**

_Steps you took._

**Evidence:**

_Paste output and screenshots. Use `shot` to capture, e.g._ `![login prompt](shots/shot-001.png)`

**Result / answer:**

_Your finding for this objective._


## Reflection

_What was the security lesson? What would you do differently, or recommend to the command?_
