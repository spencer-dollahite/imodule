#!/bin/bash
# Ensure sshd is up so the attack scenarios have a target.
echo "$1" | sudo -S mkdir -p /var/labtainer/did_param
echo "$1" | sudo -S systemctl enable ssh 2>/dev/null
echo "$1" | sudo -S systemctl restart ssh 2>/dev/null
