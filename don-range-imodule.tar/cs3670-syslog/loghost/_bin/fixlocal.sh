#!/bin/bash
# rsyslog + Wazuh manager are present (base). Student configures reception/feed.
echo "$1" | sudo -S mkdir -p /var/labtainer/did_param /var/log/remote
