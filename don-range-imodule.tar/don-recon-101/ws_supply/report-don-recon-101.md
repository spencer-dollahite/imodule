# Lab Report — Cutlass Bay: Where did the manifests go?

<!--
  NAVSTA Cutlass Bay Training Enclave · Lab don-recon-101
  Edit this file in vim. Capture screenshots with `shot`, and preview with
  `preview ~/report-don-recon-101.md`. It is collected automatically when you stop the lab.
  Fill in every field below. Delete the italic prompts as you go.
-->

| Field | Value |
|-------|-------|
| Name | _your name_ |
| Date | _YYYY-MM-DD_ |
| Lab | `don-recon-101` |
| Workstation | _hostname you worked from_ |

## Summary

_One paragraph: what you did and what you found._

## 1. Discovered that the file server exposes SMB on port 445

**What I did:**

_Steps you took._

**Evidence:**

_Paste output and screenshots. Use `shot` to capture, e.g._ `![login prompt](shots/shot-001.png)`

**Result / answer:**

_Your finding for this objective._

## 2. Enumerated the SMB shares and saw the 'manifests' share

**What I did:**

_Steps you took._

**Evidence:**

_Paste output and screenshots. Use `shot` to capture, e.g._ `![login prompt](shots/shot-001.png)`

**Result / answer:**

_Your finding for this objective._


## Reflection

_What was the security lesson? What would you do differently, or recommend to the command?_
