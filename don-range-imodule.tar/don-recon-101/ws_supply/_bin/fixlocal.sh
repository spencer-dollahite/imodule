#!/bin/bash
# fixlocal.sh -- GENERATED for ws_supply (workstation) in lab don-recon-101.
# Runs once, as tmalone, after parameterization, before the terminal opens.
# $1 = user password, $2 = user id.
PERMLOCKDIR=/var/labtainer/did_param
