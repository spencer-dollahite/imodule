---
title: "Cutlass Bay: Where did the manifests go?"
subtitle: "NAVSTA Cutlass Bay Training Enclave"
lab: "don-recon-101"
---

# Cutlass Bay: Where did the manifests go?

<p class="meta">NAVSTA Cutlass Bay Training Enclave &bull; Lab <code>don-recon-101</code> &bull; Operation TIDE BREAKER</p>

## Scenario

The Supply Officer reports that shared logistics files on the squadron file server seem to have moved. Before anyone touches the server, the SOC wants a clean map of what that server actually exposes on the network. From the Supply workstation, discover the file server's open services and list the SMB shares it offers.


**Your role:** Network analyst performing authorized internal reconnaissance.

## Objectives

By the end of this lab you will be able to:

- Discovered that the file server exposes SMB on port 445
- Enumerated the SMB shares and saw the 'manifests' share

## The network

You are working inside the NAVSTA Cutlass Bay Training Enclave. The systems in play for this exercise:

| Host | Address | Role | Your access |
|------|---------|------|-------------|
| `cb-ws-supply` (ws_supply) | 10.3.10.40 | workstation | `tmalone` |
| `cb-fs01` (fileserver) | 10.3.10.20 | fileserver | `dcho` |

Network segments:

| Segment | Subnet | Purpose |
|---------|--------|---------|
| cb_user | `10.3.10.0/24` | Cutlass Bay general user / workstation VLAN |

## Credentials

Your workstation has a **KeePassXC vault** in your home directory
(`<user>-vault.kdbx`) holding your accounts and service URLs. Open it in
KeePassXC with your own account password.

## Tasks

> Replace this section with the specific, numbered steps for this lab. Keep each
> task an observable action a student performs, so the automated assessment can
> see it.

1. _First task…_
2. _Second task…_

## Deliverables

Complete the lab report at `~/report-don-recon-101.md` on your workstation:

- Edit it in **vim**.
- Capture evidence with **`shot`**. Your workstation shares the host display, so
  `shot` captures whatever is on screen (including the browser and terminals this
  lab opens); use `shot -s` to grab just one region or window. Images save under
  `./shots/` and it prints a ready-to-paste `![](…)` line.
- Render and check it with **`preview ~/report-don-recon-101.md`** (opens in Firefox as HTML + PDF).
- **Hand in:** run **`submit ~/report-don-recon-101.md`**. It builds a single
  self-contained `report-don-recon-101.pdf` (all screenshots embedded) and copies it
  to the host dropbox at `labtainer-student/mystuff/`. Upload that one PDF to the LMS.
- When you stop the lab, the full report and its `shots/` images are also collected
  in the `.lab` archive for your instructor.

## Grading

Your work is assessed on these goals:

- Discovered that the file server exposes SMB on port 445
- Enumerated the SMB shares and saw the 'manifests' share

## References

- NAVSTA Cutlass Bay Training Enclave enclave conventions
- don-range
- reconnaissance
- nmap
- smb
