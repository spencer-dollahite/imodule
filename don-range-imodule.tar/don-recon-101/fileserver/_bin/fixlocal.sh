#!/bin/bash
# fixlocal.sh -- GENERATED for fileserver (fileserver) in lab don-recon-101.
# Runs once, as dcho, after parameterization, before the terminal opens.
# $1 = user password, $2 = user id.
PERMLOCKDIR=/var/labtainer/did_param
echo $1 | sudo -S mkdir -p "$PERMLOCKDIR"
echo $1 | sudo -S systemctl enable --now dnsmasq 2>/dev/null
echo $1 | sudo -S systemctl restart dnsmasq 2>/dev/null
echo $1 | sudo -S mkdir -p "$PERMLOCKDIR" /var/log/samba
echo $1 | sudo -S systemctl enable smbd nmbd 2>/dev/null
echo $1 | sudo -S systemctl restart smbd nmbd 2>/dev/null
